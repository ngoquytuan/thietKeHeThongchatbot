
Step1: read fr08_design_document.md
Step2: read requirements_FR-08.md
Step3: implement FR08
Step4: when done, read handover_template.md and make handover_FR08.md



