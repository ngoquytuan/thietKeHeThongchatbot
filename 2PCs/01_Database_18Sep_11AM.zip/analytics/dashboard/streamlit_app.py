import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import time

st.set_page_config(
    page_title="RAG Analytics Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("🤖 RAG Knowledge Assistant Analytics")
st.markdown("Real-time analytics dashboard for Vietnamese Chatbot System")

# API Base URL
API_BASE = "http://fr02-analytics:8003/api/v1/analytics"

# Sidebar filters
st.sidebar.header("📅 Filters")
date_range = st.sidebar.date_input(
    "Select Date Range",
    value=[datetime.now() - timedelta(days=7), datetime.now()],
    max_value=datetime.now()
)

user_level = st.sidebar.selectbox(
    "User Level",
    options=["All", "Guest", "Employee", "Manager", "Director", "System Admin"]
)

# Auto refresh toggle
auto_refresh = st.sidebar.checkbox("Auto Refresh (30s)", value=False)

# Main dashboard
col1, col2, col3, col4 = st.columns(4)

try:
    # Fetch data from analytics API
    params = {}
    if len(date_range) == 2:
        params["start_date"] = date_range[0].isoformat()
        params["end_date"] = date_range[1].isoformat()
    if user_level != "All":
        params["user_level"] = user_level

    # Get analytics summary
    summary_response = requests.get(f"{API_BASE}/summary", timeout=10)

    if summary_response.status_code == 200:
        summary_data = summary_response.json()

        # Metrics cards
        with col1:
            st.metric(
                "Total Searches",
                summary_data.get("search", {}).get("total_searches", 0)
            )
        with col2:
            st.metric(
                "Avg Response Time",
                f"{summary_data.get('search', {}).get('avg_response_time', 0):.0f}ms"
            )
        with col3:
            st.metric(
                "Success Rate",
                f"{summary_data.get('search', {}).get('success_rate', 0):.1f}%"
            )
        with col4:
            st.metric(
                "Active Users",
                summary_data.get("users", {}).get("total_active_users", 0)
            )

    # Search Analytics Section
    st.subheader("🔍 Search Analytics")

    search_response = requests.get(f"{API_BASE}/search", params=params, timeout=10)

    if search_response.status_code == 200:
        search_data = search_response.json()

        col1, col2 = st.columns(2)

        with col1:
            # Search volume chart
            if search_data.get("daily_metrics"):
                df = pd.DataFrame(search_data["daily_metrics"])
                fig = px.line(
                    df,
                    x='date',
                    y='search_count',
                    title='Search Volume Over Time',
                    color_discrete_sequence=['#1f77b4']
                )
                fig.update_layout(
                    xaxis_title="Date",
                    yaxis_title="Search Count",
                    showlegend=False
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No search data available for the selected period")

        with col2:
            # Response time chart
            if search_data.get("daily_metrics"):
                fig = px.line(
                    df,
                    x='date',
                    y='avg_response_time',
                    title='Average Response Time (ms)',
                    color_discrete_sequence=['#ff7f0e']
                )
                fig.update_layout(
                    xaxis_title="Date",
                    yaxis_title="Response Time (ms)",
                    showlegend=False
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                # Show gauge chart for current response time
                current_rt = summary_data.get("search", {}).get("avg_response_time", 0)
                fig = go.Figure(go.Indicator(
                    mode = "gauge+number+delta",
                    value = current_rt,
                    domain = {'x': [0, 1], 'y': [0, 1]},
                    title = {'text': "Avg Response Time (ms)"},
                    delta = {'reference': 1000},
                    gauge = {
                        'axis': {'range': [None, 3000]},
                        'bar': {'color': "darkblue"},
                        'steps': [
                            {'range': [0, 1000], 'color': "lightgray"},
                            {'range': [1000, 2000], 'color': "gray"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 2000
                        }
                    }
                ))
                fig.update_layout(height=300)
                st.plotly_chart(fig, use_container_width=True)

    # User Activity Section
    st.subheader("👥 User Activity Analytics")

    user_response = requests.get(f"{API_BASE}/users", params=params, timeout=10)

    if user_response.status_code == 200:
        user_data = user_response.json()

        col1, col2 = st.columns(2)

        with col1:
            # User level distribution (mock data for demo)
            user_levels = ["Guest", "Employee", "Manager", "Director", "System Admin"]
            user_counts = [20, 45, 15, 8, 2]  # Mock data

            fig = px.pie(
                values=user_counts,
                names=user_levels,
                title='User Distribution by Level'
            )
            fig.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            # Active users over time (mock data)
            dates = pd.date_range(start=date_range[0] if len(date_range) == 2 else datetime.now() - timedelta(days=7),
                                end=date_range[1] if len(date_range) == 2 else datetime.now(),
                                freq='D')
            active_users = [15, 18, 22, 19, 25, 23, 20][:len(dates)]  # Mock data

            df_users = pd.DataFrame({
                'date': dates,
                'active_users': active_users
            })

            fig = px.bar(
                df_users,
                x='date',
                y='active_users',
                title='Daily Active Users',
                color_discrete_sequence=['#2ca02c']
            )
            fig.update_layout(
                xaxis_title="Date",
                yaxis_title="Active Users",
                showlegend=False
            )
            st.plotly_chart(fig, use_container_width=True)

    # System Health Section
    st.subheader("🖥️ System Health")

    system_response = requests.get(f"{API_BASE}/system", timeout=10)

    if system_response.status_code == 200:
        system_data = system_response.json()

        col1, col2, col3 = st.columns(3)

        current_metrics = system_data.get("current_metrics", {})

        with col1:
            # CPU Usage Gauge
            cpu_usage = current_metrics.get("cpu_usage_percent", 0)
            fig = go.Figure(go.Indicator(
                mode = "gauge+number",
                value = cpu_usage,
                title = {'text': "CPU Usage (%)"},
                gauge = {
                    'axis': {'range': [None, 100]},
                    'bar': {'color': "darkred" if cpu_usage > 80 else "darkblue"},
                    'steps': [
                        {'range': [0, 50], 'color': "lightgray"},
                        {'range': [50, 80], 'color': "yellow"},
                        {'range': [80, 100], 'color': "red"}
                    ],
                    'threshold': {
                        'line': {'color': "red", 'width': 4},
                        'thickness': 0.75,
                        'value': 90
                    }
                }
            ))
            fig.update_layout(height=250)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            # Memory Usage Gauge
            memory_usage = current_metrics.get("memory_usage_mb", 0) / 1024  # Convert to GB
            fig = go.Figure(go.Indicator(
                mode = "gauge+number",
                value = memory_usage,
                title = {'text': "Memory Usage (GB)"},
                gauge = {
                    'axis': {'range': [None, 16]},  # Assume 16GB max
                    'bar': {'color': "darkgreen" if memory_usage < 8 else "darkorange"},
                    'steps': [
                        {'range': [0, 8], 'color': "lightgray"},
                        {'range': [8, 12], 'color': "yellow"},
                        {'range': [12, 16], 'color': "red"}
                    ]
                }
            ))
            fig.update_layout(height=250)
            st.plotly_chart(fig, use_container_width=True)

        with col3:
            # System Health Status
            health_status = system_data.get("health_status", "unknown")
            status_color = {
                "healthy": "🟢",
                "warning": "🟡",
                "critical": "🔴",
                "unknown": "⚪"
            }.get(health_status, "⚪")

            st.markdown(f"### System Status")
            st.markdown(f"## {status_color} {health_status.upper()}")

            # Component status
            if system_data.get("component_status"):
                st.markdown("**Component Status:**")
                for component in system_data["component_status"]:
                    comp_status = component.get("status", "unknown")
                    comp_color = {
                        "healthy": "🟢",
                        "warning": "🟡",
                        "critical": "🔴"
                    }.get(comp_status, "⚪")
                    st.markdown(f"- {comp_color} {component.get('component', 'Unknown')}")

    # Footer
    st.markdown("---")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(f"**Last Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    with col2:
        if summary_response.status_code == 200:
            st.markdown("**Status:** ✅ Connected")
        else:
            st.markdown("**Status:** ❌ API Unavailable")
    with col3:
        if st.button("🔄 Refresh Data"):
            st.rerun()

except requests.exceptions.RequestException as e:
    st.error(f"❌ Cannot connect to analytics API: {str(e)}")
    st.info(f"Make sure the analytics service is running at: {API_BASE}")

    # Show mock dashboard when API is unavailable
    st.subheader("📊 Demo Dashboard (API Unavailable)")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Searches", "0")
    with col2:
        st.metric("Avg Response Time", "0ms")
    with col3:
        st.metric("Success Rate", "0.0%")
    with col4:
        st.metric("Active Users", "0")

except Exception as e:
    st.error(f"❌ Unexpected error: {str(e)}")

# Auto-refresh functionality
if auto_refresh:
    time.sleep(30)
    st.rerun()