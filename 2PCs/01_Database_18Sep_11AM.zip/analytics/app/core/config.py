from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Database Configuration
    DATABASE_URL: str = "postgresql+asyncpg://kb_admin:1234567890@fr02-postgres-v2:5432/knowledge_base_v2"

    # Redis Configuration
    REDIS_URL: str = "redis://fr02-redis-master:6379/3"

    # API Configuration
    API_PORT: int = 8003
    LOG_LEVEL: str = "INFO"

    # Security
    JWT_SECRET_KEY: str = "integrated-fr02-fr07-fr08-secret-2025"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # Analytics Configuration
    CACHE_TTL_SECONDS: int = 300
    MAX_QUERY_RESULTS: int = 1000

    class Config:
        env_file = ".env"

settings = Settings()