from fastapi import FastAPI, Depends, HTTPException
from app.api.analytics_endpoints import router as analytics_router
from app.core.database import get_db, engine
from app.models import analytics
import uvicorn

app = FastAPI(
    title="FR-07 Analytics Module",
    description="Integrated Analytics for RAG Knowledge Assistant",
    version="1.0.0"
)

# Create tables
@app.on_event("startup")
async def create_tables():
    async with engine.begin() as conn:
        await conn.run_sync(analytics.Base.metadata.create_all)

# Include routers
app.include_router(analytics_router, prefix="/api/v1/analytics", tags=["Analytics"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "FR-07 Analytics"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8003, reload=False)