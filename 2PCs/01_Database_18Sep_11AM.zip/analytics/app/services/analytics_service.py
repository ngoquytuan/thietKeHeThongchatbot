from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, desc
from app.models.analytics import SearchAnalytics, UserActivitySummary, DocumentUsageStats, SystemMetrics
from app.schemas.analytics import SearchMetricsResponse, UserActivityResponse, DocumentAnalyticsResponse, SystemMetricsResponse
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import json

class AnalyticsService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_search_metrics(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        user_level: Optional[str] = None,
        limit: int = 100
    ) -> SearchMetricsResponse:
        """Get search analytics metrics"""

        # Base query
        query = select(SearchAnalytics)

        # Apply date filters
        if start_date:
            query = query.where(SearchAnalytics.timestamp >= start_date)
        if end_date:
            query = query.where(SearchAnalytics.timestamp <= end_date)

        # Default to last 7 days if no dates provided
        if not start_date and not end_date:
            start_date = datetime.now() - timedelta(days=7)
            query = query.where(SearchAnalytics.timestamp >= start_date)

        # Execute query
        result = await self.db.execute(query.limit(limit))
        searches = result.scalars().all()

        if not searches:
            return SearchMetricsResponse(
                total_searches=0,
                avg_response_time=0.0,
                success_rate=0.0,
                cache_hit_rate=0.0,
                daily_metrics=[]
            )

        # Calculate metrics
        total_searches = len(searches)
        avg_response_time = sum(s.processing_time_ms for s in searches) / total_searches
        success_rate = (sum(1 for s in searches if s.has_results) / total_searches) * 100
        cache_hit_rate = 0.0  # Will implement cache tracking later

        # Daily metrics (simplified)
        daily_metrics = [
            {
                "date": start_date.date().isoformat(),
                "search_count": total_searches,
                "avg_response_time": avg_response_time
            }
        ]

        return SearchMetricsResponse(
            total_searches=total_searches,
            avg_response_time=avg_response_time,
            success_rate=success_rate,
            cache_hit_rate=cache_hit_rate,
            daily_metrics=daily_metrics
        )

    async def get_user_activity(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        department: Optional[str] = None
    ) -> UserActivityResponse:
        """Get user activity analytics"""

        # Get unique users from search analytics
        query = select(func.count(func.distinct(SearchAnalytics.user_id)))

        if start_date:
            query = query.where(SearchAnalytics.timestamp >= start_date)
        if end_date:
            query = query.where(SearchAnalytics.timestamp <= end_date)

        result = await self.db.execute(query)
        total_active_users = result.scalar() or 0

        return UserActivityResponse(
            total_active_users=total_active_users,
            avg_session_duration=0.0,  # Will implement session tracking later
            by_department=[],
            by_user_level=[]
        )

    async def get_document_usage(
        self,
        document_type: Optional[str] = None,
        min_access_count: Optional[int] = 1,
        limit: int = 50
    ) -> DocumentAnalyticsResponse:
        """Get document usage statistics"""

        # For now, return empty response since document usage tracking needs to be implemented
        return DocumentAnalyticsResponse(
            total_documents=0,
            most_accessed_documents=[],
            access_patterns={}
        )

    async def get_system_metrics(
        self,
        component: Optional[str] = None,
        hours: int = 24
    ) -> SystemMetricsResponse:
        """Get system performance metrics"""

        start_time = datetime.now() - timedelta(hours=hours)

        query = select(SystemMetrics).where(SystemMetrics.timestamp >= start_time)

        if component:
            query = query.where(SystemMetrics.metric_type == component)

        query = query.order_by(desc(SystemMetrics.timestamp))

        result = await self.db.execute(query)
        metrics = result.scalars().all()

        if not metrics:
            return SystemMetricsResponse(
                current_metrics={},
                health_status="unknown",
                component_status=[]
            )

        # Calculate current metrics
        latest_metric = metrics[0]
        current_metrics = {
            "cpu_usage_percent": latest_metric.cpu_usage_percent or 0,
            "memory_usage_mb": latest_metric.memory_usage_mb or 0,
            "response_time_ms": latest_metric.response_time_ms or 0
        }

        # Determine health status
        health_status = "healthy"
        if current_metrics["cpu_usage_percent"] > 80:
            health_status = "warning"
        if current_metrics["cpu_usage_percent"] > 95:
            health_status = "critical"

        return SystemMetricsResponse(
            current_metrics=current_metrics,
            health_status=health_status,
            component_status=[
                {
                    "component": latest_metric.metric_type,
                    "status": health_status,
                    "last_update": latest_metric.timestamp.isoformat()
                }
            ]
        )

    async def record_search_analytics(self, search_data: dict) -> bool:
        """Record a search analytics event"""
        try:
            search_record = SearchAnalytics(**search_data)
            self.db.add(search_record)
            await self.db.commit()
            return True
        except Exception as e:
            await self.db.rollback()
            return False

    async def record_system_metric(self, metric_data: dict) -> bool:
        """Record a system performance metric"""
        try:
            metric_record = SystemMetrics(**metric_data)
            self.db.add(metric_record)
            await self.db.commit()
            return True
        except Exception as e:
            await self.db.rollback()
            return False