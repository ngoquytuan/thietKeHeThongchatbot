from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime, date
from enum import Enum

class UserLevel(str, Enum):
    GUEST = "Guest"
    EMPLOYEE = "Employee"
    MANAGER = "Manager"
    DIRECTOR = "Director"
    SYSTEM_ADMIN = "System Admin"

class SearchMetricsResponse(BaseModel):
    total_searches: int
    avg_response_time: float
    success_rate: float
    cache_hit_rate: float
    daily_metrics: Optional[List[Dict[str, Any]]] = None

class UserActivityResponse(BaseModel):
    total_active_users: int
    avg_session_duration: float
    by_department: Optional[List[Dict[str, Any]]] = None
    by_user_level: Optional[List[Dict[str, Any]]] = None

class DocumentAnalyticsResponse(BaseModel):
    total_documents: int
    most_accessed_documents: List[Dict[str, Any]]
    access_patterns: Optional[Dict[str, Any]] = None

class SystemMetricsResponse(BaseModel):
    current_metrics: Dict[str, Any]
    health_status: str
    component_status: List[Dict[str, Any]]

class SearchAnalyticsCreate(BaseModel):
    user_id: Optional[str] = None
    query: str
    results_count: int
    processing_time_ms: int
    has_results: bool = True
    cache_hit: bool = False

class SystemMetricCreate(BaseModel):
    metric_type: str
    response_time_ms: Optional[float] = None
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None
    endpoint: Optional[str] = None
    error_count: Optional[int] = 0