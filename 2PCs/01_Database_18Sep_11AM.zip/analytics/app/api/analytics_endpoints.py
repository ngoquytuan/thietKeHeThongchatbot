from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.analytics_service import AnalyticsService
from app.schemas.analytics import (
    SearchMetricsResponse,
    UserActivityResponse,
    DocumentAnalyticsResponse,
    SystemMetricsResponse,
    SearchAnalyticsCreate,
    SystemMetricCreate
)
from typing import Optional
from datetime import datetime

router = APIRouter()

@router.get("/search", response_model=SearchMetricsResponse)
async def get_search_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    user_level: Optional[str] = Query(None),
    limit: int = Query(100, le=1000),
    db: AsyncSession = Depends(get_db)
):
    """Get search analytics metrics"""
    service = AnalyticsService(db)
    return await service.get_search_metrics(start_date, end_date, user_level, limit)

@router.get("/users", response_model=UserActivityResponse)
async def get_user_activity(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    department: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """Get user activity analytics"""
    service = AnalyticsService(db)
    return await service.get_user_activity(start_date, end_date, department)

@router.get("/documents", response_model=DocumentAnalyticsResponse)
async def get_document_usage(
    document_type: Optional[str] = Query(None),
    min_access_count: Optional[int] = Query(1),
    limit: int = Query(50, le=500),
    db: AsyncSession = Depends(get_db)
):
    """Get document usage statistics"""
    service = AnalyticsService(db)
    return await service.get_document_usage(document_type, min_access_count, limit)

@router.get("/system", response_model=SystemMetricsResponse)
async def get_system_metrics(
    component: Optional[str] = Query(None),
    hours: int = Query(24, le=168),
    db: AsyncSession = Depends(get_db)
):
    """Get system performance metrics"""
    service = AnalyticsService(db)
    return await service.get_system_metrics(component, hours)

@router.post("/record/search")
async def record_search_analytics(
    search_data: SearchAnalyticsCreate,
    db: AsyncSession = Depends(get_db)
):
    """Record search analytics event"""
    service = AnalyticsService(db)

    # Convert to dict for database insertion
    data = search_data.dict()
    data['search_method'] = 'api'  # Default search method

    success = await service.record_search_analytics(data)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to record search analytics"
        )

    return {"message": "Search analytics recorded successfully"}

@router.post("/record/metric")
async def record_system_metric(
    metric_data: SystemMetricCreate,
    db: AsyncSession = Depends(get_db)
):
    """Record system performance metric"""
    service = AnalyticsService(db)

    success = await service.record_system_metric(metric_data.dict())
    if not success:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to record system metric"
        )

    return {"message": "System metric recorded successfully"}

@router.get("/summary")
async def get_analytics_summary(
    db: AsyncSession = Depends(get_db)
):
    """Get analytics summary overview"""
    service = AnalyticsService(db)

    # Get quick metrics from multiple sources
    search_metrics = await service.get_search_metrics(limit=10)
    user_activity = await service.get_user_activity()
    system_metrics = await service.get_system_metrics(hours=1)

    return {
        "search": {
            "total_searches": search_metrics.total_searches,
            "avg_response_time": search_metrics.avg_response_time,
            "success_rate": search_metrics.success_rate
        },
        "users": {
            "total_active_users": user_activity.total_active_users
        },
        "system": {
            "health_status": system_metrics.health_status,
            "current_metrics": system_metrics.current_metrics
        },
        "timestamp": datetime.now().isoformat()
    }