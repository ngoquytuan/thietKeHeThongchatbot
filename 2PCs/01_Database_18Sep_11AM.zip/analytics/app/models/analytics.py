from sqlalchemy import Column, String, Integer, Float, Boolean, Text, DateTime, UUID, ForeignKey, Date, BIGINT
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid

Base = declarative_base()

class SearchAnalytics(Base):
    __tablename__ = "search_analytics"

    search_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True))
    session_id = Column(String(255))
    query = Column(Text, nullable=False)
    query_normalized = Column(Text)
    query_language = Column(String(10), default="vi")
    search_method = Column(String(50), nullable=False)
    filters_applied = Column(JSONB, default={})
    limit_requested = Column(Integer, nullable=False, default=10)
    offset_requested = Column(Integer, default=0)
    results_count = Column(Integer, nullable=False)
    has_results = Column(Boolean, nullable=False)
    top_score = Column(Float)
    avg_score = Column(Float)
    processing_time_ms = Column(Integer, nullable=False)
    semantic_search_time_ms = Column(Integer)
    bm25_search_time_ms = Column(Integer)
    clicked_results = Column(JSONB, default={})
    user_satisfaction = Column(Integer)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

class UserActivitySummary(Base):
    __tablename__ = "user_activity_summary"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True))
    date = Column(Date, nullable=False)
    search_count = Column(Integer, default=0)
    session_duration_minutes = Column(Integer, default=0)
    documents_accessed = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class DocumentUsageStats(Base):
    __tablename__ = "document_usage_stats"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    document_id = Column(UUID(as_uuid=True))
    access_count = Column(Integer, default=0)
    last_accessed = Column(DateTime(timezone=True))
    most_frequent_user_level = Column(String(20))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class SystemMetrics(Base):
    __tablename__ = "system_metrics"

    metric_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    metric_type = Column(String(100), nullable=False)
    response_time_ms = Column(Float)
    memory_usage_mb = Column(Float)
    cpu_usage_percent = Column(Float)
    gpu_usage_percent = Column(Float)
    gpu_memory_mb = Column(Float)
    active_connections = Column(Integer)
    database_size_mb = Column(Float)
    query_count = Column(Integer)
    slow_query_count = Column(Integer)
    cache_hit_rate = Column(Float)
    cache_size_mb = Column(Float)
    endpoint = Column(String(255))
    http_status_code = Column(Integer)
    error_count = Column(Integer)
    metric_metadata = Column(JSONB, default={})

class AnalyticsCache(Base):
    __tablename__ = "analytics_cache"

    cache_key = Column(String(255), primary_key=True)
    cache_value = Column(JSONB, nullable=False)
    cache_type = Column(String(50), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())