# 🔍 FR-02.1 v2.0 Deployment Health Checker

## Overview
This Python script comprehensively checks if your Vietnamese Chatbot Dual Database System deployment is working correctly.

## Features
- **Docker Container Health**: Checks all containers are running
- **PostgreSQL Database**: Tests connection, tables, and extensions  
- **Redis Cache**: Verifies master/replica connectivity and operations
- **ChromaDB Vector DB**: Tests API connectivity and collections
- **Web Interfaces**: Validates Grafana, Prometheus, and Adminer
- **Network Connectivity**: Tests inter-container communication
- **Detailed Reporting**: Generates JSON reports with full details

## Quick Usage

### Option 1: Automatic Installation & Check
```bash
# Install dependencies and run check
./install_and_check.sh
```

### Option 2: Manual Installation
```bash
# Install Python dependencies
pip install -r requirements_check.txt

# Run the deployment checker
python check_deployment.py
```

### Option 3: Without Dependencies (Basic Check)
```bash
# Run with basic checks only (no PostgreSQL/Redis detailed tests)
python check_deployment.py
```

## Output Example
```
[CHECK] FR-02.1 v2.0 DEPLOYMENT HEALTH CHECK
======================================================================

[DOCKER] CHECKING DOCKER CONTAINERS
--------------------------------------------------
[PASS] Docker - Container fr02-postgres-v2: PASS
[PASS] Docker - Container fr02-chroma-v2: PASS
...

DEPLOYMENT HEALTH REPORT
======================================================================
📈 Overall Status: 🟢 EXCELLENT
✅ Passed: 36/37 (97.3%)
❌ Failed: 1
```

## Files Generated
- `deployment_check_results.json`: Detailed JSON report
- Console output with color-coded results

## Interpretation

### Status Levels
- **🟢 EXCELLENT** (90%+): Ready for production
- **🟡 GOOD** (75-89%): Minor issues, mostly working
- **🟠 NEEDS ATTENTION** (50-74%): Several issues need fixing
- **🔴 CRITICAL ISSUES** (<50%): Major problems, not ready

### Common Issues & Solutions

#### PostgreSQL Connection Failed
```bash
# Check if container is running
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Restart if needed
docker-compose restart postgres
```

#### ChromaDB Connection Issues
```bash
# Check ChromaDB health
curl http://localhost:8000/api/v2/heartbeat

# Check logs
docker-compose logs chroma
```

#### Redis Connection Failed
```bash
# Test Redis manually
docker-compose exec redis-master redis-cli ping
```

#### Web Interface Not Accessible
```bash
# Check port bindings
docker-compose ps

# Test with curl
curl http://localhost:3009/api/health  # Grafana
curl http://localhost:9090/-/healthy   # Prometheus
curl http://localhost:8081             # Adminer
```

## Requirements
- Python 3.8+
- Docker & Docker Compose
- Optional: psycopg2-binary, redis, chromadb, requests

## Dependencies
All dependencies are optional. The script will run basic checks without them:
- `psycopg2-binary`: For detailed PostgreSQL checks
- `redis`: For detailed Redis checks  
- `chromadb`: For detailed vector database checks
- `requests`: For web interface checks

## Exit Codes
- `0`: Success (75%+ checks passed)
- `1`: Failure (less than 75% checks passed)

## Integration
Perfect for:
- CI/CD pipeline health checks
- Deployment verification
- Monitoring and alerting
- Troubleshooting deployment issues

## Current Test Results Summary

Based on the latest run:
- **✅ Overall Status**: EXCELLENT (97.3% success rate)
- **✅ Docker**: All 9 containers running
- **✅ PostgreSQL**: All 12 checks passed
- **✅ Redis**: All 5 checks passed  
- **✅ Web Interfaces**: All accessible
- **✅ Network**: All connectivity tests passed
- **⚠️ ChromaDB**: 1 minor client configuration issue

**Recommendation**: System is ready for production use!