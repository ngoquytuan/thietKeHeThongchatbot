# 📋 HANDOVER DOCUMENT: File Storage Integration for FR03.3

## 🎯 **Overview**
This document provides comprehensive information for the FR03.3 team to integrate with the enhanced FR-02.1 module for file storage and management. The FR-02.1 module now supports shared storage for preserving original files sent by FR03.3.

---

## 🔧 **FR-02.1 Module Configuration**

### **Database Configuration**
- **Database Name**: `knowledge_base_v2`
- **Database User**: `kb_admin`
- **Database Password**: `${POSTGRES_PASSWORD}` (from environment variable)
- **Database Host**: `postgres` (container name) or `localhost` (from host)
- **Database Port**: `5432`

### **Connection Pooling (PgBouncer)**
- **PgBouncer Host**: `pgbouncer` (container name) or `localhost` (from host)
- **PgBouncer Port**: `6432`
- **Pool Mode**: `transaction`
- **Max Client Connections**: `1000`
- **Default Pool Size**: `25`

### **Database Connection String**
```
postgresql://kb_admin:${POSTGRES_PASSWORD}@postgres:5432/knowledge_base_v2
```

---

## 🌐 **Service Ports & Endpoints**

### **Core Services**
| Service | Container Name | Host Port | Container Port | Purpose |
|---------|---------------|-----------|----------------|---------|
| PostgreSQL | `fr02-postgres-v2` | `5432` | `5432` | Main database |
| PgBouncer | `fr02-pgbouncer` | `6432` | `5432` | Connection pooling |
| ChromaDB | `fr02-chroma-v2` | `8001` | `8000` | Vector database |
| Redis Master | `fr02-redis-master` | `6379` | `6379` | Cache/Session store |
| Redis Replica | `fr02-redis-replica` | `6380` | `6379` | Cache replica |

### **🆕 File Storage API**
| Service | Container Name | Host Port | Container Port | Purpose |
|---------|---------------|-----------|----------------|---------|
| **File API** | `fr02-file-api` | `8002` | `8000` | **Original file serving** |

### **Monitoring & Management**
| Service | Container Name | Host Port | Container Port | Purpose |
|---------|---------------|-----------|----------------|---------|
| Prometheus | `fr02-prometheus` | `9090` | `9090` | Metrics collection |
| Grafana | `fr02-grafana` | `3009` | `3000` | Dashboards |
| Adminer | `fr02-adminer` | `8081` | `8080` | Database web interface |
| NGINX | `fr02-nginx` | `80, 443` | `80, 443` | Load balancer |

### **Exporters (Metrics)**
| Service | Container Name | Host Port | Purpose |
|---------|---------------|-----------|---------|
| PostgreSQL Exporter | `fr02-postgres-exporter` | `9187` | DB metrics |
| Redis Exporter | `fr02-redis-exporter` | `9121` | Cache metrics |
| Node Exporter | `fr02-node-exporter` | `9100` | System metrics |

---

## 📂 **Shared Storage Configuration**

### **Docker Volume**
- **Volume Name**: `chatbot_storage`
- **Mount Path (in containers)**: `/opt/chatbot-storage`
- **Volume Type**: Docker managed volume
- **Access Mode**:
  - PostgreSQL container: Read/Write
  - File API container: Read-only

### **Storage Structure**
```
/opt/chatbot-storage/
├── original/                    # Original files from FR03.3
│   └── {YYYY}/{MM}/{DD}/       # Date-based organization
│       └── {DEPT}_{TYPE}_{TIMESTAMP}/
│           ├── original_file.pdf
│           ├── file_metadata.json
│           └── access_log.json
├── packages/                   # FR03.1 export packages
│   └── {YYYY}/{MM}/{DD}/
│       └── {DEPT}_{TYPE}_{TIMESTAMP}.zip
├── processed/                  # Processed files
├── temp/                      # Temporary processing
└── logs/                      # Access logs
```

---

## 🗄️ **Enhanced Database Schema**

### **New Fields in `documents_metadata_v2`**
```sql
-- File management fields added to existing table
ALTER TABLE documents_metadata_v2 ADD COLUMN IF NOT EXISTS original_file_info JSONB DEFAULT '{}';
ALTER TABLE documents_metadata_v2 ADD COLUMN IF NOT EXISTS export_package_info JSONB DEFAULT '{}';
ALTER TABLE documents_metadata_v2 ADD COLUMN IF NOT EXISTS file_access_info JSONB DEFAULT '{}';
```

### **Field Structures**

#### **`original_file_info` JSONB Structure**
```json
{
  "original_file_path": "/opt/chatbot-storage/original/2025/09/15/HR_POLICY_20250915_143022/document.pdf",
  "original_filename": "employee_handbook.pdf",
  "file_size_bytes": 2847392,
  "file_hash": "sha256:abc123def456...",
  "mime_type": "application/pdf",
  "upload_timestamp": "2025-09-15T14:30:22Z",
  "uploaded_by": "hr.manager@company.com",
  "file_accessible": true,
  "preservation_status": "preserved",
  "relative_path": "2025/09/15/HR_POLICY_20250915_143022/document.pdf",
  "metadata_file": "/opt/chatbot-storage/original/2025/09/15/.../file_metadata.json",
  "access_log_file": "/opt/chatbot-storage/original/2025/09/15/.../access_log.json"
}
```

#### **`export_package_info` JSONB Structure**
```json
{
  "fr03_1_package_path": "/opt/chatbot-storage/packages/2025/09/15/HR_POLICY_20250915_143022.zip",
  "package_timestamp": "2025-09-15T14:35:45Z",
  "package_hash": "sha256:def789abc012...",
  "package_size_bytes": 1245678,
  "export_version": "1.0",
  "processing_job_id": "uuid-of-job",
  "package_accessible": true,
  "relative_path": "2025/09/15/HR_POLICY_20250915_143022.zip"
}
```

#### **`file_access_info` JSONB Structure**
```json
{
  "storage_tier": "warm",
  "access_count": 0,
  "last_accessed": null,
  "retention_policy": "7_years",
  "backup_locations": [],
  "legal_hold": false,
  "scheduled_deletion": null,
  "storage_location": "shared_volume",
  "preservation_verified": true
}
```

---

## 🔌 **File API Endpoints**

### **Base URL**: `http://localhost:8002`

### **Available Endpoints**

#### **1. Download Original File**
```http
GET /api/documents/{document_id}/original
```
- **Purpose**: Download the original file for a document
- **Response**: File download with proper MIME type
- **Error Codes**: 404 (not found), 500 (server error)

#### **2. Download Export Package**
```http
GET /api/documents/{document_id}/package
```
- **Purpose**: Download the FR03.1 export package
- **Response**: ZIP file download
- **Error Codes**: 404 (not found), 500 (server error)

#### **3. Health Check**
```http
GET /health
```
- **Purpose**: Check API and storage accessibility
- **Response**: JSON with status and storage info

#### **4. API Information**
```http
GET /
```
- **Purpose**: Get API version and status
- **Response**: JSON with API info

---

## 🔄 **Integration Requirements for FR03.3**

### **1. Docker Network Integration**
FR03.3 must join the FR-02.1 network:
```yaml
networks:
  fr02-network:
    external: true  # Use network from FR-02.1
```

### **2. Shared Volume Mount**
FR03.3 must mount the shared storage volume:
```yaml
volumes:
  chatbot_storage:
    external: true  # Use volume from FR-02.1

services:
  fr03-3-processor:
    volumes:
      - chatbot_storage:/opt/chatbot-storage:rw  # Read-write access
```

### **3. Environment Variables**
```yaml
environment:
  - DATABASE_URL=postgresql://kb_admin:${POSTGRES_PASSWORD}@postgres:5432/knowledge_base_v2
  - STORAGE_BASE_PATH=/opt/chatbot-storage
```

### **4. File Preservation Logic**
FR03.3 must implement file preservation when importing documents:

```python
# Example file preservation function for FR03.3
async def preserve_files_to_fr02_storage(extracted_dir: str, job_id: str, manifest: dict):
    """
    Preserve original file and package to FR-02.1 shared storage
    """
    storage_base = "/opt/chatbot-storage"

    # Create date-based directory structure
    now = datetime.now()
    date_path = f"{now.year:04d}/{now.month:02d}/{now.day:02d}"
    package_name = manifest.get('package_name', f"UNKNOWN_{job_id}")

    # Preserve original file
    original_dir = f"{storage_base}/original/{date_path}/{package_name}"
    os.makedirs(original_dir, exist_ok=True)

    # Copy original file from extracted package
    original_files = list(Path(f"{extracted_dir}/original").glob("*"))
    if original_files:
        original_file = original_files[0]
        preserved_path = f"{original_dir}/{original_file.name}"
        shutil.copy2(original_file, preserved_path)

        # Create metadata and access log files
        # ... (see full implementation in update_FR03.3_FR02.1.md)

    return {
        "original_file_path": preserved_path,
        "package_info": {...}
    }
```

### **5. Database Integration**
When inserting documents, FR03.3 must populate the new file management fields:

```python
# Enhanced insert query with file information
insert_query = """
    INSERT INTO documents_metadata_v2 (
        document_id, title, content, document_type, access_level,
        department_owner, author, status, language_detected,
        vietnamese_segmented, diacritics_normalized, tone_marks_preserved,
        search_text_normalized, indexable_content, extracted_emails,
        extracted_phones, extracted_dates, embedding_model_primary,
        chunk_count, file_size_bytes, search_tokens,
        original_file_info, export_package_info, file_access_info,
        created_at, updated_at
    ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
        $15, $16, $17, $18, $19, $20, to_tsvector('simple', $13),
        $21, $22, $23, $24, $25
    )
"""
```

---

## 🔐 **Authentication & Security**

### **Database Access**
- **Username**: `kb_admin`
- **Password**: Stored in `${POSTGRES_PASSWORD}` environment variable
- **SSL Mode**: `disable` (for local development)

### **API Security**
- Currently no authentication implemented (basic setup)
- File access is direct (no user permissions yet)
- **TODO for FR03.3**: Implement proper authentication/authorization

---

## 📊 **Monitoring & Troubleshooting**

### **Service Health Checks**
1. **Database**: `pg_isready -U kb_admin -d knowledge_base_v2`
2. **File API**: `curl http://localhost:8002/health`
3. **Storage**: Check `/opt/chatbot-storage` accessibility

### **Log Locations**
```bash
# Container logs
docker-compose logs fr02-postgres-v2
docker-compose logs fr02-file-api

# Storage logs
# Inside containers: /opt/chatbot-storage/logs/
```

### **Common Issues & Solutions**
1. **Volume mount issues**: Ensure `chatbot_storage` volume exists
2. **Permission issues**: Check file ownership in storage directories
3. **Database connection**: Verify PostgreSQL is healthy before starting FR03.3
4. **Port conflicts**: Ensure no other services use ports 5432, 6432, 8002

---

## 🚀 **Deployment Checklist for FR03.3**

### **Pre-deployment**
- [ ] Update FR03.3 docker-compose to use `fr02-network`
- [ ] Mount `chatbot_storage` volume with read-write access
- [ ] Set correct environment variables
- [ ] Implement file preservation logic
- [ ] Update database insert queries with file info

### **Testing**
- [ ] Verify FR03.3 can write to `/opt/chatbot-storage/original/`
- [ ] Test database connection to FR-02.1 PostgreSQL
- [ ] Confirm file preservation creates proper directory structure
- [ ] Validate file download via FR-02.1 File API

### **Production Ready**
- [ ] Implement error handling for file operations
- [ ] Add logging for file preservation activities
- [ ] Set up monitoring for storage usage
- [ ] Configure backup strategy for stored files

---

## 📞 **Support Contacts**

- **Database Issues**: Check FR-02.1 PostgreSQL logs and health
- **Storage Issues**: Verify shared volume mount and permissions
- **API Issues**: Check FR-02.1 File API logs on port 8002
- **Network Issues**: Ensure FR03.3 joins `fr02-network`

---

## 📚 **Reference Documents**
- `update_FR03.3_FR02.1.md` - Detailed technical implementation
- `docker-compose.yml` - Current FR-02.1 configuration
- `scripts/enhanced-schema.sql` - Database schema updates

---

**Document Version**: 1.0
**Last Updated**: 2025-09-15
**Created By**: FR-02.1 Enhancement Team