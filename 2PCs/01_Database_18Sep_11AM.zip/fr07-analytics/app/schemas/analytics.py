from pydantic import BaseModel, Field, validator
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from uuid import UUID
from enum import Enum

class UserLevel(str, Enum):
    GUEST = "Guest"
    EMPLOYEE = "Employee"
    MANAGER = "Manager"
    DIRECTOR = "Director"
    SYSTEM_ADMIN = "System Admin"

class ReportType(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    CUSTOM = "custom"

class ReportFormat(str, Enum):
    PDF = "pdf"
    CSV = "csv"
    EXCEL = "excel"
    JSON = "json"

class ReportStatus(str, Enum):
    PENDING = "pending"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"

# Request Schemas
class SearchAnalyticsQuery(BaseModel):
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    user_level: Optional[UserLevel] = None
    limit: int = Field(default=100, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)

class UserAnalyticsQuery(BaseModel):
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    user_level: Optional[UserLevel] = None
    include_inactive: bool = False

class DocumentAnalyticsQuery(BaseModel):
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    document_type: Optional[str] = None
    min_access_count: int = Field(default=0, ge=0)

class ReportGenerationRequest(BaseModel):
    report_type: ReportType
    report_format: ReportFormat
    sections: List[str] = Field(default=["performance", "users", "documents"])
    date_range: Dict[str, datetime]
    email_delivery: bool = False
    recipients: Optional[List[str]] = None
    custom_parameters: Optional[Dict[str, Any]] = None

# Response Schemas
class SearchAnalyticsResponse(BaseModel):
    total_queries: int
    avg_processing_time_ms: float
    cache_hit_rate: float
    results_by_date: List[Dict[str, Any]]
    top_queries: List[Dict[str, Any]]
    performance_trends: List[Dict[str, Any]]

class UserDistribution(BaseModel):
    Guest: int = 0
    Employee: int = 0
    Manager: int = 0
    Director: int = 0
    System_Admin: int = 0

class UserAnalyticsResponse(BaseModel):
    total_users: int
    active_users: int
    user_distribution: UserDistribution
    engagement_metrics: Dict[str, Any]
    session_analytics: Dict[str, Any]

class DocumentAnalyticsResponse(BaseModel):
    total_documents: int
    accessed_documents: int
    top_documents: List[Dict[str, Any]]
    access_patterns: Dict[str, Any]
    quality_metrics: Dict[str, Any]

class SystemMetricsResponse(BaseModel):
    cpu_usage: float
    memory_usage: float
    response_time_ms: float
    requests_per_second: float
    uptime_percentage: float
    error_rate: float

class ReportGenerationResponse(BaseModel):
    report_id: int
    status: ReportStatus
    estimated_completion: Optional[datetime] = None
    download_url: Optional[str] = None
    file_size: Optional[int] = None

class ReportStatusResponse(BaseModel):
    report_id: int
    status: ReportStatus
    download_url: Optional[str] = None
    generated_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    file_size: Optional[int] = None
    error_message: Optional[str] = None

# Data Models for Analytics
class SearchAnalyticsData(BaseModel):
    id: int
    user_id: Optional[UUID]
    query_text: str
    processing_time_ms: int
    results_count: int
    cache_hit: bool
    timestamp: datetime

class UserActivityData(BaseModel):
    user_id: UUID
    total_queries: int
    avg_session_duration_ms: int
    last_active: Optional[datetime]
    user_level: Optional[str]

class DocumentUsageData(BaseModel):
    document_id: UUID
    access_count: int
    last_accessed: Optional[datetime]
    most_frequent_user_level: Optional[str]

class SystemMetricData(BaseModel):
    id: int
    metric_name: str
    metric_value: float
    metric_unit: Optional[str]
    component: Optional[str]
    timestamp: datetime

# Analytics Summary Models
class PerformanceSummary(BaseModel):
    period: str
    total_queries: int
    avg_response_time_ms: float
    min_response_time_ms: int
    max_response_time_ms: int
    cache_hit_rate: float
    error_rate: float
    throughput_qps: float

class UserEngagementSummary(BaseModel):
    period: str
    total_active_users: int
    new_users: int
    returning_users: int
    avg_queries_per_user: float
    avg_session_duration_ms: int
    user_retention_rate: float

class PopularContent(BaseModel):
    content_id: UUID
    content_title: str
    access_count: int
    unique_users: int
    avg_rating: Optional[float]
    last_accessed: datetime

# Dashboard Widgets
class MetricWidget(BaseModel):
    title: str
    value: Union[int, float, str]
    unit: Optional[str]
    trend: Optional[float]  # percentage change
    trend_period: Optional[str]
    status: Optional[str]  # good, warning, critical

class ChartWidget(BaseModel):
    title: str
    chart_type: str  # line, bar, pie, gauge
    data: List[Dict[str, Any]]
    x_axis: Optional[str]
    y_axis: Optional[str]

class DashboardResponse(BaseModel):
    widgets: List[Union[MetricWidget, ChartWidget]]
    last_updated: datetime
    refresh_interval: int  # seconds

# Error Response
class ErrorResponse(BaseModel):
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None

class HealthCheckResponse(BaseModel):
    status: str
    database: bool
    redis: bool
    services: Dict[str, bool]
    timestamp: datetime