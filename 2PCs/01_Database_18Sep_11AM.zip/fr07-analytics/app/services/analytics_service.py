from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_, desc
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import json
from uuid import UUID

from ..models.analytics import (
    SearchAnalytics, UserActivitySummary, DocumentUsageStats, 
    SystemMetrics, AnalyticsCache
)
from ..schemas.analytics import (
    SearchAnalyticsQuery, UserAnalyticsQuery, DocumentAnalyticsQuery,
    SearchAnalyticsResponse, UserAnalyticsResponse, DocumentAnalyticsResponse,
    SystemMetricsResponse, PerformanceSummary, UserEngagementSummary
)
from ..core.database import redis_manager
from ..core.config import settings
import logging

logger = logging.getLogger(__name__)

class AnalyticsService:
    """Core analytics service for data processing and calculations"""
    
    def __init__(self, db: Session):
        self.db = db
        self.redis = redis_manager.get_client()
        self.cache_ttl = settings.cache_ttl_seconds
    
    def get_search_analytics(self, query: SearchAnalyticsQuery) -> SearchAnalyticsResponse:
        """Get search analytics data with caching"""
        cache_key = f"search_analytics:{hash(str(query))}"
        
        # Try to get from cache first
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            return SearchAnalyticsResponse(**cached_result)
        
        # Build base query
        base_query = self.db.query(SearchAnalytics)
        
        # Apply filters
        if query.start_date:
            base_query = base_query.filter(SearchAnalytics.timestamp >= query.start_date)
        if query.end_date:
            base_query = base_query.filter(SearchAnalytics.timestamp <= query.end_date)
        
        # Calculate metrics
        total_queries = base_query.count()
        
        avg_processing_time = base_query.with_entities(
            func.avg(SearchAnalytics.processing_time_ms)
        ).scalar() or 0.0
        
        cache_hits = base_query.filter(SearchAnalytics.cache_hit == True).count()
        cache_hit_rate = (cache_hits / total_queries) if total_queries > 0 else 0.0
        
        # Get results by date
        results_by_date = self._get_search_results_by_date(base_query)
        
        # Get top queries
        top_queries = self._get_top_queries(base_query, limit=10)
        
        # Get performance trends
        performance_trends = self._get_performance_trends(base_query)
        
        result = SearchAnalyticsResponse(
            total_queries=total_queries,
            avg_processing_time_ms=round(avg_processing_time, 2),
            cache_hit_rate=round(cache_hit_rate, 4),
            results_by_date=results_by_date,
            top_queries=top_queries,
            performance_trends=performance_trends
        )
        
        # Cache the result
        self._set_cache(cache_key, result.dict())
        
        return result
    
    def get_user_analytics(self, query: UserAnalyticsQuery) -> UserAnalyticsResponse:
        """Get user analytics and engagement data"""
        cache_key = f"user_analytics:{hash(str(query))}"
        
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            return UserAnalyticsResponse(**cached_result)
        
        # Build base query for user activity
        base_query = self.db.query(UserActivitySummary)
        
        if query.user_level:
            base_query = base_query.filter(UserActivitySummary.user_level == query.user_level.value)
        
        if not query.include_inactive and query.start_date:
            base_query = base_query.filter(UserActivitySummary.last_active >= query.start_date)
        
        total_users = base_query.count()
        
        # Count active users (users with activity in the date range)
        active_users = base_query.filter(
            UserActivitySummary.last_active >= (query.start_date or datetime.now() - timedelta(days=30))
        ).count()
        
        # Get user distribution by level
        distribution_query = self.db.query(
            UserActivitySummary.user_level,
            func.count(UserActivitySummary.user_id)
        ).group_by(UserActivitySummary.user_level)
        
        user_distribution = {
            "Guest": 0, "Employee": 0, "Manager": 0, "Director": 0, "System_Admin": 0
        }
        
        for level, count in distribution_query.all():
            if level:
                user_distribution[level.replace(" ", "_")] = count
        
        # Calculate engagement metrics
        engagement_metrics = self._calculate_user_engagement(base_query, query)
        
        # Calculate session analytics
        session_analytics = self._calculate_session_analytics(base_query, query)
        
        result = UserAnalyticsResponse(
            total_users=total_users,
            active_users=active_users,
            user_distribution=user_distribution,
            engagement_metrics=engagement_metrics,
            session_analytics=session_analytics
        )
        
        self._set_cache(cache_key, result.dict())
        return result
    
    def get_document_analytics(self, query: DocumentAnalyticsQuery) -> DocumentAnalyticsResponse:
        """Get document usage and popularity analytics"""
        cache_key = f"document_analytics:{hash(str(query))}"
        
        cached_result = self._get_from_cache(cache_key)
        if cached_result:
            return DocumentAnalyticsResponse(**cached_result)
        
        # Build base query
        base_query = self.db.query(DocumentUsageStats)
        
        if query.start_date and query.end_date:
            base_query = base_query.filter(
                and_(
                    DocumentUsageStats.last_accessed >= query.start_date,
                    DocumentUsageStats.last_accessed <= query.end_date
                )
            )
        
        if query.min_access_count > 0:
            base_query = base_query.filter(DocumentUsageStats.access_count >= query.min_access_count)
        
        total_documents = self.db.query(DocumentUsageStats).count()
        accessed_documents = base_query.filter(DocumentUsageStats.access_count > 0).count()
        
        # Get top documents
        top_documents = base_query.order_by(desc(DocumentUsageStats.access_count)).limit(20).all()
        top_documents_data = [
            {
                "document_id": str(doc.document_id),
                "access_count": doc.access_count,
                "last_accessed": doc.last_accessed.isoformat() if doc.last_accessed else None,
                "most_frequent_user_level": doc.most_frequent_user_level
            }
            for doc in top_documents
        ]
        
        # Calculate access patterns
        access_patterns = self._calculate_document_access_patterns(base_query)
        
        # Calculate quality metrics
        quality_metrics = self._calculate_document_quality_metrics(base_query)
        
        result = DocumentAnalyticsResponse(
            total_documents=total_documents,
            accessed_documents=accessed_documents,
            top_documents=top_documents_data,
            access_patterns=access_patterns,
            quality_metrics=quality_metrics
        )
        
        self._set_cache(cache_key, result.dict())
        return result
    
    def get_system_metrics(self) -> SystemMetricsResponse:
        """Get current system performance metrics"""
        cache_key = "system_metrics:current"
        
        cached_result = self._get_from_cache(cache_key, ttl=30)  # Short cache for system metrics
        if cached_result:
            return SystemMetricsResponse(**cached_result)
        
        # Get latest system metrics
        latest_metrics = self.db.query(SystemMetrics).filter(
            SystemMetrics.timestamp >= datetime.now() - timedelta(minutes=5)
        ).all()
        
        metrics_dict = {}
        for metric in latest_metrics:
            metrics_dict[metric.metric_name] = float(metric.metric_value)
        
        # Calculate uptime and error rate from search analytics
        uptime_data = self._calculate_system_uptime()
        error_rate = self._calculate_error_rate()
        
        result = SystemMetricsResponse(
            cpu_usage=metrics_dict.get('cpu_usage', 0.0),
            memory_usage=metrics_dict.get('memory_usage', 0.0),
            response_time_ms=metrics_dict.get('response_time', 0.0),
            requests_per_second=metrics_dict.get('requests_per_second', 0.0),
            uptime_percentage=uptime_data.get('uptime_percentage', 99.0),
            error_rate=error_rate
        )
        
        self._set_cache(cache_key, result.dict(), ttl=30)
        return result
    
    def record_search_analytics(self, user_id: Optional[UUID], query_text: str, 
                              processing_time_ms: int, results_count: int, cache_hit: bool = False):
        """Record a search analytics event"""
        try:
            search_record = SearchAnalytics(
                user_id=user_id,
                query_text=query_text,
                processing_time_ms=processing_time_ms,
                results_count=results_count,
                cache_hit=cache_hit
            )
            self.db.add(search_record)
            self.db.commit()
            
            # Invalidate related caches
            self._invalidate_search_caches()
            
            logger.info(f"Recorded search analytics for query: {query_text[:50]}...")
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to record search analytics: {str(e)}")
            raise
    
    def record_system_metric(self, metric_name: str, metric_value: float, 
                           metric_unit: str = None, component: str = None):
        """Record a system performance metric"""
        try:
            metric_record = SystemMetrics(
                metric_name=metric_name,
                metric_value=metric_value,
                metric_unit=metric_unit,
                component=component
            )
            self.db.add(metric_record)
            self.db.commit()
            
            # Update cache
            cache_key = f"metric:{metric_name}:latest"
            self._set_cache(cache_key, str(metric_value), ttl=60)
            
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to record system metric: {str(e)}")
            raise
    
    # Private helper methods
    def _get_search_results_by_date(self, base_query) -> List[Dict[str, Any]]:
        """Get search results grouped by date"""
        results = base_query.with_entities(
            func.date(SearchAnalytics.timestamp).label('date'),
            func.count(SearchAnalytics.id).label('count'),
            func.avg(SearchAnalytics.processing_time_ms).label('avg_time')
        ).group_by(func.date(SearchAnalytics.timestamp)).order_by('date').all()
        
        return [
            {
                "date": result.date.isoformat(),
                "count": result.count,
                "avg_processing_time_ms": round(float(result.avg_time or 0), 2)
            }
            for result in results
        ]
    
    def _get_top_queries(self, base_query, limit: int = 10) -> List[Dict[str, Any]]:
        """Get most frequent search queries"""
        results = base_query.with_entities(
            SearchAnalytics.query_text,
            func.count(SearchAnalytics.id).label('count'),
            func.avg(SearchAnalytics.processing_time_ms).label('avg_time')
        ).group_by(SearchAnalytics.query_text).order_by(desc('count')).limit(limit).all()
        
        return [
            {
                "query": result.query_text,
                "count": result.count,
                "avg_processing_time_ms": round(float(result.avg_time or 0), 2)
            }
            for result in results
        ]
    
    def _get_performance_trends(self, base_query) -> List[Dict[str, Any]]:
        """Get performance trends over time"""
        results = base_query.with_entities(
            func.date_trunc('hour', SearchAnalytics.timestamp).label('hour'),
            func.avg(SearchAnalytics.processing_time_ms).label('avg_time'),
            func.count(SearchAnalytics.id).label('count')
        ).group_by('hour').order_by('hour').all()
        
        return [
            {
                "hour": result.hour.isoformat(),
                "avg_processing_time_ms": round(float(result.avg_time or 0), 2),
                "query_count": result.count
            }
            for result in results
        ]
    
    def _calculate_user_engagement(self, base_query, query: UserAnalyticsQuery) -> Dict[str, Any]:
        """Calculate user engagement metrics"""
        avg_queries = base_query.with_entities(
            func.avg(UserActivitySummary.total_queries)
        ).scalar() or 0
        
        avg_session_duration = base_query.with_entities(
            func.avg(UserActivitySummary.avg_session_duration_ms)
        ).scalar() or 0
        
        return {
            "avg_queries_per_user": round(float(avg_queries), 2),
            "avg_session_duration_ms": round(float(avg_session_duration), 2),
            "engagement_score": min(100, round(float(avg_queries) * 10, 1))
        }
    
    def _calculate_session_analytics(self, base_query, query: UserAnalyticsQuery) -> Dict[str, Any]:
        """Calculate session-related analytics"""
        return {
            "total_sessions": base_query.count(),
            "avg_session_duration_ms": 0,  # Placeholder - would need session tracking
            "bounce_rate": 0.0,  # Placeholder - would need session tracking
            "return_rate": 0.0   # Placeholder - would need session tracking
        }
    
    def _calculate_document_access_patterns(self, base_query) -> Dict[str, Any]:
        """Calculate document access patterns"""
        # Access by user level
        level_access = self.db.query(
            DocumentUsageStats.most_frequent_user_level,
            func.sum(DocumentUsageStats.access_count)
        ).filter(DocumentUsageStats.most_frequent_user_level.isnot(None))\
         .group_by(DocumentUsageStats.most_frequent_user_level).all()
        
        return {
            "access_by_user_level": {
                level or "Unknown": int(count) for level, count in level_access
            },
            "peak_access_hours": [],  # Placeholder - would need hourly data
            "access_frequency_distribution": {}  # Placeholder
        }
    
    def _calculate_document_quality_metrics(self, base_query) -> Dict[str, Any]:
        """Calculate document quality metrics"""
        total_access = base_query.with_entities(
            func.sum(DocumentUsageStats.access_count)
        ).scalar() or 0
        
        unique_documents = base_query.filter(DocumentUsageStats.access_count > 0).count()
        
        return {
            "total_accesses": int(total_access),
            "unique_accessed_documents": unique_documents,
            "avg_accesses_per_document": round(float(total_access / unique_documents if unique_documents > 0 else 0), 2),
            "document_popularity_score": min(100, round(float(total_access / 1000), 1))
        }
    
    def _calculate_system_uptime(self) -> Dict[str, Any]:
        """Calculate system uptime from metrics"""
        # This would typically come from external monitoring
        return {"uptime_percentage": 99.5}
    
    def _calculate_error_rate(self) -> float:
        """Calculate error rate from search analytics"""
        # Placeholder - would need error tracking in search analytics
        return 0.01
    
    def _get_from_cache(self, key: str, ttl: int = None) -> Optional[Dict[str, Any]]:
        """Get data from Redis cache"""
        try:
            cached_data = redis_manager.get_cache(key)
            if cached_data:
                return json.loads(cached_data)
        except Exception as e:
            logger.warning(f"Cache get failed for key {key}: {str(e)}")
        return None
    
    def _set_cache(self, key: str, data: Dict[str, Any], ttl: int = None) -> bool:
        """Set data in Redis cache"""
        try:
            ttl = ttl or self.cache_ttl
            return redis_manager.set_cache(key, json.dumps(data, default=str), ttl)
        except Exception as e:
            logger.warning(f"Cache set failed for key {key}: {str(e)}")
            return False
    
    def _invalidate_search_caches(self):
        """Invalidate search analytics related caches"""
        try:
            redis_manager.flush_pattern("search_analytics:*")
            redis_manager.flush_pattern("system_metrics:*")
        except Exception as e:
            logger.warning(f"Cache invalidation failed: {str(e)}")