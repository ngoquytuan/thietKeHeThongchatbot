from pydantic_settings import BaseSettings
from typing import Optional
import os

class Settings(BaseSettings):
    # Database Configuration
    database_url: str = "postgresql://user:password@localhost:5432/rag_db"
    db_host: str = "localhost"
    db_port: int = 5432
    db_user: str = "user"
    db_password: str = "password"
    db_name: str = "rag_db"
    
    # Redis Configuration
    redis_url: str = "redis://localhost:6379"
    redis_host: str = "localhost"
    redis_port: int = 6379
    
    # API Configuration
    api_host: str = "0.0.0.0"
    api_port: int = 8001
    api_reload: bool = False
    
    # Dashboard Configuration
    dashboard_host: str = "0.0.0.0"
    dashboard_port: int = 8501
    
    # JWT Configuration
    secret_key: str = "your-secret-key-here"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # Prometheus Configuration
    prometheus_multiproc_dir: str = "/tmp"
    
    # Logging Configuration
    log_level: str = "INFO"
    log_format: str = "json"
    
    # Report Storage
    reports_path: str = "/app/reports"
    
    # External Services
    grafana_url: str = "http://grafana:3000"
    prometheus_url: str = "http://prometheus:9090"
    
    # Analytics Configuration
    cache_ttl_seconds: int = 300  # 5 minutes
    max_query_results: int = 1000
    report_retention_days: int = 90
    
    # Performance Settings
    db_pool_size: int = 10
    db_max_overflow: int = 20
    api_workers: int = 4
    
    class Config:
        env_file = ".env"
        case_sensitive = False

# Global settings instance
settings = Settings()