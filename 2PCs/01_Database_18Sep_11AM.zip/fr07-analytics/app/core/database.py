from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from typing import Generator
import redis
from .config import settings

# Database Engine
engine = create_engine(
    settings.database_url,
    poolclass=QueuePool,
    pool_size=settings.db_pool_size,
    max_overflow=settings.db_max_overflow,
    pool_pre_ping=True,
    echo=False
)

# Session Factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base Model
Base = declarative_base()

# Redis Connection
redis_client = redis.Redis.from_url(
    settings.redis_url,
    decode_responses=True,
    socket_connect_timeout=5,
    socket_timeout=5,
    retry_on_timeout=True
)

def get_db() -> Generator[Session, None, None]:
    """Database dependency for FastAPI endpoints"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_redis() -> redis.Redis:
    """Redis dependency for caching"""
    return redis_client

class DatabaseManager:
    """Database connection and session management"""
    
    def __init__(self):
        self.engine = engine
        self.SessionLocal = SessionLocal
    
    def get_session(self) -> Session:
        """Get a new database session"""
        return self.SessionLocal()
    
    def close_session(self, db: Session):
        """Close database session"""
        db.close()
    
    def health_check(self) -> bool:
        """Check database connection health"""
        try:
            with self.engine.connect() as connection:
                connection.execute("SELECT 1")
                return True
        except Exception:
            return False

class RedisManager:
    """Redis connection and caching management"""
    
    def __init__(self):
        self.client = redis_client
    
    def get_client(self) -> redis.Redis:
        """Get Redis client"""
        return self.client
    
    def health_check(self) -> bool:
        """Check Redis connection health"""
        try:
            self.client.ping()
            return True
        except Exception:
            return False
    
    def set_cache(self, key: str, value: str, ttl: int = None) -> bool:
        """Set cache value with optional TTL"""
        try:
            if ttl:
                return self.client.setex(key, ttl, value)
            else:
                return self.client.set(key, value)
        except Exception:
            return False
    
    def get_cache(self, key: str) -> str:
        """Get cache value"""
        try:
            return self.client.get(key)
        except Exception:
            return None
    
    def delete_cache(self, key: str) -> bool:
        """Delete cache key"""
        try:
            return bool(self.client.delete(key))
        except Exception:
            return False
    
    def flush_pattern(self, pattern: str) -> int:
        """Delete all keys matching pattern"""
        try:
            keys = self.client.keys(pattern)
            if keys:
                return self.client.delete(*keys)
            return 0
        except Exception:
            return 0

# Global instances
db_manager = DatabaseManager()
redis_manager = RedisManager()