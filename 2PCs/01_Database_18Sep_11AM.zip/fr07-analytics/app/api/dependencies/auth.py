from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional, List
from pydantic import BaseModel

from ...core.config import settings

# Security scheme
security = HTTPBearer()

# Token data model
class TokenData(BaseModel):
    user_id: Optional[str] = None
    user_level: Optional[str] = None
    permissions: List[str] = []

# User model for authentication
class CurrentUser(BaseModel):
    user_id: str
    user_level: str
    permissions: List[str]

# Role-based permissions mapping
ROLE_PERMISSIONS = {
    "System Admin": [
        "analytics:read",
        "analytics:write", 
        "reports:generate",
        "reports:read",
        "system:monitor",
        "users:manage"
    ],
    "Director": [
        "analytics:read",
        "reports:generate", 
        "reports:read",
        "system:monitor"
    ],
    "Manager": [
        "analytics:read",
        "reports:generate",
        "reports:read"
    ],
    "Employee": [
        "analytics:read:limited"
    ],
    "Guest": []
}

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.access_token_expire_minutes)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
    return encoded_jwt

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> TokenData:
    """Verify and decode JWT token"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            credentials.credentials, 
            settings.secret_key, 
            algorithms=[settings.algorithm]
        )
        user_id: str = payload.get("sub")
        user_level: str = payload.get("user_level", "Guest")
        
        if user_id is None:
            raise credentials_exception
        
        # Get permissions based on user level
        permissions = ROLE_PERMISSIONS.get(user_level, [])
        
        return TokenData(
            user_id=user_id,
            user_level=user_level,
            permissions=permissions
        )
    except JWTError:
        raise credentials_exception

def get_current_user(token_data: TokenData = Depends(verify_token)) -> CurrentUser:
    """Get current user from token"""
    return CurrentUser(
        user_id=token_data.user_id,
        user_level=token_data.user_level,
        permissions=token_data.permissions
    )

def require_permission(required_permission: str):
    """Decorator to require specific permission"""
    def permission_checker(current_user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if required_permission not in current_user.permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission '{required_permission}' required"
            )
        return current_user
    return permission_checker

def require_role(required_roles: List[str]):
    """Decorator to require specific roles"""
    def role_checker(current_user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if current_user.user_level not in required_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role must be one of: {', '.join(required_roles)}"
            )
        return current_user
    return role_checker

# Convenience functions for common role requirements
def require_admin():
    """Require System Admin role"""
    return require_role(["System Admin"])

def require_management():
    """Require Manager, Director, or System Admin role"""
    return require_role(["Manager", "Director", "System Admin"])

def require_analytics_access():
    """Require analytics read permission"""
    return require_permission("analytics:read")

def require_report_access():
    """Require report generation permission"""
    return require_permission("reports:generate")

def require_system_access():
    """Require system monitoring permission"""
    return require_permission("system:monitor")