from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime, timedelta

from ...core.database import get_db
from ...schemas.analytics import (
    SearchAnalyticsQuery, UserAnalyticsQuery, DocumentAnalyticsQuery,
    SearchAnalyticsResponse, UserAnalyticsResponse, DocumentAnalyticsResponse,
    SystemMetricsResponse, UserLevel
)
from ...services.analytics_service import AnalyticsService
from ..dependencies.auth import (
    require_analytics_access, require_management, require_system_access,
    CurrentUser
)

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

@router.get("/search", response_model=SearchAnalyticsResponse)
async def get_search_analytics(
    start_date: Optional[datetime] = Query(None, description="Start date for analytics period"),
    end_date: Optional[datetime] = Query(None, description="End date for analytics period"),
    user_level: Optional[UserLevel] = Query(None, description="Filter by user level"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of results"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_management())
):
    """
    Get search analytics data including query performance, cache hit rates, and trends.
    
    Accessible by: Manager, Director, System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        query = SearchAnalyticsQuery(
            start_date=start_date,
            end_date=end_date,
            user_level=user_level,
            limit=limit,
            offset=offset
        )
        return analytics_service.get_search_analytics(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve search analytics: {str(e)}")

@router.get("/users", response_model=UserAnalyticsResponse)
async def get_user_analytics(
    start_date: Optional[datetime] = Query(None, description="Start date for analytics period"),
    end_date: Optional[datetime] = Query(None, description="End date for analytics period"),
    user_level: Optional[UserLevel] = Query(None, description="Filter by user level"),
    include_inactive: bool = Query(False, description="Include inactive users"),
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_management())
):
    """
    Get user analytics data including activity patterns, engagement metrics, and distribution.
    
    Accessible by: Manager, Director, System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        query = UserAnalyticsQuery(
            start_date=start_date,
            end_date=end_date,
            user_level=user_level,
            include_inactive=include_inactive
        )
        return analytics_service.get_user_analytics(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve user analytics: {str(e)}")

@router.get("/documents", response_model=DocumentAnalyticsResponse)
async def get_document_analytics(
    start_date: Optional[datetime] = Query(None, description="Start date for analytics period"),
    end_date: Optional[datetime] = Query(None, description="End date for analytics period"),
    document_type: Optional[str] = Query(None, description="Filter by document type"),
    min_access_count: int = Query(0, ge=0, description="Minimum access count filter"),
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_management())
):
    """
    Get document analytics data including usage patterns, popularity, and quality metrics.
    
    Accessible by: Manager, Director, System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        query = DocumentAnalyticsQuery(
            start_date=start_date,
            end_date=end_date,
            document_type=document_type,
            min_access_count=min_access_count
        )
        return analytics_service.get_document_analytics(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve document analytics: {str(e)}")

@router.get("/system", response_model=SystemMetricsResponse)
async def get_system_metrics(
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_system_access())
):
    """
    Get current system performance metrics including CPU, memory, response time, and uptime.
    
    Accessible by: System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        return analytics_service.get_system_metrics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve system metrics: {str(e)}")

@router.get("/health")
async def health_check(db: Session = Depends(get_db)):
    """
    Health check endpoint for monitoring service availability.
    
    Accessible by: All authenticated users
    """
    try:
        # Test database connection
        db.execute("SELECT 1")
        
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow(),
            "service": "analytics",
            "version": "1.0.0"
        }
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Service unavailable: {str(e)}")

@router.get("/summary")
async def get_analytics_summary(
    period: str = Query("24h", regex="^(1h|24h|7d|30d)$", description="Time period for summary"),
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_analytics_access())
):
    """
    Get summarized analytics data for quick overview.
    
    Accessible by: Manager, Director, System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        
        # Calculate date range based on period
        now = datetime.utcnow()
        period_map = {
            "1h": timedelta(hours=1),
            "24h": timedelta(days=1),
            "7d": timedelta(days=7),
            "30d": timedelta(days=30)
        }
        start_date = now - period_map[period]
        
        # Get basic analytics
        search_query = SearchAnalyticsQuery(start_date=start_date, end_date=now, limit=1000)
        user_query = UserAnalyticsQuery(start_date=start_date, end_date=now)
        doc_query = DocumentAnalyticsQuery(start_date=start_date, end_date=now)
        
        search_analytics = analytics_service.get_search_analytics(search_query)
        user_analytics = analytics_service.get_user_analytics(user_query)
        document_analytics = analytics_service.get_document_analytics(doc_query)
        system_metrics = analytics_service.get_system_metrics()
        
        return {
            "period": period,
            "summary": {
                "total_queries": search_analytics.total_queries,
                "avg_response_time_ms": search_analytics.avg_processing_time_ms,
                "cache_hit_rate": search_analytics.cache_hit_rate,
                "active_users": user_analytics.active_users,
                "total_users": user_analytics.total_users,
                "accessed_documents": document_analytics.accessed_documents,
                "cpu_usage": system_metrics.cpu_usage,
                "memory_usage": system_metrics.memory_usage,
                "uptime_percentage": system_metrics.uptime_percentage
            },
            "generated_at": now
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate analytics summary: {str(e)}")

@router.post("/record/search")
async def record_search_event(
    query_text: str,
    processing_time_ms: int,
    results_count: int,
    cache_hit: bool = False,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_analytics_access())
):
    """
    Record a search analytics event.
    
    This endpoint is typically called by the RAG Core system to log search events.
    """
    try:
        analytics_service = AnalyticsService(db)
        analytics_service.record_search_analytics(
            user_id=current_user.user_id,
            query_text=query_text,
            processing_time_ms=processing_time_ms,
            results_count=results_count,
            cache_hit=cache_hit
        )
        return {"status": "recorded", "timestamp": datetime.utcnow()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to record search event: {str(e)}")

@router.post("/record/metric")
async def record_system_metric(
    metric_name: str,
    metric_value: float,
    metric_unit: Optional[str] = None,
    component: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: CurrentUser = Depends(require_system_access())
):
    """
    Record a system performance metric.
    
    Accessible by: System Admin
    """
    try:
        analytics_service = AnalyticsService(db)
        analytics_service.record_system_metric(
            metric_name=metric_name,
            metric_value=metric_value,
            metric_unit=metric_unit,
            component=component
        )
        return {"status": "recorded", "timestamp": datetime.utcnow()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to record system metric: {str(e)}")