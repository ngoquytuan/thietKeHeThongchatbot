from sqlalchemy import Column, Integer, String, Text, Boolean, TIMESTAMP, UUID, DECIMAL, BigInteger, Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional
import uuid

Base = declarative_base()

class SearchAnalytics(Base):
    """Search query analytics and performance metrics"""
    __tablename__ = "search_analytics"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(UUID(as_uuid=True), nullable=True)
    query_text = Column(Text, nullable=False)
    processing_time_ms = Column(Integer, nullable=False)
    results_count = Column(Integer, nullable=False)
    cache_hit = Column(Boolean, default=False)
    timestamp = Column(TIMESTAMP(timezone=True), server_default=func.now())
    
    __table_args__ = (
        Index('idx_search_analytics_timestamp', 'timestamp'),
        Index('idx_search_analytics_user_id', 'user_id'),
        Index('idx_search_analytics_cache_hit', 'cache_hit'),
    )

class UserActivitySummary(Base):
    """User activity and engagement summary"""
    __tablename__ = "user_activity_summary"
    
    user_id = Column(UUID(as_uuid=True), primary_key=True)
    total_queries = Column(Integer, default=0)
    avg_session_duration_ms = Column(Integer, default=0)
    last_active = Column(TIMESTAMP(timezone=True))
    user_level = Column(String(20), nullable=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

class DocumentUsageStats(Base):
    """Document access patterns and usage statistics"""
    __tablename__ = "document_usage_stats"
    
    document_id = Column(UUID(as_uuid=True), primary_key=True)
    access_count = Column(Integer, default=0)
    last_accessed = Column(TIMESTAMP(timezone=True))
    most_frequent_user_level = Column(String(20), nullable=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        Index('idx_document_usage_access_count', 'access_count'),
        Index('idx_document_usage_last_accessed', 'last_accessed'),
    )

class SystemMetrics(Base):
    """System performance and resource utilization metrics"""
    __tablename__ = "system_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    metric_name = Column(String(100), nullable=False)
    metric_value = Column(DECIMAL(10, 4), nullable=False)
    metric_unit = Column(String(20))
    component = Column(String(50))
    timestamp = Column(TIMESTAMP(timezone=True), server_default=func.now())
    
    __table_args__ = (
        Index('idx_system_metrics_timestamp', 'timestamp'),
        Index('idx_system_metrics_name', 'metric_name'),
        Index('idx_system_metrics_component', 'component'),
    )

class ReportGeneration(Base):
    """Report generation requests and status tracking"""
    __tablename__ = "report_generation"
    
    report_id = Column(Integer, primary_key=True, index=True)
    report_type = Column(String(50), nullable=False)
    report_format = Column(String(20), nullable=False)
    report_status = Column(String(20), default='pending')
    file_path = Column(String(255))
    file_size = Column(BigInteger)
    generated_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    completed_at = Column(TIMESTAMP(timezone=True))
    user_id = Column(UUID(as_uuid=True))
    parameters = Column(JSONB)
    error_message = Column(Text)
    
    __table_args__ = (
        Index('idx_report_generation_status', 'report_status'),
        Index('idx_report_generation_type', 'report_type'),
        Index('idx_report_generation_user', 'user_id'),
        Index('idx_report_generation_generated_at', 'generated_at'),
    )

class AnalyticsCache(Base):
    """Pre-computed analytics data for improved performance"""
    __tablename__ = "analytics_cache"
    
    cache_key = Column(String(255), primary_key=True)
    cache_value = Column(JSONB, nullable=False)
    cache_type = Column(String(50), nullable=False)
    expires_at = Column(TIMESTAMP(timezone=True), nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())
    
    __table_args__ = (
        Index('idx_analytics_cache_expires', 'expires_at'),
        Index('idx_analytics_cache_type', 'cache_type'),
    )