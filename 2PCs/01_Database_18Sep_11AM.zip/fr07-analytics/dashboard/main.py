import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json
from typing import Dict, Any, Optional
import time

# Page configuration
st.set_page_config(
    page_title="RAG Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Configuration
API_BASE_URL = "http://analytics-api:8000"  # Docker service name
DEFAULT_TOKEN = "dummy-token-for-demo"  # In production, implement proper authentication

class DashboardAPI:
    """API client for analytics data"""
    
    def __init__(self, base_url: str, token: str):
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {token}"}
    
    def get_search_analytics(self, start_date: datetime, end_date: datetime, 
                           user_level: str = None) -> Optional[Dict[str, Any]]:
        """Get search analytics data"""
        params = {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "limit": 1000
        }
        if user_level and user_level != "All":
            params["user_level"] = user_level
        
        try:
            response = requests.get(
                f"{self.base_url}/api/analytics/search",
                headers=self.headers,
                params=params,
                timeout=10
            )
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            st.error(f"Failed to fetch search analytics: {str(e)}")
            return None
    
    def get_user_analytics(self, start_date: datetime, end_date: datetime) -> Optional[Dict[str, Any]]:
        """Get user analytics data"""
        params = {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        
        try:
            response = requests.get(
                f"{self.base_url}/api/analytics/users",
                headers=self.headers,
                params=params,
                timeout=10
            )
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            st.error(f"Failed to fetch user analytics: {str(e)}")
            return None
    
    def get_document_analytics(self, start_date: datetime, end_date: datetime) -> Optional[Dict[str, Any]]:
        """Get document analytics data"""
        params = {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat()
        }
        
        try:
            response = requests.get(
                f"{self.base_url}/api/analytics/documents",
                headers=self.headers,
                params=params,
                timeout=10
            )
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            st.error(f"Failed to fetch document analytics: {str(e)}")
            return None
    
    def get_system_metrics(self) -> Optional[Dict[str, Any]]:
        """Get system metrics data"""
        try:
            response = requests.get(
                f"{self.base_url}/api/analytics/system",
                headers=self.headers,
                timeout=10
            )
            return response.json() if response.status_code == 200 else None
        except Exception as e:
            st.error(f"Failed to fetch system metrics: {str(e)}")
            return None
    
    def health_check(self) -> bool:
        """Check if API is healthy"""
        try:
            response = requests.get(f"{self.base_url}/health", timeout=5)
            return response.status_code == 200
        except:
            return False

def create_metric_card(title: str, value: str, delta: Optional[str] = None, delta_color: str = "normal"):
    """Create a metric card"""
    st.metric(
        label=title,
        value=value,
        delta=delta,
        delta_color=delta_color
    )

def create_gauge_chart(title: str, value: float, max_value: float = 100, 
                      color: str = "blue", unit: str = "%"):
    """Create a gauge chart"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=value,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title},
        delta={'reference': max_value * 0.8},
        gauge={
            'axis': {'range': [None, max_value]},
            'bar': {'color': color},
            'steps': [
                {'range': [0, max_value * 0.6], 'color': "lightgray"},
                {'range': [max_value * 0.6, max_value * 0.8], 'color': "yellow"},
                {'range': [max_value * 0.8, max_value], 'color': "lightgreen"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': max_value * 0.9
            }
        }
    ))
    fig.update_layout(height=300)
    return fig

def main():
    """Main dashboard function"""
    st.title("📊 RAG Knowledge Assistant Analytics")
    st.markdown("---")
    
    # Initialize API client
    api = DashboardAPI(API_BASE_URL, DEFAULT_TOKEN)
    
    # Check API health
    if not api.health_check():
        st.error("⚠️ Analytics API is not available. Please check the service.")
        st.stop()
    
    # Sidebar filters
    st.sidebar.header("🎛️ Dashboard Filters")
    
    # Date range selection
    date_range = st.sidebar.selectbox(
        "Time Period",
        ["Last 24 Hours", "Last 7 Days", "Last 30 Days", "Custom Range"]
    )
    
    if date_range == "Custom Range":
        start_date = st.sidebar.date_input("Start Date", datetime.now() - timedelta(days=7))
        end_date = st.sidebar.date_input("End Date", datetime.now())
    else:
        days_map = {
            "Last 24 Hours": 1,
            "Last 7 Days": 7,
            "Last 30 Days": 30
        }
        days = days_map[date_range]
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
    
    # Convert to datetime objects
    start_datetime = datetime.combine(start_date, datetime.min.time()) if hasattr(start_date, 'date') else start_date
    end_datetime = datetime.combine(end_date, datetime.max.time()) if hasattr(end_date, 'date') else end_date
    
    # User level filter
    user_level = st.sidebar.selectbox(
        "User Level",
        ["All", "Guest", "Employee", "Manager", "Director", "System Admin"]
    )
    
    # Auto-refresh
    auto_refresh = st.sidebar.checkbox("Auto Refresh (30s)")
    if auto_refresh:
        time.sleep(30)
        st.experimental_rerun()
    
    # Refresh button
    if st.sidebar.button("🔄 Refresh Data"):
        st.experimental_rerun()
    
    # Fetch data
    with st.spinner("Loading analytics data..."):
        search_data = api.get_search_analytics(start_datetime, end_datetime, user_level)
        user_data = api.get_user_analytics(start_datetime, end_datetime)
        document_data = api.get_document_analytics(start_datetime, end_datetime)
        system_data = api.get_system_metrics()
    
    # Overview Section
    st.header("📈 Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if search_data:
            create_metric_card(
                "Total Queries",
                f"{search_data.get('total_queries', 0):,}",
                "+12% vs last period"
            )
        else:
            create_metric_card("Total Queries", "N/A")
    
    with col2:
        if search_data:
            create_metric_card(
                "Avg Response Time",
                f"{search_data.get('avg_processing_time_ms', 0):.0f}ms",
                "-5ms vs last period",
                "inverse"
            )
        else:
            create_metric_card("Avg Response Time", "N/A")
    
    with col3:
        if user_data:
            create_metric_card(
                "Active Users",
                f"{user_data.get('active_users', 0):,}",
                "+8% vs last period"
            )
        else:
            create_metric_card("Active Users", "N/A")
    
    with col4:
        if search_data:
            cache_hit_rate = search_data.get('cache_hit_rate', 0) * 100
            create_metric_card(
                "Cache Hit Rate",
                f"{cache_hit_rate:.1f}%",
                "+2.1% vs last period"
            )
        else:
            create_metric_card("Cache Hit Rate", "N/A")
    
    # Performance Section
    st.header("⚡ Performance Metrics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if search_data and search_data.get('results_by_date'):
            # Response time trend
            df_trend = pd.DataFrame(search_data['results_by_date'])
            df_trend['date'] = pd.to_datetime(df_trend['date'])
            
            fig = px.line(
                df_trend,
                x='date',
                y='avg_processing_time_ms',
                title='Response Time Trend',
                labels={'avg_processing_time_ms': 'Response Time (ms)', 'date': 'Date'}
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No performance trend data available")
    
    with col2:
        if search_data and search_data.get('results_by_date'):
            # Query volume
            fig = px.bar(
                df_trend,
                x='date',
                y='count',
                title='Query Volume',
                labels={'count': 'Number of Queries', 'date': 'Date'}
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No query volume data available")
    
    # System Health Section
    st.header("🖥️ System Health")
    
    col1, col2, col3, col4 = st.columns(4)
    
    if system_data:
        with col1:
            cpu_fig = create_gauge_chart(
                "CPU Usage",
                system_data.get('cpu_usage', 0),
                100,
                "blue",
                "%"
            )
            st.plotly_chart(cpu_fig, use_container_width=True)
        
        with col2:
            memory_fig = create_gauge_chart(
                "Memory Usage",
                system_data.get('memory_usage', 0),
                100,
                "green",
                "%"
            )
            st.plotly_chart(memory_fig, use_container_width=True)
        
        with col3:
            uptime_fig = create_gauge_chart(
                "Uptime",
                system_data.get('uptime_percentage', 99.5),
                100,
                "orange",
                "%"
            )
            st.plotly_chart(uptime_fig, use_container_width=True)
        
        with col4:
            error_rate = system_data.get('error_rate', 0) * 100
            error_fig = create_gauge_chart(
                "Error Rate",
                error_rate,
                5,
                "red",
                "%"
            )
            st.plotly_chart(error_fig, use_container_width=True)
    
    # User Analytics Section
    st.header("👥 User Analytics")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if user_data and user_data.get('user_distribution'):
            # User distribution pie chart
            distribution = user_data['user_distribution']
            labels = list(distribution.keys())
            values = list(distribution.values())
            
            fig = px.pie(
                values=values,
                names=labels,
                title='User Distribution by Role'
            )
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No user distribution data available")
    
    with col2:
        if search_data and search_data.get('top_queries'):
            # Top queries
            st.subheader("🔍 Top Search Queries")
            top_queries = search_data['top_queries'][:10]
            
            for i, query in enumerate(top_queries, 1):
                st.write(f"**{i}.** {query.get('query', 'Unknown')}")
                st.write(f"   └── {query.get('count', 0)} queries, {query.get('avg_processing_time_ms', 0):.0f}ms avg")
        else:
            st.info("No top queries data available")
    
    # Document Analytics Section
    st.header("📄 Document Analytics")
    
    if document_data:
        col1, col2 = st.columns(2)
        
        with col1:
            # Document access metrics
            st.subheader("📊 Document Metrics")
            total_docs = document_data.get('total_documents', 0)
            accessed_docs = document_data.get('accessed_documents', 0)
            access_rate = (accessed_docs / total_docs * 100) if total_docs > 0 else 0
            
            st.metric("Total Documents", f"{total_docs:,}")
            st.metric("Accessed Documents", f"{accessed_docs:,}")
            st.metric("Access Rate", f"{access_rate:.1f}%")
        
        with col2:
            # Top documents
            if document_data.get('top_documents'):
                st.subheader("📈 Most Accessed Documents")
                top_docs = document_data['top_documents'][:10]
                
                doc_df = pd.DataFrame([
                    {
                        'Document ID': doc.get('document_id', 'Unknown')[:8] + '...',
                        'Access Count': doc.get('access_count', 0),
                        'User Level': doc.get('most_frequent_user_level', 'Unknown')
                    }
                    for doc in top_docs
                ])
                
                st.dataframe(doc_df, hide_index=True)
    
    # Footer
    st.markdown("---")
    st.markdown(
        f"**Last Updated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | "
        f"**Data Range:** {start_datetime.strftime('%Y-%m-%d')} to {end_datetime.strftime('%Y-%m-%d')}"
    )

if __name__ == "__main__":
    main()