# Tài liệu Thiết kế Module FR-08: Admin & Maintenance Tools

**📅 Ngày:** 09/09/2025  
**👨‍💼 Người soạn thảo:** [Tên bạn]  
**🏗️ Dự án:** Hệ thống Trợ lý Tri thức AI (RAG Knowledge Assistant)  
**📋 Module:** FR-08 - Admin & Maintenance Tools  
**📊 Trạng thái:** Thiết kế ban đầu, chờ phê duyệt  

---

## 1. Mục đích của Module

Module **FR-08: Admin & Maintenance Tools** cung cấp các công cụ và giao diện cho quản trị viên (System Admin) để:
- **Giám sát hệ thống**: Theo dõi hiệu suất (CPU, RAM, throughput), trạng thái container, và lỗi runtime.
- **Bảo trì cơ sở dữ liệu**: Quản lý, tối ưu hóa, và sao lưu cơ sở dữ liệu (PostgreSQL, ChromaDB).
- **Xử lý lỗi**: Phát hiện, ghi log, và khắc phục lỗi hệ thống (như lỗi truy vấn, timeout).
- **Quản trị người dùng và tài liệu**: Xem, chỉnh sửa thông tin người dùng (`users`) và metadata tài liệu (`documents_metadata_v2`).

Module này hỗ trợ đội kỹ thuật duy trì hệ thống ổn định, đảm bảo uptime ≥ 99.5%, và cung cấp giao diện quản trị tiện lợi cho System Admin.

---

## 2. Yêu cầu Chức năng

Dựa trên tài liệu `update_docs_handovers.md` và schema SQL, module FR-08 bao gồm các chức năng sau:

### 2.1. Giám sát Hệ thống
- Theo dõi các chỉ số hiệu suất từ bảng `system_metrics`:
  - `response_time_ms`, `cpu_usage_percent`, `memory_usage_mb`, `disk_io`, `network_throughput`.
- Tích hợp với **Prometheus** và **Grafana** để hiển thị dashboard giám sát:
  - CPU/memory usage theo container (Docker).
  - Số lượng yêu cầu API (`/api/ask`, `/api/documents`).
  - Tỷ lệ lỗi (HTTP 500, timeout).
- Cảnh báo khi vượt ngưỡng: CPU > 80%, memory > 90%, hoặc response time > 2s.

### 2.2. Bảo trì Cơ sở Dữ liệu
- **PostgreSQL**:
  - Quản lý bảng: `users`, `documents_metadata_v2`, `search_analytics`, `system_metrics`.
  - Tối ưu hóa index: `ANALYZE`, `REINDEX` cho `search_analytics`, `documents_metadata_v2`.
  - Sao lưu/ khôi phục: Sử dụng `pg_dump` và `pg_restore`.
- **ChromaDB**:
  - Xóa cache hoặc tối ưu hóa bộ sưu tập (collections) khi cần.
  - Kiểm tra tính toàn vẹn của vector embeddings.
- Giao diện quản trị: Sử dụng **Adminer** hoặc API tùy chỉnh để truy cập và chỉnh sửa cơ sở dữ liệu.

### 2.3. Xử lý Lỗi
- Ghi log lỗi từ **FR-04 (RAG Core)**, **FR-02.2 (API Quản trị)**, và hạ tầng:
  - Lỗi truy vấn (timeout, invalid query).
  - Lỗi cơ sở dữ liệu (connection pool full, index corruption).
- Giao diện để xem và phân tích log (dùng `loguru` hoặc Grafana Loki).
- Công cụ để khởi động lại container hoặc dịch vụ khi lỗi xảy ra.

### 2.4. Quản trị Người dùng và Tài liệu
- **Quản lý người dùng**:
  - Xem, chỉnh sửa, xóa thông tin từ bảng `users` (email, user_level, password_hash).
  - Gán quyền RBAC (Guest, Employee, Manager, Director, System Admin).
- **Quản lý tài liệu**:
  - Xem, chỉnh sửa metadata từ `documents_metadata_v2` (title, category, created_at).
  - Xóa hoặc đánh dấu tài liệu không còn sử dụng (`is_active = FALSE`).
- API endpoint: `/api/admin/users`, `/api/admin/documents`.

### 2.5. Tích hợp với Hệ thống
- Kết nối với **FR-02.1 (Hệ thống CSDL kép)** để truy cập PostgreSQL và ChromaDB.
- Tích hợp với **FR-06 (Bảo mật và Phân quyền)** để giới hạn quyền truy cập (chỉ System Admin).
- Tích hợp với **External Services** (Prometheus, Grafana, Loki) để giám sát và phân tích log.
- Hỗ trợ **FR-07 (Analytics & Reporting)** bằng cách cung cấp metrics hệ thống cho báo cáo.

---

## 3. Yêu cầu Phi Chức năng

- **Hiệu suất**:
  - Thời gian phản hồi API quản trị: < 1 giây cho 1,000 bản ghi.
  - Hỗ trợ 10 System Admin truy cập đồng thời.
- **Bảo mật**:
  - Chỉ System Admin truy cập được các endpoint `/api/admin/*` (JWT + RBAC).
  - Dữ liệu nhạy cảm (`password_hash`, `email`) được mã hóa hoặc ẩn (content masking).
- **Khả năng mở rộng**:
  - Hỗ trợ giám sát ≥ 50 container Docker.
  - Tương thích với PostgreSQL read replica và ChromaDB cluster.
- **Tính sẵn sàng**: Uptime ≥ 99.5%, tích hợp với Prometheus/Grafana để cảnh báo.

---

## 4. Công nghệ Sử dụng

Dựa trên danh sách công nghệ và tài liệu `update_docs_handovers.md`:

| **Component**         | **Công nghệ**                     | **Version** | **Lý do lựa chọn**                     |
|-----------------------|-----------------------------------|-------------|---------------------------------------|
| **Backend API**       | FastAPI                          | 0.104.1+    | Hiệu suất cao, async, tích hợp dễ     |
| **Database**          | PostgreSQL, ChromaDB             | 15+, 1.0.0  | Hỗ trợ SQL và vector DB               |
| **DB Management**     | Adminer                          | Latest      | Giao diện quản trị DB nhẹ, dễ dùng    |
| **Monitoring**        | Prometheus, Grafana, prometheus-client | 0.17.0 | Giám sát metrics và dashboard         |
| **Logging**           | loguru, Grafana Loki             | Latest      | Ghi và phân tích log cấu trúc         |
| **Deployment**        | Docker, Docker Compose           | 20.10+      | Container hóa, dễ triển khai          |

**Môi trường triển khai**: Python 3.11 + Docker + Ubuntu

---

## 5. Thiết kế Kỹ thuật

### 5.1. Schema Cơ sở Dữ liệu
Các bảng liên quan đến FR-08 từ schema SQL:

- **`system_metrics`**:
  ```sql
  CREATE TABLE system_metrics (
      id SERIAL PRIMARY KEY,
      container_id VARCHAR(64),
      response_time_ms INTEGER,
      cpu_usage_percent FLOAT,
      memory_usage_mb FLOAT,
      disk_io FLOAT,
      network_throughput FLOAT,
      timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  );
  ```
  - Lưu trữ metrics hệ thống từ Docker containers.
  - Index: `CREATE INDEX idx_system_metrics_timestamp ON system_metrics(timestamp);`

- **`users`** (liên quan đến quản trị người dùng):
  ```sql
  CREATE TABLE users (
      id UUID PRIMARY KEY,
      email VARCHAR(255) UNIQUE,
      password_hash VARCHAR(255),
      user_level VARCHAR(20) CHECK (user_level IN ('Guest', 'Employee', 'Manager', 'Director', 'System Admin')),
      created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  );
  ```

- **`documents_metadata_v2`** (liên quan đến quản trị tài liệu):
  ```sql
  CREATE TABLE documents_metadata_v2 (
      id UUID PRIMARY KEY,
      title VARCHAR(255),
      category VARCHAR(100),
      created_at TIMESTAMPTZ,
      is_active BOOLEAN DEFAULT TRUE
  );
  ```

### 5.2. API Endpoints
Module FR-08 cung cấp các endpoint sau (tích hợp với FastAPI):

| **Endpoint**            | **Phương thức** | **Mô tả**                                     | **Quyền truy cập** |
|-------------------------|-----------------|-----------------------------------------------|--------------------|
| `/api/admin/users`      | GET, POST, PUT, DELETE | Quản lý người dùng (CRUD)            | System Admin       |
| `/api/admin/documents`  | GET, PUT, DELETE | Quản lý metadata tài liệu            | System Admin       |
| `/api/admin/system`     | GET             | Xem metrics hệ thống (CPU, RAM, log)  | System Admin       |
| `/api/admin/maintenance`| POST            | Thực hiện bảo trì (reindex, backup)   | System Admin       |

**Ví dụ endpoint**:
```python
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import Optional

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class UserUpdate(BaseModel):
    email: Optional[str]
    user_level: Optional[str]

async def get_current_admin(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["RS256"])
        if payload.get("user_level") != "System Admin":
            raise HTTPException(status_code=403, detail="Admin access required")
        return payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/api/admin/system")
async def get_system_metrics(admin_id: str = Depends(get_current_admin)):
    # Truy vấn PostgreSQL: SELECT * FROM system_metrics ORDER BY timestamp DESC LIMIT 100
    return {"cpu_usage_percent": 45.5, "memory_usage_mb": 2048}
```

### 5.3. Giao diện Quản trị
- **Adminer**: Giao diện web để quản lý PostgreSQL:
  - URL: `http://localhost:8080`
  - Cấu hình: Kết nối đến `postgres:5432` với user/pass từ Docker Compose.
- **Grafana Dashboard**:
  - Hiển thị metrics từ `system_metrics` và Prometheus:
    - CPU/memory usage theo container.
    - Lỗi API (HTTP 500, timeout).
  - URL: `http://grafana:3000`
- **Custom Admin UI** (tùy chọn):
  - Dùng FastAPI + Jinja2 để tạo giao diện quản trị tùy chỉnh, hiển thị danh sách users, documents, và metrics.

### 5.4. Luồng Dữ liệu
```mermaid
graph TD
    FR04[FR-04: RAG Core] -->|Ghi metrics| Data_FR021[FR-02.1: PostgreSQL<br/>system_metrics]
    FR022[FR-02.2: API Quản trị] -->|Ghi log| Data_FR021
    Data_FR021 --> FR08[FR-08: Admin & Maintenance Tools]
    FR08 -->|API/Giao diện| Gateway[FR-06: Gateway<br/>JWT + RBAC]
    FR08 -->|Metrics/Log| External[External Services<br/>Prometheus, Grafana, Loki]
    Gateway --> Users[Người dùng<br/>System Admin]
```

---

## 6. Triển khai

### 6.1. Môi trường
- **OS**: Ubuntu 22.04
- **Container**: Docker 20.10+, Docker Compose 2.0+
- **Python**: 3.11
- **Database**: PostgreSQL 15 (với pgbouncer), ChromaDB 1.0.0

### 6.2. Cấu hình Docker
**`docker-compose.yml`**:
```yaml
version: '3.8'
services:
  admin:
    image: python:3.11
    volumes:
      - ./admin:/app
    working_dir: /app
    command: uvicorn main:app --host 0.0.0.0 --port 8002
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/rag_db
      - CHROMADB_HOST=chromadb:8000
      - PROMETHEUS_MULTIPROC_DIR=/tmp
    depends_on:
      - postgres
      - chromadb
      - redis
    networks:
      - rag_network
  adminer:
    image: adminer:latest
    ports:
      - "8080:8080"
    environment:
      - ADMINER_DEFAULT_SERVER=postgres
    depends_on:
      - postgres
    networks:
      - rag_network
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=rag_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - rag_network
  chromadb:
    image: chromadb/chromadb:1.0.0
    environment:
      - CHROMADB_PORT=8000
    networks:
      - rag_network
  redis:
    image: redis:7
    networks:
      - rag_network
  prometheus:
    image: prom/prometheus:latest
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"
    networks:
      - rag_network
  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    depends_on:
      - prometheus
    networks:
      - rag_network

volumes:
  postgres_data:

networks:
  rag_network:
    driver: bridge
```

### 6.3. Cấu hình Prometheus
- Thêm endpoint `/metrics` vào FastAPI:
```python
from prometheus_client import Gauge, generate_latest
from fastapi import FastAPI

app = FastAPI()
cpu_usage = Gauge("cpu_usage_percent", "CPU usage percentage", ["container"])

@app.get("/metrics")
async def metrics():
    cpu_usage.labels(container="admin").set(45.5)
    return generate_latest()
```

- Cấu hình Prometheus trong `prometheus.yml`:
```yaml
scrape_configs:
  - job_name: 'admin'
    static_configs:
      - targets: ['admin:8002']
```

---

## 7. Các Bước Triển khai

1. **Khởi tạo cơ sở dữ liệu**:
   - Tạo bảng `system_metrics`, đảm bảo index trên `timestamp`.
   - Kiểm tra kết nối PostgreSQL và ChromaDB.

2. **Cài đặt môi trường**:
   - Cài Python 3.11, Docker, Docker Compose trên Ubuntu.
   - Cài thư viện: `pip install fastapi==0.104.1 sqlalchemy==2.0.23 prometheus-client==0.17.0 loguru`.

3. **Triển khai API**:
   - Tạo file `main.py` cho FastAPI với các endpoint `/api/admin/*`.
   - Thêm middleware JWT (tích hợp với FR-06) và logging (loguru).

4. **Triển khai Adminer và Grafana**:
   - Chạy Adminer: `http://localhost:8080`.
   - Cấu hình Grafana dashboard: `http://grafana:3000`.

5. **Chạy Docker Compose**:
   ```bash
   docker-compose up -d
   ```

6. **Kiểm tra**:
   - Test endpoint: `curl http://localhost:8002/api/admin/system`.
   - Truy cập Adminer: `http://localhost:8080`.
   - Kiểm tra Grafana dashboard: `http://grafana:3000`.

7. **Tích hợp với FR-06**:
   - Cập nhật RBAC để chỉ System Admin truy cập được `/api/admin`.

---

## 8. Rủi ro và Giải pháp

| **Rủi ro**                                    | **Giải pháp**                                                                 |
|-----------------------------------------------|------------------------------------------------------------------------------|
| Metrics không được ghi đúng                  | Đảm bảo FR-04, FR-02.2 ghi đầy đủ vào `system_metrics` qua logging middleware. |
| Adminer không kết nối được PostgreSQL        | Kiểm tra cấu hình `pgbouncer` và Docker network.                             |
| Lỗi quyền truy cập endpoint                  | Kiểm tra JWT và RBAC trong FR-06 trước khi xử lý yêu cầu.                    |
| Grafana dashboard không hiển thị metrics     | Kiểm tra cấu hình Prometheus scrape và endpoint `/metrics`.                  |

---

## 9. Kế hoạch Phát triển

- **Tuần 1**: Tạo schema `system_metrics`, triển khai endpoint `/api/admin/users` và `/api/admin/documents`.
- **Tuần 2**: Triển khai endpoint `/api/admin/system` và `/api/admin/maintenance`.
- **Tuần 3**: Cấu hình Adminer và Grafana dashboard.
- **Tuần 4**: Test tích hợp, tối ưu hiệu suất, và triển khai backup.

---

## 10. Hỗ trợ Cần thiết

- **Từ đội kỹ thuật**:
  - Xác nhận schema `system_metrics` và kết nối ChromaDB.
  - Cung cấp quyền truy cập Prometheus/Grafana/Loki.
- **Từ management**:
  - Phê duyệt tài nguyên cho Docker containers (CPU, RAM).
  - Xác nhận yêu cầu quản trị (như danh sách tác vụ bảo trì) từ stakeholders.

---

**📧 Liên hệ:** [Your email]  
**📱 Phone:** [Your phone]  
**📊 Tài liệu chi tiết:** Có sẵn trong project knowledge base