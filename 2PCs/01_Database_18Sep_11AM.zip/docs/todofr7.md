
Step1: read fr07_design_document.md
Step2: read requirements_FR-07.md
Step3: implement FR07
Step4: when done, read handover_template.md and make handover_FR07.md



