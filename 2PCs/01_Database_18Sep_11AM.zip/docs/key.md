# 🔐 FR-02.1 v2.0 - Service Credentials & Access Keys

**Project**: Vietnamese Chatbot Dual Database System  
**Version**: 2.0  
**Generated**: September 11, 2025  
**Environment**: Development/Production  

## ✅ **VERIFIED LOGIN CREDENTIALS** 

**TESTED AND CONFIRMED WORKING - Updated September 11, 2025**  
**🔧 PostgreSQL Connection Fixed - All Services Working**

### **Quick Access Summary:**
- **Adminer (Database)**: `http://localhost:8081`
  - **System**: PostgreSQL
  - **Server**: `postgres`
  - **Username**: `kb_admin`
  - **Password**: `1234567890`
  - **Database**: `knowledge_base_v2`

- **Grafana (Monitoring)**: `http://localhost:3009`
  - **Username**: `admin`
  - **Password**: `1234567890`

- **PostgreSQL (Direct)**: `localhost:5432`
  - **Username**: `kb_admin`
  - **Password**: `1234567890`
  - **Database**: `knowledge_base_v2`  

---

## 📊 **DATABASE SERVICES**

### **PostgreSQL Database**
- **Host**: `localhost` / `postgres` (container name)
- **Port**: `5432`
- **Database**: `knowledge_base_v2`
- **Username**: `kb_admin`
- **Password**: `1234567890`
- **Connection String**: `postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2`
- **Status**: ✅ Healthy

### **PgBouncer (Connection Pooling)**
- **Host**: `localhost` / `pgbouncer` (container name)
- **Port**: `6432`
- **Database**: `knowledge_base_v2`
- **Username**: `kb_admin`
- **Password**: `1234567890`
- **Connection String**: `postgresql://kb_admin:1234567890@localhost:6432/knowledge_base_v2`
- **Pool Mode**: `transaction`
- **Status**: ✅ Running

### **ChromaDB (Vector Database)**
- **Host**: `localhost` / `chroma` (container name)
- **Port**: `8000`
- **API Version**: `v2`
- **Auth Token**: `1234567890`
- **API Endpoint**: `http://localhost:8000/api/v2/`
- **Heartbeat**: `http://localhost:8000/api/v2/heartbeat`
- **Authentication Header**: `X-Chroma-Token: 1234567890`
- **Status**: ✅ Healthy

### **Redis Cache (Master)**
- **Host**: `localhost` / `redis-master` (container name)
- **Port**: `6379`
- **Password**: `None` (no password set)
- **Database**: `0` (default)
- **Connection**: `redis://localhost:6379`
- **Status**: ✅ Healthy

### **Redis Cache (Replica)**
- **Host**: `localhost` / `redis-replica` (container name)
- **Port**: `6380`
- **Password**: `None` (no password set)
- **Database**: `0` (default)
- **Connection**: `redis://localhost:6380`
- **Status**: ✅ Running

---

## 🌐 **WEB INTERFACES**

### **Adminer (Database Web Management)**
- **URL**: `http://localhost:8081`
- **System**: `PostgreSQL`
- **Server**: `postgres`
- **Username**: `kb_admin`
- **Password**: `1234567890`
- **Database**: `knowledge_base_v2`
- **Design Theme**: `pepa-linha`
- **Status**: ✅ Available

### **Grafana (Monitoring Dashboards)**
- **URL**: `http://localhost:3009`
- **Username**: `admin`
- **Password**: `1234567890`
- **Organization**: `Main Org.`
- **Installed Plugins**: `redis-datasource`
- **Status**: ✅ Available

### **Prometheus (Metrics Collection)**
- **URL**: `http://localhost:9090`
- **Authentication**: `None`
- **Health Check**: `http://localhost:9090/-/healthy`
- **Retention**: `30 days`
- **Status**: ✅ Available

### **NGINX (Load Balancer)**
- **HTTP**: `http://localhost:80`
- **HTTPS**: `https://localhost:443`
- **Authentication**: `None`
- **Status**: ✅ Running

---

## 📈 **MONITORING SERVICES**

### **Node Exporter**
- **URL**: `http://localhost:9100/metrics`
- **Authentication**: `None`
- **Metrics**: System metrics (CPU, Memory, Disk, Network)
- **Status**: ✅ Running

### **PostgreSQL Exporter**
- **URL**: `http://localhost:9187/metrics`
- **Authentication**: `None`
- **Database Connection**: `postgresql://kb_admin:1234567890@postgres:5432/knowledge_base_v2?sslmode=disable`
- **Metrics**: PostgreSQL performance metrics
- **Status**: ✅ Running

### **Redis Exporter**
- **URL**: `http://localhost:9121/metrics`
- **Authentication**: `None`
- **Redis Connection**: `redis://redis-master:6379`
- **Metrics**: Redis performance metrics
- **Status**: ✅ Running

---

## 🔧 **CONFIGURATION FILES**

### **Environment Variables (.env)**
```bash
# Database Configuration
POSTGRES_PASSWORD=1234567890
POSTGRES_USER=kb_admin
POSTGRES_DB=knowledge_base_v2
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

# ChromaDB Configuration
CHROMA_AUTH_TOKEN=1234567890
CHROMA_HOST=chroma
CHROMA_PORT=8000

# Monitoring Configuration
GRAFANA_PASSWORD=1234567890
PROMETHEUS_RETENTION=30d

# Redis Configuration
REDIS_HOST=redis-master
REDIS_PORT=6379

# Vietnamese NLP Configuration
EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B
EMBEDDING_DIMENSION=1024
```

---

## 🐳 **DOCKER CONTAINER INFORMATION**

| Container Name | Image | Status | Ports |
|---------------|-------|---------|-------|
| `fr02-postgres-v2` | `postgres:15-alpine` | ✅ Healthy | `5432:5432` |
| `fr02-pgbouncer` | `pgbouncer/pgbouncer:latest` | ✅ Running | `6432:5432` |
| `fr02-chroma-v2` | `chromadb/chroma:1.0.0` | ✅ Healthy | `8000:8000` |
| `fr02-redis-master` | `redis:7-alpine` | ✅ Healthy | `6379:6379` |
| `fr02-redis-replica` | `redis:7-alpine` | ✅ Running | `6380:6379` |
| `fr02-adminer` | `adminer:latest` | ✅ Running | `8081:8080` |
| `fr02-grafana` | `grafana/grafana:latest` | ✅ Running | `3009:3000` |
| `fr02-prometheus` | `prom/prometheus:latest` | ✅ Running | `9090:9090` |
| `fr02-nginx` | `nginx:alpine` | ✅ Running | `80:80, 443:443` |
| `fr02-node-exporter` | `prom/node-exporter:latest` | ✅ Running | `9100:9100` |
| `fr02-postgres-exporter` | `prometheuscommunity/postgres-exporter:latest` | ✅ Running | `9187:9187` |
| `fr02-redis-exporter` | `oliver006/redis_exporter:latest` | ✅ Running | `9121:9121` |

---

## 🔒 **SECURITY NOTES**

### **⚠️ Development Environment Warning**
- **Password**: `1234567890` is used across services for development
- **Production**: Change all passwords to secure, unique values
- **ChromaDB**: Authentication token should be a secure random string
- **SSL/TLS**: Enable HTTPS certificates for production deployment

### **Network Security**
- All services are bound to `0.0.0.0` for development
- Production: Restrict access to specific IP ranges
- Docker Network: `fr02-network` (172.20.0.0/16)

### **Backup Information**
- **PostgreSQL**: Automated backups to `/opt/backups`
- **ChromaDB**: Vector data persisted to `chroma_data` volume
- **Redis**: Data persistence enabled with AOF and RDB
- **Grafana**: Dashboards and settings in `grafana_data` volume

---

## 🛠️ **QUICK COMMANDS**

### **Database Operations**
```bash
# Connect to PostgreSQL
docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2

# Connect to Redis
docker-compose exec redis-master redis-cli

# View ChromaDB collections
curl -H "X-Chroma-Token: 1234567890" http://localhost:8000/api/v2/collections
```

### **Service Management**
```bash
# View all services
docker-compose ps

# Restart specific service
docker-compose restart grafana

# View logs
docker-compose logs -f chroma

# Stop all services
docker-compose down

# Start all services
docker-compose up -d
```

### **Health Checks**
```bash
# PostgreSQL
docker-compose exec postgres pg_isready -U kb_admin -d knowledge_base_v2

# Redis
docker-compose exec redis-master redis-cli ping

# ChromaDB
curl -f http://localhost:8000/api/v2/heartbeat

# Grafana
curl -f http://localhost:3009/api/health

# Prometheus
curl -f http://localhost:9090/-/healthy
```

---

## 📝 **NOTES**

1. **First Time Setup**: All services are configured and running
2. **Database Schema**: Enhanced schema deployed with Vietnamese support
3. **Collections**: ChromaDB collections created for different departments
4. **Monitoring**: Comprehensive monitoring stack with Prometheus + Grafana
5. **Web Access**: Adminer provides easy database management interface

**Last Updated**: September 11, 2025  
**System Status**: ✅ All Services Operational  
**Ready for**: Development, Testing, and Production Deployment