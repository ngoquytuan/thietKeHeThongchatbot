"""
Admin API routes for user and document management
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime
from loguru import logger

from config.database import get_db
from models.users import User, UserLevel
from models.documents import DocumentMetadata
from services.auth_service import get_current_admin

admin_router = APIRouter()

# Pydantic models for request/response
class UserResponse(BaseModel):
    id: str
    email: str
    user_level: str
    created_at: str
    
    class Config:
        from_attributes = True

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    user_level: UserLevel = UserLevel.GUEST

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    user_level: Optional[UserLevel] = None
    password: Optional[str] = Field(None, min_length=8)

class DocumentResponse(BaseModel):
    id: str
    title: str
    category: Optional[str]
    created_at: str
    is_active: bool
    
    class Config:
        from_attributes = True

class DocumentUpdate(BaseModel):
    title: Optional[str] = Field(None, max_length=255)
    category: Optional[str] = Field(None, max_length=100)
    is_active: Optional[bool] = None

class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int


# User management endpoints
@admin_router.get("/users", response_model=PaginatedResponse)
async def list_users(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    user_level: Optional[UserLevel] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """List all users with pagination and filtering"""
    try:
        # Build query
        query = select(User)
        count_query = select(func.count(User.id))
        
        # Apply filters
        if search:
            search_filter = or_(
                User.email.ilike(f"%{search}%")
            )
            query = query.where(search_filter)
            count_query = count_query.where(search_filter)
        
        if user_level:
            query = query.where(User.user_level == user_level)
            count_query = count_query.where(User.user_level == user_level)
        
        # Get total count
        total_result = await db.execute(count_query)
        total = total_result.scalar()
        
        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size).order_by(User.created_at.desc())
        
        result = await db.execute(query)
        users = result.scalars().all()
        
        # Convert to response format
        user_responses = []
        for user in users:
            user_responses.append(UserResponse(
                id=str(user.id),
                email=user.email,
                user_level=user.user_level.value,
                created_at=user.created_at.isoformat()
            ))
        
        pages = (total + size - 1) // size
        
        logger.info(f"Admin {current_admin.email} listed {len(user_responses)} users")
        
        return PaginatedResponse(
            items=user_responses,
            total=total,
            page=page,
            size=size,
            pages=pages
        )
        
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve users"
        )

@admin_router.get("/users/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get specific user by ID"""
    try:
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        logger.info(f"Admin {current_admin.email} viewed user {user.email}")
        
        return UserResponse(
            id=str(user.id),
            email=user.email,
            user_level=user.user_level.value,
            created_at=user.created_at.isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve user"
        )

@admin_router.put("/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    user_update: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Update specific user"""
    try:
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Update fields
        if user_update.email is not None:
            # Check if email already exists
            existing = await db.execute(
                select(User).where(and_(User.email == user_update.email, User.id != user_id))
            )
            if existing.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Email already exists"
                )
            user.email = user_update.email
        
        if user_update.user_level is not None:
            user.user_level = user_update.user_level
        
        if user_update.password is not None:
            # In a real implementation, hash the password
            user.password_hash = f"hashed_{user_update.password}"  # Placeholder
        
        await db.commit()
        await db.refresh(user)
        
        logger.info(f"Admin {current_admin.email} updated user {user.email}")
        
        return UserResponse(
            id=str(user.id),
            email=user.email,
            user_level=user.user_level.value,
            created_at=user.created_at.isoformat()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"Error updating user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update user"
        )

@admin_router.delete("/users/{user_id}")
async def delete_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Delete specific user"""
    try:
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # Prevent deletion of system admins
        if user.user_level == UserLevel.SYSTEM_ADMIN:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete system admin users"
            )
        
        # Prevent self-deletion
        if user.id == current_admin.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete your own account"
            )
        
        await db.delete(user)
        await db.commit()
        
        logger.info(f"Admin {current_admin.email} deleted user {user.email}")
        
        return {"message": "User deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"Error deleting user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete user"
        )


# Document management endpoints
@admin_router.get("/documents", response_model=PaginatedResponse)
async def list_documents(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """List all documents with pagination and filtering"""
    try:
        # Build query
        query = select(DocumentMetadata)
        count_query = select(func.count(DocumentMetadata.id))
        
        # Apply filters
        filters = []
        if search:
            filters.append(or_(
                DocumentMetadata.title.ilike(f"%{search}%"),
                DocumentMetadata.category.ilike(f"%{search}%")
            ))
        
        if category:
            filters.append(DocumentMetadata.category == category)
        
        if is_active is not None:
            filters.append(DocumentMetadata.is_active == is_active)
        
        if filters:
            filter_condition = and_(*filters)
            query = query.where(filter_condition)
            count_query = count_query.where(filter_condition)
        
        # Get total count
        total_result = await db.execute(count_query)
        total = total_result.scalar()
        
        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size).order_by(DocumentMetadata.created_at.desc())
        
        result = await db.execute(query)
        documents = result.scalars().all()
        
        # Convert to response format
        document_responses = []
        for doc in documents:
            document_responses.append(DocumentResponse(
                id=str(doc.id),
                title=doc.title,
                category=doc.category,
                created_at=doc.created_at.isoformat(),
                is_active=doc.is_active
            ))
        
        pages = (total + size - 1) // size
        
        logger.info(f"Admin {current_admin.email} listed {len(document_responses)} documents")
        
        return PaginatedResponse(
            items=document_responses,
            total=total,
            page=page,
            size=size,
            pages=pages
        )
        
    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve documents"
        )

@admin_router.get("/documents/{document_id}", response_model=DocumentResponse)
async def get_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get specific document by ID"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )
        
        logger.info(f"Admin {current_admin.email} viewed document {document.title}")
        
        return DocumentResponse(
            id=str(document.id),
            title=document.title,
            category=document.category,
            created_at=document.created_at.isoformat(),
            is_active=document.is_active
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve document"
        )

@admin_router.put("/documents/{document_id}", response_model=DocumentResponse)
async def update_document(
    document_id: UUID,
    doc_update: DocumentUpdate,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Update specific document"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )
        
        # Update fields
        if doc_update.title is not None:
            document.title = doc_update.title
        
        if doc_update.category is not None:
            document.category = doc_update.category
        
        if doc_update.is_active is not None:
            document.is_active = doc_update.is_active
        
        await db.commit()
        await db.refresh(document)
        
        logger.info(f"Admin {current_admin.email} updated document {document.title}")
        
        return DocumentResponse(
            id=str(document.id),
            title=document.title,
            category=document.category,
            created_at=document.created_at.isoformat(),
            is_active=document.is_active
        )
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"Error updating document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update document"
        )

@admin_router.delete("/documents/{document_id}")
async def delete_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Delete specific document"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )
        
        await db.delete(document)
        await db.commit()
        
        logger.info(f"Admin {current_admin.email} deleted document {document.title}")
        
        return {"message": "Document deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"Error deleting document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete document"
        )