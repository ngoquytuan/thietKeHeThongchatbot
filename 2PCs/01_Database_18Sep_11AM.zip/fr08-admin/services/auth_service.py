"""
Authentication and Authorization Service for FR-08
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import jwt
from jwt import PyJWTError
from typing import Optional
from loguru import logger

from config.database import get_db
from config.settings import Settings
from models.users import User, UserLevel

settings = Settings()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


class JWTError(Exception):
    """Custom JWT Error"""
    pass


async def verify_jwt_token(token: str) -> Optional[dict]:
    """Verify JWT token and extract payload"""
    try:
        payload = jwt.decode(
            token, 
            settings.JWT_SECRET_KEY, 
            algorithms=[settings.JWT_ALGORITHM]
        )
        return payload
    except PyJWTError as e:
        logger.warning(f"JWT verification failed: {e}")
        return None


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> User:
    """Get current user from JWT token"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    payload = await verify_jwt_token(token)
    if payload is None:
        raise credentials_exception
        
    user_email: str = payload.get("sub")
    if user_email is None:
        raise credentials_exception
        
    # Get user from database
    result = await db.execute(select(User).where(User.email == user_email))
    user = result.scalar_one_or_none()
    
    if user is None:
        raise credentials_exception
        
    return user


async def get_current_admin(
    current_user: User = Depends(get_current_user)
) -> User:
    """Verify that current user is a System Admin"""
    if not current_user.is_system_admin():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="System Admin access required"
        )
    
    logger.info(f"Admin access granted to {current_user.email}")
    return current_user


async def verify_admin_access(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> bool:
    """Verify admin access without returning user object"""
    try:
        user = await get_current_user(token, db)
        return user.is_system_admin()
    except HTTPException:
        return False


class AdminPermissions:
    """Admin permission checks"""
    
    @staticmethod
    def can_manage_users(user: User) -> bool:
        """Check if user can manage other users"""
        return user.user_level == UserLevel.SYSTEM_ADMIN
    
    @staticmethod
    def can_manage_documents(user: User) -> bool:
        """Check if user can manage documents"""
        return user.user_level == UserLevel.SYSTEM_ADMIN
    
    @staticmethod
    def can_view_system_metrics(user: User) -> bool:
        """Check if user can view system metrics"""
        return user.user_level == UserLevel.SYSTEM_ADMIN
    
    @staticmethod
    def can_perform_maintenance(user: User) -> bool:
        """Check if user can perform maintenance operations"""
        return user.user_level == UserLevel.SYSTEM_ADMIN