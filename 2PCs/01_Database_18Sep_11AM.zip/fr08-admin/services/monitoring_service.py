"""
System Monitoring Service for FR-08
"""

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, desc, and_
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from loguru import logger
import psutil
import docker
from prometheus_client import Gauge, Counter, Histogram
import asyncio

from models.system_metrics import SystemMetrics
from config.settings import Settings

settings = Settings()

# Prometheus metrics
cpu_usage_gauge = Gauge("system_cpu_usage_percent", "CPU usage percentage", ["container"])
memory_usage_gauge = Gauge("system_memory_usage_mb", "Memory usage in MB", ["container"])
response_time_histogram = Histogram("api_response_time_seconds", "API response time", ["endpoint"])
error_counter = Counter("system_errors_total", "Total system errors", ["type", "component"])


class MonitoringService:
    """Service for system monitoring and metrics collection"""
    
    def __init__(self):
        self.docker_client = None
        try:
            self.docker_client = docker.from_env()
        except Exception as e:
            logger.warning(f"Docker client initialization failed: {e}")
    
    async def collect_system_metrics(self, db: AsyncSession) -> Dict[str, Any]:
        """Collect current system metrics"""
        try:
            # Get system metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_io_counters()
            network = psutil.net_io_counters()
            
            # Get Docker container metrics
            container_metrics = await self._get_container_metrics()
            
            metrics = {
                "system": {
                    "cpu_usage_percent": cpu_percent,
                    "memory_usage_mb": memory.used / 1024 / 1024,
                    "memory_total_mb": memory.total / 1024 / 1024,
                    "memory_percent": memory.percent,
                    "disk_read_mb": disk.read_bytes / 1024 / 1024 if disk else 0,
                    "disk_write_mb": disk.write_bytes / 1024 / 1024 if disk else 0,
                    "network_sent_mb": network.bytes_sent / 1024 / 1024 if network else 0,
                    "network_recv_mb": network.bytes_recv / 1024 / 1024 if network else 0,
                },
                "containers": container_metrics,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            # Store metrics in database
            await self._store_metrics(db, metrics)
            
            # Update Prometheus metrics
            self._update_prometheus_metrics(metrics)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error collecting system metrics: {e}")
            error_counter.labels(type="collection", component="monitoring").inc()
            raise
    
    async def _get_container_metrics(self) -> List[Dict[str, Any]]:
        """Get metrics from Docker containers"""
        if not self.docker_client:
            return []
            
        container_metrics = []
        
        try:
            containers = self.docker_client.containers.list()
            
            for container in containers:
                try:
                    stats = container.stats(stream=False)
                    
                    # Calculate CPU usage
                    cpu_delta = stats['cpu_stats']['cpu_usage']['total_usage'] - \
                               stats['precpu_stats']['cpu_usage']['total_usage']
                    system_delta = stats['cpu_stats']['system_cpu_usage'] - \
                                  stats['precpu_stats']['system_cpu_usage']
                    
                    cpu_percent = 0.0
                    if system_delta > 0 and cpu_delta > 0:
                        cpu_percent = (cpu_delta / system_delta) * \
                                     len(stats['cpu_stats']['cpu_usage']['percpu_usage']) * 100.0
                    
                    # Calculate memory usage
                    memory_usage = stats['memory_stats'].get('usage', 0)
                    memory_limit = stats['memory_stats'].get('limit', 0)
                    memory_percent = 0.0
                    if memory_limit > 0:
                        memory_percent = (memory_usage / memory_limit) * 100.0
                    
                    container_info = {
                        "container_id": container.id[:12],
                        "name": container.name,
                        "status": container.status,
                        "cpu_usage_percent": round(cpu_percent, 2),
                        "memory_usage_mb": round(memory_usage / 1024 / 1024, 2),
                        "memory_limit_mb": round(memory_limit / 1024 / 1024, 2),
                        "memory_percent": round(memory_percent, 2),
                        "network_rx_mb": round(stats['networks'].get('eth0', {}).get('rx_bytes', 0) / 1024 / 1024, 2),
                        "network_tx_mb": round(stats['networks'].get('eth0', {}).get('tx_bytes', 0) / 1024 / 1024, 2)
                    }
                    
                    container_metrics.append(container_info)
                    
                except Exception as e:
                    logger.warning(f"Error getting stats for container {container.name}: {e}")
                    
        except Exception as e:
            logger.error(f"Error listing containers: {e}")
            
        return container_metrics
    
    async def _store_metrics(self, db: AsyncSession, metrics: Dict[str, Any]):
        """Store metrics in database"""
        try:
            # Store system metrics
            system_metric = SystemMetrics(
                container_id="system",
                cpu_usage_percent=metrics["system"]["cpu_usage_percent"],
                memory_usage_mb=metrics["system"]["memory_usage_mb"],
                disk_io=metrics["system"]["disk_read_mb"] + metrics["system"]["disk_write_mb"],
                network_throughput=metrics["system"]["network_sent_mb"] + metrics["system"]["network_recv_mb"]
            )
            db.add(system_metric)
            
            # Store container metrics
            for container in metrics["containers"]:
                container_metric = SystemMetrics(
                    container_id=container["container_id"],
                    cpu_usage_percent=container["cpu_usage_percent"],
                    memory_usage_mb=container["memory_usage_mb"],
                    network_throughput=container["network_rx_mb"] + container["network_tx_mb"]
                )
                db.add(container_metric)
            
            await db.commit()
            
        except Exception as e:
            logger.error(f"Error storing metrics: {e}")
            await db.rollback()
            raise
    
    def _update_prometheus_metrics(self, metrics: Dict[str, Any]):
        """Update Prometheus metrics"""
        try:
            # Update system metrics
            cpu_usage_gauge.labels(container="system").set(metrics["system"]["cpu_usage_percent"])
            memory_usage_gauge.labels(container="system").set(metrics["system"]["memory_usage_mb"])
            
            # Update container metrics
            for container in metrics["containers"]:
                cpu_usage_gauge.labels(container=container["name"]).set(container["cpu_usage_percent"])
                memory_usage_gauge.labels(container=container["name"]).set(container["memory_usage_mb"])
                
        except Exception as e:
            logger.error(f"Error updating Prometheus metrics: {e}")
    
    async def get_historical_metrics(
        self, 
        db: AsyncSession, 
        hours: int = 24,
        container_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get historical metrics from database"""
        try:
            since = datetime.utcnow() - timedelta(hours=hours)
            
            query = select(SystemMetrics).where(SystemMetrics.timestamp >= since)
            if container_id:
                query = query.where(SystemMetrics.container_id == container_id)
            
            query = query.order_by(desc(SystemMetrics.timestamp)).limit(1000)
            
            result = await db.execute(query)
            metrics = result.scalars().all()
            
            return [metric.to_dict() for metric in metrics]
            
        except Exception as e:
            logger.error(f"Error getting historical metrics: {e}")
            raise
    
    async def check_thresholds(self, metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check if metrics exceed configured thresholds"""
        alerts = []
        
        # Check system CPU
        if metrics["system"]["cpu_usage_percent"] > settings.CPU_THRESHOLD:
            alerts.append({
                "type": "cpu_high",
                "message": f"System CPU usage is {metrics['system']['cpu_usage_percent']:.1f}%",
                "threshold": settings.CPU_THRESHOLD,
                "current": metrics["system"]["cpu_usage_percent"],
                "severity": "warning"
            })
        
        # Check system memory
        if metrics["system"]["memory_percent"] > settings.MEMORY_THRESHOLD:
            alerts.append({
                "type": "memory_high",
                "message": f"System memory usage is {metrics['system']['memory_percent']:.1f}%",
                "threshold": settings.MEMORY_THRESHOLD,
                "current": metrics["system"]["memory_percent"],
                "severity": "critical"
            })
        
        # Check container metrics
        for container in metrics["containers"]:
            if container["cpu_usage_percent"] > settings.CPU_THRESHOLD:
                alerts.append({
                    "type": "container_cpu_high",
                    "message": f"Container {container['name']} CPU usage is {container['cpu_usage_percent']:.1f}%",
                    "container": container["name"],
                    "threshold": settings.CPU_THRESHOLD,
                    "current": container["cpu_usage_percent"],
                    "severity": "warning"
                })
                
            if container["memory_percent"] > settings.MEMORY_THRESHOLD:
                alerts.append({
                    "type": "container_memory_high",
                    "message": f"Container {container['name']} memory usage is {container['memory_percent']:.1f}%",
                    "container": container["name"],
                    "threshold": settings.MEMORY_THRESHOLD,
                    "current": container["memory_percent"],
                    "severity": "critical"
                })
        
        if alerts:
            logger.warning(f"Generated {len(alerts)} alerts")
            
        return alerts