"""
Database Maintenance Service for FR-08
"""

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from datetime import datetime, timedelta
from typing import Dict, Any, List
from loguru import logger
import subprocess
import os
import asyncio
from pathlib import Path

from config.settings import Settings
from config.database import get_redis, get_chromadb_client

settings = Settings()


class MaintenanceService:
    """Service for database and system maintenance operations"""
    
    def __init__(self):
        self.backup_dir = Path(settings.BACKUP_DIR)
        self.backup_dir.mkdir(exist_ok=True)
    
    async def create_database_backup(self, db: AsyncSession) -> Dict[str, Any]:
        """Create PostgreSQL database backup using pg_dump"""
        try:
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"rag_db_backup_{timestamp}.sql"
            backup_path = self.backup_dir / backup_filename
            
            # Extract database connection details from settings
            db_url = settings.DATABASE_URL
            if "postgresql://" in db_url:
                # Parse connection string
                # Format: postgresql://user:pass@host:port/dbname
                parts = db_url.replace("postgresql://", "").split("/")
                db_name = parts[-1]
                host_part = parts[0].split("@")[-1]
                user_part = parts[0].split("@")[0]
                
                host = host_part.split(":")[0]
                port = host_part.split(":")[1] if ":" in host_part else "5432"
                user = user_part.split(":")[0]
                password = user_part.split(":")[1] if ":" in user_part else ""
                
                # Prepare pg_dump command
                env = os.environ.copy()
                if password:
                    env["PGPASSWORD"] = password
                
                cmd = [
                    "pg_dump",
                    "-h", host,
                    "-p", port,
                    "-U", user,
                    "-d", db_name,
                    "--verbose",
                    "--no-password",
                    "-f", str(backup_path)
                ]
                
                # Run pg_dump
                logger.info(f"Starting database backup to {backup_path}")
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    env=env,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await process.communicate()
                
                if process.returncode == 0:
                    backup_size = backup_path.stat().st_size
                    logger.info(f"Database backup completed: {backup_filename} ({backup_size} bytes)")
                    
                    # Clean up old backups
                    await self._cleanup_old_backups()
                    
                    return {
                        "success": True,
                        "filename": backup_filename,
                        "size_bytes": backup_size,
                        "timestamp": timestamp,
                        "path": str(backup_path)
                    }
                else:
                    error_msg = stderr.decode() if stderr else "Unknown error"
                    logger.error(f"Database backup failed: {error_msg}")
                    return {
                        "success": False,
                        "error": error_msg
                    }
            else:
                raise ValueError("Invalid database URL format")
                
        except Exception as e:
            logger.error(f"Error creating database backup: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _cleanup_old_backups(self):
        """Remove old backup files beyond max count"""
        try:
            backup_files = list(self.backup_dir.glob("rag_db_backup_*.sql"))
            backup_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            
            if len(backup_files) > settings.MAX_BACKUP_COUNT:
                files_to_remove = backup_files[settings.MAX_BACKUP_COUNT:]
                for file_path in files_to_remove:
                    file_path.unlink()
                    logger.info(f"Removed old backup: {file_path.name}")
                    
        except Exception as e:
            logger.error(f"Error cleaning up old backups: {e}")
    
    async def optimize_database(self, db: AsyncSession) -> Dict[str, Any]:
        """Optimize PostgreSQL database with ANALYZE and REINDEX"""
        results = []
        
        try:
            # Tables to optimize
            tables = [
                "system_metrics",
                "users", 
                "documents_metadata_v2",
                "search_analytics"
            ]
            
            for table in tables:
                try:
                    # Run ANALYZE
                    logger.info(f"Running ANALYZE on {table}")
                    await db.execute(text(f"ANALYZE {table}"))
                    
                    # Run REINDEX
                    logger.info(f"Running REINDEX on {table}")
                    await db.execute(text(f"REINDEX TABLE {table}"))
                    
                    results.append({
                        "table": table,
                        "analyze": "success",
                        "reindex": "success"
                    })
                    
                except Exception as e:
                    logger.error(f"Error optimizing table {table}: {e}")
                    results.append({
                        "table": table,
                        "analyze": "failed",
                        "reindex": "failed", 
                        "error": str(e)
                    })
            
            await db.commit()
            
            return {
                "success": True,
                "results": results,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            await db.rollback()
            logger.error(f"Database optimization failed: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def cleanup_old_metrics(self, db: AsyncSession, days: int = 30) -> Dict[str, Any]:
        """Clean up old system metrics data"""
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Count records to be deleted
            count_result = await db.execute(
                text("SELECT COUNT(*) FROM system_metrics WHERE timestamp < :cutoff"),
                {"cutoff": cutoff_date}
            )
            record_count = count_result.scalar()
            
            if record_count > 0:
                # Delete old records
                await db.execute(
                    text("DELETE FROM system_metrics WHERE timestamp < :cutoff"),
                    {"cutoff": cutoff_date}
                )
                await db.commit()
                
                logger.info(f"Cleaned up {record_count} old metric records older than {days} days")
                
                return {
                    "success": True,
                    "deleted_records": record_count,
                    "cutoff_date": cutoff_date.isoformat()
                }
            else:
                return {
                    "success": True,
                    "deleted_records": 0,
                    "message": "No old records to clean up"
                }
                
        except Exception as e:
            await db.rollback()
            logger.error(f"Error cleaning up old metrics: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def clear_redis_cache(self) -> Dict[str, Any]:
        """Clear Redis cache"""
        try:
            redis_client = await get_redis()
            
            # Get cache info before clearing
            info = await redis_client.info("memory")
            used_memory_before = info.get("used_memory", 0)
            
            # Clear all keys
            await redis_client.flushall()
            
            # Get cache info after clearing  
            info_after = await redis_client.info("memory")
            used_memory_after = info_after.get("used_memory", 0)
            
            logger.info("Redis cache cleared successfully")
            
            return {
                "success": True,
                "memory_freed_bytes": used_memory_before - used_memory_after,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error clearing Redis cache: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def optimize_chromadb(self) -> Dict[str, Any]:
        """Optimize ChromaDB collections"""
        try:
            client = await get_chromadb_client()
            
            # Get collections list
            response = await client.get("/api/v1/collections")
            if response.status_code != 200:
                raise Exception(f"Failed to get collections: {response.text}")
                
            collections = response.json()
            results = []
            
            for collection in collections:
                try:
                    collection_name = collection["name"]
                    
                    # For each collection, we could trigger optimization
                    # This is a placeholder for ChromaDB-specific operations
                    logger.info(f"Processing ChromaDB collection: {collection_name}")
                    
                    results.append({
                        "collection": collection_name,
                        "status": "processed",
                        "documents": collection.get("metadata", {}).get("document_count", "unknown")
                    })
                    
                except Exception as e:
                    logger.error(f"Error processing collection {collection.get('name', 'unknown')}: {e}")
                    results.append({
                        "collection": collection.get("name", "unknown"),
                        "status": "failed",
                        "error": str(e)
                    })
            
            return {
                "success": True,
                "collections_processed": len(results),
                "results": results,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error optimizing ChromaDB: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def check_database_health(self, db: AsyncSession) -> Dict[str, Any]:
        """Check database health and connectivity"""
        health_checks = []
        
        try:
            # Test PostgreSQL connection
            try:
                result = await db.execute(text("SELECT version()"))
                pg_version = result.scalar()
                health_checks.append({
                    "component": "PostgreSQL",
                    "status": "healthy",
                    "version": pg_version[:50] + "..." if len(pg_version) > 50 else pg_version
                })
            except Exception as e:
                health_checks.append({
                    "component": "PostgreSQL", 
                    "status": "unhealthy",
                    "error": str(e)
                })
            
            # Test Redis connection
            try:
                redis_client = await get_redis()
                await redis_client.ping()
                info = await redis_client.info("server")
                health_checks.append({
                    "component": "Redis",
                    "status": "healthy",
                    "version": info.get("redis_version", "unknown")
                })
            except Exception as e:
                health_checks.append({
                    "component": "Redis",
                    "status": "unhealthy", 
                    "error": str(e)
                })
            
            # Test ChromaDB connection
            try:
                client = await get_chromadb_client()
                response = await client.get("/api/v1/heartbeat")
                if response.status_code == 200:
                    health_checks.append({
                        "component": "ChromaDB",
                        "status": "healthy",
                        "response_time": response.elapsed.total_seconds()
                    })
                else:
                    health_checks.append({
                        "component": "ChromaDB",
                        "status": "unhealthy",
                        "error": f"HTTP {response.status_code}"
                    })
            except Exception as e:
                health_checks.append({
                    "component": "ChromaDB",
                    "status": "unhealthy",
                    "error": str(e)
                })
            
            # Overall health status
            unhealthy_count = len([check for check in health_checks if check["status"] == "unhealthy"])
            overall_status = "healthy" if unhealthy_count == 0 else "degraded"
            
            return {
                "overall_status": overall_status,
                "components": health_checks,
                "timestamp": datetime.utcnow().isoformat(),
                "healthy_components": len(health_checks) - unhealthy_count,
                "total_components": len(health_checks)
            }
            
        except Exception as e:
            logger.error(f"Error checking database health: {e}")
            return {
                "overall_status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }