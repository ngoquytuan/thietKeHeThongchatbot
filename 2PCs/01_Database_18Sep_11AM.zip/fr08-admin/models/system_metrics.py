"""
System Metrics Database Model
"""

from sqlalchemy import Column, Integer, Float, String, DateTime, Index
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional

from config.database import Base


class SystemMetrics(Base):
    """Model for system_metrics table"""
    
    __tablename__ = "system_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    container_id = Column(String(64), nullable=True, index=True)
    response_time_ms = Column(Integer, nullable=True)
    cpu_usage_percent = Column(Float, nullable=True)
    memory_usage_mb = Column(Float, nullable=True)
    disk_io = Column(Float, nullable=True)
    network_throughput = Column(Float, nullable=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    
    # Composite indexes for better query performance
    __table_args__ = (
        Index('idx_system_metrics_container_timestamp', 'container_id', 'timestamp'),
        Index('idx_system_metrics_timestamp_desc', 'timestamp', ),
    )
    
    def __repr__(self):
        return f"<SystemMetrics(id={self.id}, container={self.container_id}, timestamp={self.timestamp})>"
    
    def to_dict(self):
        """Convert to dictionary for JSON serialization"""
        return {
            "id": self.id,
            "container_id": self.container_id,
            "response_time_ms": self.response_time_ms,
            "cpu_usage_percent": self.cpu_usage_percent,
            "memory_usage_mb": self.memory_usage_mb,
            "disk_io": self.disk_io,
            "network_throughput": self.network_throughput,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None
        }