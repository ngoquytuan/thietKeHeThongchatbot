#!/bin/bash

# FR-02.1 v2.0 Backup Script
# Automated backup for PostgreSQL, ChromaDB, and Redis

set -euo pipefail

# Configuration
BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7
LOG_FILE="/var/log/fr02-backup.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging function
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_info() {
    log "${BLUE}[INFO]${NC} $1"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    log "${RED}[ERROR]${NC} $1"
}

# Ensure backup directory exists
mkdir -p "$BACKUP_DIR"

log_info "Starting backup process: $DATE"

# PostgreSQL backup
backup_postgresql() {
    log_info "Starting PostgreSQL backup..."
    
    # Get password from environment or use default
    PGPASSWORD=${POSTGRES_PASSWORD:-changeme}
    
    # Create PostgreSQL backup
    if PGPASSWORD=$PGPASSWORD pg_dump -h localhost -U kb_admin -d knowledge_base_v2 --verbose \
        | gzip > "$BACKUP_DIR/postgres_backup_$DATE.sql.gz"; then
        log_success "PostgreSQL backup completed: postgres_backup_$DATE.sql.gz"
    else
        log_error "PostgreSQL backup failed"
        return 1
    fi
}

# ChromaDB backup
backup_chromadb() {
    log_info "Starting ChromaDB backup..."
    
    # Create ChromaDB backup using docker exec
    if docker-compose exec -T chroma /bin/sh -c "cd /chroma && tar czf - chroma/" \
        > "$BACKUP_DIR/chroma_backup_$DATE.tar.gz"; then
        log_success "ChromaDB backup completed: chroma_backup_$DATE.tar.gz"
    else
        log_error "ChromaDB backup failed"
        return 1
    fi
}

# Redis backup
backup_redis() {
    log_info "Starting Redis backup..."
    
    # Create Redis backup using BGSAVE and then copy the RDB file
    if docker-compose exec -T redis-master redis-cli BGSAVE; then
        # Wait for background save to complete
        while [ "$(docker-compose exec -T redis-master redis-cli LASTSAVE)" == "$(docker-compose exec -T redis-master redis-cli LASTSAVE)" ]; do
            sleep 1
        done
        
        # Copy the RDB file
        if docker-compose exec -T redis-master cat /data/dump.rdb \
            > "$BACKUP_DIR/redis_backup_$DATE.rdb"; then
            log_success "Redis backup completed: redis_backup_$DATE.rdb"
        else
            log_error "Redis backup file copy failed"
            return 1
        fi
    else
        log_error "Redis BGSAVE failed"
        return 1
    fi
}

# Configuration backup
backup_configuration() {
    log_info "Starting configuration backup..."
    
    # Backup all configuration files
    if tar czf "$BACKUP_DIR/config_backup_$DATE.tar.gz" \
        config/ docker-compose.yml .env 2>/dev/null; then
        log_success "Configuration backup completed: config_backup_$DATE.tar.gz"
    else
        log_error "Configuration backup failed"
        return 1
    fi
}

# Cleanup old backups
cleanup_old_backups() {
    log_info "Cleaning up old backups (retention: ${RETENTION_DAYS} days)..."
    
    # Remove backups older than retention period
    find "$BACKUP_DIR" -name "*backup*" -type f -mtime +$RETENTION_DAYS -delete
    
    # Count remaining backups
    BACKUP_COUNT=$(find "$BACKUP_DIR" -name "*backup*" -type f | wc -l)
    log_success "Cleanup completed. $BACKUP_COUNT backup files remaining"
}

# Verify backup integrity
verify_backups() {
    log_info "Verifying backup integrity..."
    
    # Check PostgreSQL backup
    if gzip -t "$BACKUP_DIR/postgres_backup_$DATE.sql.gz"; then
        log_success "PostgreSQL backup integrity verified"
    else
        log_error "PostgreSQL backup integrity check failed"
        return 1
    fi
    
    # Check ChromaDB backup
    if tar -tzf "$BACKUP_DIR/chroma_backup_$DATE.tar.gz" >/dev/null; then
        log_success "ChromaDB backup integrity verified"
    else
        log_error "ChromaDB backup integrity check failed"
        return 1
    fi
    
    # Check Redis backup (basic file existence and size)
    if [ -f "$BACKUP_DIR/redis_backup_$DATE.rdb" ] && [ -s "$BACKUP_DIR/redis_backup_$DATE.rdb" ]; then
        log_success "Redis backup integrity verified"
    else
        log_error "Redis backup integrity check failed"
        return 1
    fi
    
    # Check configuration backup
    if tar -tzf "$BACKUP_DIR/config_backup_$DATE.tar.gz" >/dev/null; then
        log_success "Configuration backup integrity verified"
    else
        log_error "Configuration backup integrity check failed"
        return 1
    fi
}

# Generate backup report
generate_backup_report() {
    log_info "Generating backup report..."
    
    REPORT_FILE="$BACKUP_DIR/backup_report_$DATE.txt"
    
    cat > "$REPORT_FILE" << EOF
FR-02.1 v2.0 Backup Report
==========================
Date: $(date)
Backup ID: $DATE

Backup Files:
- PostgreSQL: postgres_backup_$DATE.sql.gz ($(ls -lh "$BACKUP_DIR/postgres_backup_$DATE.sql.gz" | awk '{print $5}'))
- ChromaDB: chroma_backup_$DATE.tar.gz ($(ls -lh "$BACKUP_DIR/chroma_backup_$DATE.tar.gz" | awk '{print $5}'))
- Redis: redis_backup_$DATE.rdb ($(ls -lh "$BACKUP_DIR/redis_backup_$DATE.rdb" | awk '{print $5}'))
- Configuration: config_backup_$DATE.tar.gz ($(ls -lh "$BACKUP_DIR/config_backup_$DATE.tar.gz" | awk '{print $5}'))

Storage Usage:
$(df -h "$BACKUP_DIR" | tail -1)

Retention Policy: $RETENTION_DAYS days
Total Backup Files: $(find "$BACKUP_DIR" -name "*backup*" -type f | wc -l)

Status: SUCCESS
EOF
    
    log_success "Backup report generated: backup_report_$DATE.txt"
}

# Send notification (optional)
send_notification() {
    local status=$1
    local message=$2
    
    # You can implement email notifications, Slack webhooks, etc. here
    # For now, just log the notification
    log_info "NOTIFICATION: $status - $message"
}

# Main backup function
main() {
    local overall_status="SUCCESS"
    local failed_services=""
    
    # Execute backup procedures
    if ! backup_postgresql; then
        overall_status="PARTIAL_FAILURE"
        failed_services="$failed_services PostgreSQL"
    fi
    
    if ! backup_chromadb; then
        overall_status="PARTIAL_FAILURE"
        failed_services="$failed_services ChromaDB"
    fi
    
    if ! backup_redis; then
        overall_status="PARTIAL_FAILURE"
        failed_services="$failed_services Redis"
    fi
    
    if ! backup_configuration; then
        overall_status="PARTIAL_FAILURE"
        failed_services="$failed_services Configuration"
    fi
    
    # Only verify and cleanup if we have some successful backups
    if [ "$overall_status" != "FAILURE" ]; then
        verify_backups || overall_status="PARTIAL_FAILURE"
        cleanup_old_backups
        generate_backup_report
    fi
    
    # Final status report
    if [ "$overall_status" == "SUCCESS" ]; then
        log_success "🎉 All backups completed successfully!"
        send_notification "SUCCESS" "FR-02.1 v2.0 backup completed successfully"
    elif [ "$overall_status" == "PARTIAL_FAILURE" ]; then
        log_error "⚠️ Backup completed with failures in:$failed_services"
        send_notification "PARTIAL_FAILURE" "FR-02.1 v2.0 backup completed with failures:$failed_services"
    else
        log_error "❌ Backup process failed completely"
        send_notification "FAILURE" "FR-02.1 v2.0 backup process failed"
        exit 1
    fi
    
    log_info "Backup process completed: $DATE"
}

# Error handling
trap 'log_error "Backup script failed at line $LINENO"' ERR

# Run main function
main "$@"