#!/bin/bash

# FR-02.1 v2.0 Restore Script
# Restore from backups for PostgreSQL, ChromaDB, and Redis

set -euo pipefail

# Configuration
BACKUP_DIR="/opt/backups"
LOG_FILE="/var/log/fr02-restore.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging function
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_info() {
    log "${BLUE}[INFO]${NC} $1"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    log "${RED}[ERROR]${NC} $1"
}

log_warning() {
    log "${YELLOW}[WARNING]${NC} $1"
}

# Usage function
usage() {
    echo "Usage: $0 [OPTIONS] BACKUP_DATE"
    echo ""
    echo "Options:"
    echo "  -h, --help           Show this help message"
    echo "  -p, --postgres-only  Restore PostgreSQL only"
    echo "  -c, --chroma-only    Restore ChromaDB only"
    echo "  -r, --redis-only     Restore Redis only"
    echo "  -f, --force          Force restore without confirmation"
    echo "  --list               List available backups"
    echo ""
    echo "Example:"
    echo "  $0 20231215_143022    # Restore all services from backup"
    echo "  $0 -p 20231215_143022 # Restore PostgreSQL only"
    echo "  $0 --list            # List available backups"
}

# List available backups
list_backups() {
    log_info "Available backups in $BACKUP_DIR:"
    echo ""
    
    # Find all backup dates
    backup_dates=$(find "$BACKUP_DIR" -name "*backup_*.sql.gz" -o -name "*backup_*.tar.gz" -o -name "*backup_*.rdb" | \
                   sed 's/.*backup_\([0-9]\{8\}_[0-9]\{6\}\).*/\1/' | sort -u)
    
    if [ -z "$backup_dates" ]; then
        echo "No backups found in $BACKUP_DIR"
        return 1
    fi
    
    printf "%-20s %-15s %-15s %-15s %-15s\n" "BACKUP_DATE" "PostgreSQL" "ChromaDB" "Redis" "Config"
    printf "%-20s %-15s %-15s %-15s %-15s\n" "$(printf '=%.0s' {1..20})" "$(printf '=%.0s' {1..15})" "$(printf '=%.0s' {1..15})" "$(printf '=%.0s' {1..15})" "$(printf '=%.0s' {1..15})"
    
    for date in $backup_dates; do
        pg_status="❌"
        chroma_status="❌"
        redis_status="❌"
        config_status="❌"
        
        [ -f "$BACKUP_DIR/postgres_backup_$date.sql.gz" ] && pg_status="✅"
        [ -f "$BACKUP_DIR/chroma_backup_$date.tar.gz" ] && chroma_status="✅"
        [ -f "$BACKUP_DIR/redis_backup_$date.rdb" ] && redis_status="✅"
        [ -f "$BACKUP_DIR/config_backup_$date.tar.gz" ] && config_status="✅"
        
        printf "%-20s %-15s %-15s %-15s %-15s\n" "$date" "$pg_status" "$chroma_status" "$redis_status" "$config_status"
    done
}

# Confirm restore operation
confirm_restore() {
    local backup_date=$1
    local services=$2
    
    echo ""
    log_warning "⚠️  WARNING: This will overwrite existing data!"
    echo "Backup date: $backup_date"
    echo "Services to restore: $services"
    echo ""
    
    read -p "Are you sure you want to continue? (yes/no): " confirm
    if [ "$confirm" != "yes" ]; then
        log_info "Restore operation cancelled"
        exit 0
    fi
}

# Restore PostgreSQL
restore_postgresql() {
    local backup_date=$1
    local backup_file="$BACKUP_DIR/postgres_backup_$backup_date.sql.gz"
    
    log_info "Starting PostgreSQL restore from $backup_file..."
    
    # Check if backup file exists
    if [ ! -f "$backup_file" ]; then
        log_error "PostgreSQL backup file not found: $backup_file"
        return 1
    fi
    
    # Get password from environment
    PGPASSWORD=${POSTGRES_PASSWORD:-changeme}
    
    # Stop connections to the database
    log_info "Terminating existing connections to knowledge_base_v2..."
    PGPASSWORD=$PGPASSWORD psql -h localhost -U kb_admin -d postgres -c "
        SELECT pg_terminate_backend(pid) 
        FROM pg_stat_activity 
        WHERE datname = 'knowledge_base_v2' AND pid <> pg_backend_pid();"
    
    # Drop and recreate database
    log_info "Dropping and recreating database..."
    PGPASSWORD=$PGPASSWORD dropdb -h localhost -U kb_admin --if-exists knowledge_base_v2
    PGPASSWORD=$PGPASSWORD createdb -h localhost -U kb_admin knowledge_base_v2
    
    # Restore from backup
    log_info "Restoring database from backup..."
    if gunzip -c "$backup_file" | PGPASSWORD=$PGPASSWORD psql -h localhost -U kb_admin -d knowledge_base_v2 > /dev/null; then
        log_success "PostgreSQL restore completed successfully"
    else
        log_error "PostgreSQL restore failed"
        return 1
    fi
}

# Restore ChromaDB
restore_chromadb() {
    local backup_date=$1
    local backup_file="$BACKUP_DIR/chroma_backup_$backup_date.tar.gz"
    
    log_info "Starting ChromaDB restore from $backup_file..."
    
    # Check if backup file exists
    if [ ! -f "$backup_file" ]; then
        log_error "ChromaDB backup file not found: $backup_file"
        return 1
    fi
    
    # Stop ChromaDB container
    log_info "Stopping ChromaDB container..."
    docker-compose stop chroma
    
    # Clear existing data
    log_info "Clearing existing ChromaDB data..."
    docker volume rm fr02-dual-database-v2_chroma_data || true
    
    # Start ChromaDB container
    log_info "Starting ChromaDB container..."
    docker-compose up -d chroma
    
    # Wait for ChromaDB to be ready
    sleep 10
    
    # Restore data
    log_info "Restoring ChromaDB data..."
    if docker-compose exec -T chroma /bin/sh -c "cd / && tar xzf -" < "$backup_file"; then
        log_success "ChromaDB restore completed successfully"
        
        # Restart ChromaDB to ensure data is loaded
        docker-compose restart chroma
        sleep 10
    else
        log_error "ChromaDB restore failed"
        return 1
    fi
}

# Restore Redis
restore_redis() {
    local backup_date=$1
    local backup_file="$BACKUP_DIR/redis_backup_$backup_date.rdb"
    
    log_info "Starting Redis restore from $backup_file..."
    
    # Check if backup file exists
    if [ ! -f "$backup_file" ]; then
        log_error "Redis backup file not found: $backup_file"
        return 1
    fi
    
    # Stop Redis containers
    log_info "Stopping Redis containers..."
    docker-compose stop redis-master redis-replica
    
    # Clear existing Redis data
    docker volume rm fr02-dual-database-v2_redis_data || true
    docker volume rm fr02-dual-database-v2_redis_replica_data || true
    
    # Start Redis master
    log_info "Starting Redis master..."
    docker-compose up -d redis-master
    sleep 5
    
    # Stop Redis to restore data
    docker-compose exec redis-master redis-cli shutdown nosave || true
    
    # Copy backup file to Redis data directory
    log_info "Restoring Redis data..."
    if docker cp "$backup_file" fr02-redis-master:/data/dump.rdb; then
        # Start Redis with restored data
        docker-compose start redis-master
        sleep 5
        
        # Start replica
        docker-compose up -d redis-replica
        sleep 5
        
        log_success "Redis restore completed successfully"
    else
        log_error "Redis restore failed"
        return 1
    fi
}

# Restore configuration
restore_configuration() {
    local backup_date=$1
    local backup_file="$BACKUP_DIR/config_backup_$backup_date.tar.gz"
    
    log_info "Starting configuration restore from $backup_file..."
    
    # Check if backup file exists
    if [ ! -f "$backup_file" ]; then
        log_error "Configuration backup file not found: $backup_file"
        return 1
    fi
    
    # Create backup of current configuration
    log_info "Backing up current configuration..."
    tar czf "config_backup_current_$(date +%Y%m%d_%H%M%S).tar.gz" config/ docker-compose.yml .env 2>/dev/null || true
    
    # Restore configuration
    log_info "Restoring configuration files..."
    if tar xzf "$backup_file"; then
        log_success "Configuration restore completed successfully"
    else
        log_error "Configuration restore failed"
        return 1
    fi
}

# Post-restore verification
verify_restore() {
    log_info "Verifying restore operation..."
    
    # Wait for services to be ready
    sleep 30
    
    # Check PostgreSQL
    if PGPASSWORD=${POSTGRES_PASSWORD:-changeme} psql -h localhost -U kb_admin -d knowledge_base_v2 -c "SELECT COUNT(*) FROM users;" > /dev/null 2>&1; then
        log_success "✅ PostgreSQL verification passed"
    else
        log_error "❌ PostgreSQL verification failed"
    fi
    
    # Check ChromaDB
    if curl -f http://localhost:8000/api/v1/heartbeat > /dev/null 2>&1; then
        log_success "✅ ChromaDB verification passed"
    else
        log_error "❌ ChromaDB verification failed"
    fi
    
    # Check Redis
    if docker-compose exec redis-master redis-cli ping | grep PONG > /dev/null 2>&1; then
        log_success "✅ Redis verification passed"
    else
        log_error "❌ Redis verification failed"
    fi
}

# Main restore function
main() {
    local backup_date=""
    local postgres_only=false
    local chroma_only=false
    local redis_only=false
    local force=false
    local services="PostgreSQL, ChromaDB, Redis, Configuration"
    
    # Parse command line arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                usage
                exit 0
                ;;
            -p|--postgres-only)
                postgres_only=true
                services="PostgreSQL"
                shift
                ;;
            -c|--chroma-only)
                chroma_only=true
                services="ChromaDB"
                shift
                ;;
            -r|--redis-only)
                redis_only=true
                services="Redis"
                shift
                ;;
            -f|--force)
                force=true
                shift
                ;;
            --list)
                list_backups
                exit 0
                ;;
            -*)
                log_error "Unknown option: $1"
                usage
                exit 1
                ;;
            *)
                backup_date=$1
                shift
                ;;
        esac
    done
    
    # Check if backup date is provided
    if [ -z "$backup_date" ]; then
        log_error "Backup date is required"
        usage
        exit 1
    fi
    
    # Validate backup date format
    if ! [[ "$backup_date" =~ ^[0-9]{8}_[0-9]{6}$ ]]; then
        log_error "Invalid backup date format. Expected: YYYYMMDD_HHMMSS"
        exit 1
    fi
    
    # Confirm restore operation unless forced
    if [ "$force" != true ]; then
        confirm_restore "$backup_date" "$services"
    fi
    
    log_info "Starting restore process for backup: $backup_date"
    
    # Execute restore operations
    local overall_status="SUCCESS"
    
    if [ "$postgres_only" == true ]; then
        restore_postgresql "$backup_date" || overall_status="FAILURE"
    elif [ "$chroma_only" == true ]; then
        restore_chromadb "$backup_date" || overall_status="FAILURE"
    elif [ "$redis_only" == true ]; then
        restore_redis "$backup_date" || overall_status="FAILURE"
    else
        # Restore all services
        restore_postgresql "$backup_date" || overall_status="PARTIAL_FAILURE"
        restore_chromadb "$backup_date" || overall_status="PARTIAL_FAILURE"
        restore_redis "$backup_date" || overall_status="PARTIAL_FAILURE"
        restore_configuration "$backup_date" || overall_status="PARTIAL_FAILURE"
    fi
    
    # Verify restore
    verify_restore
    
    # Final status report
    if [ "$overall_status" == "SUCCESS" ]; then
        log_success "🎉 Restore completed successfully!"
    else
        log_error "⚠️ Restore completed with some failures"
    fi
    
    log_info "Restore process completed for backup: $backup_date"
}

# Error handling
trap 'log_error "Restore script failed at line $LINENO"' ERR

# Run main function
main "$@"