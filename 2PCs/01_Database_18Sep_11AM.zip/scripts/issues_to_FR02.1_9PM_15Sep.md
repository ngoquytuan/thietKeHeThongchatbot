# FR02.1 Database Schema Issues for FR03.3 Integration

**Report Date**: September 15, 2025
**Issue Category**: Database Schema Compatibility
**Priority**: High - Blocking FR03.3 Document Submission
**Status**: Analysis Complete - Requires FR02.1 Database Schema Updates

## 🎯 **Executive Summary**

FR03.3 Data Ingestion Pipeline cannot submit documents to the shared database due to a **critical schema mismatch** in the `data_ingestion_jobs` table. While FR02.1 database v3.0 includes this table, it's **missing the `document_id` column** that FR03.3 requires for its job tracking functionality.

## 🔍 **Root Cause Analysis**

### **The Error**
```
sqlalchemy.dialects.postgresql.asyncpg.ProgrammingError:
column "document_id" of relation "data_ingestion_jobs" does not exist
```

### **Schema Comparison**

#### **FR03.3 Expected Schema** (from `src/models/document_models.py`)
```sql
CREATE TABLE data_ingestion_jobs (
    job_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL,                    -- ❌ MISSING IN FR02.1
    source_file VARCHAR(500) NOT NULL,
    status ENUM(DocumentStatus) DEFAULT 'PENDING',
    current_stage ENUM(ProcessingStage),
    total_chunks INTEGER DEFAULT 0,
    processed_chunks INTEGER DEFAULT 0,
    failed_chunks INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT utcnow,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    processing_metadata JSON,
    quality_score INTEGER,                        -- ❌ MISSING IN FR02.1
    quality_passed BOOLEAN DEFAULT FALSE,         -- ❌ MISSING IN FR02.1
    processing_duration_ms INTEGER                -- ❌ MISSING IN FR02.1
);
```

#### **FR02.1 Current Schema** (from `01_init_database_V3.sql` lines 448-488)
```sql
CREATE TABLE data_ingestion_jobs (
    job_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    job_name VARCHAR(255) NOT NULL,               -- ❌ NOT IN FR03.3
    job_type VARCHAR(50) DEFAULT 'document_processing',
    source_path VARCHAR(1000),                    -- ❌ DIFFERENT FROM source_file
    target_collection VARCHAR(100),               -- ❌ NOT IN FR03.3
    chunking_method chunking_method_enum,         -- ❌ NOT IN FR03.3
    chunk_size_tokens INTEGER DEFAULT 512,       -- ❌ NOT IN FR03.3
    overlap_tokens INTEGER DEFAULT 50,           -- ❌ NOT IN FR03.3
    embedding_model VARCHAR(100),                -- ❌ NOT IN FR03.3
    status VARCHAR(50) DEFAULT 'pending',        -- ❌ DIFFERENT TYPE (STRING vs ENUM)
    progress_percentage DECIMAL(5,2),            -- ❌ NOT IN FR03.3
    documents_processed INTEGER DEFAULT 0,       -- ❌ NOT IN FR03.3
    chunks_created INTEGER DEFAULT 0,            -- ❌ NOT IN FR03.3
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    processing_time_seconds DOUBLE PRECISION,    -- ❌ DIFFERENT FROM processing_duration_ms
    estimated_completion_time TIMESTAMP,         -- ❌ NOT IN FR03.3
    success_count INTEGER DEFAULT 0,             -- ❌ NOT IN FR03.3
    error_count INTEGER DEFAULT 0,               -- ❌ NOT IN FR03.3
    warning_count INTEGER DEFAULT 0,             -- ❌ NOT IN FR03.3
    error_log TEXT[],                            -- ❌ DIFFERENT FROM error_message
    memory_peak_mb DOUBLE PRECISION,             -- ❌ NOT IN FR03.3
    cpu_time_seconds DOUBLE PRECISION,           -- ❌ NOT IN FR03.3
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()           -- ❌ NOT IN FR03.3
);
```

## 🚨 **Critical Missing Columns**

### **Priority 1: Blocking Columns**
1. **`document_id`** - `UUID NOT NULL`
   - **Impact**: Complete failure of document submission
   - **Purpose**: Links processing jobs to document records
   - **Required**: Immediate addition

### **Priority 2: Quality Control Columns**
2. **`quality_score`** - `INTEGER`
   - **Purpose**: Stores quality assessment results from FR03.2
   - **Default**: `NULL`

3. **`quality_passed`** - `BOOLEAN DEFAULT FALSE`
   - **Purpose**: Tracks if document passed quality thresholds
   - **Integration**: Links to FR03.2 quality assessment

4. **`processing_duration_ms`** - `INTEGER`
   - **Purpose**: Performance tracking in milliseconds
   - **Current**: FR02.1 uses `processing_time_seconds` (different unit/type)

### **Priority 3: Job Structure Columns**
5. **`source_file`** - `VARCHAR(500) NOT NULL`
   - **Purpose**: Specific file path for processing
   - **Current**: FR02.1 uses `source_path` (different semantic meaning)

6. **`current_stage`** - `ENUM(ProcessingStage)`
   - **Purpose**: Tracks pipeline stage (quality_control, chunking, embedding, storage, indexing)
   - **Missing**: No equivalent in FR02.1

7. **`total_chunks`** - `INTEGER DEFAULT 0`
   - **Purpose**: Expected chunk count for progress tracking
   - **Current**: FR02.1 uses `chunks_created` (different semantic meaning)

8. **`processed_chunks`** - `INTEGER DEFAULT 0`
   - **Purpose**: Successfully processed chunks count

9. **`failed_chunks`** - `INTEGER DEFAULT 0`
   - **Purpose**: Failed chunk processing count

## 🏗️ **Required Database Schema Updates**

### **Migration Script Required**
```sql
-- FR03.3 Integration Schema Migration
-- Add missing columns to data_ingestion_jobs table

ALTER TABLE data_ingestion_jobs
ADD COLUMN document_id UUID,
ADD COLUMN source_file VARCHAR(500),
ADD COLUMN current_stage VARCHAR(50), -- Will need enum later
ADD COLUMN total_chunks INTEGER DEFAULT 0,
ADD COLUMN processed_chunks INTEGER DEFAULT 0,
ADD COLUMN failed_chunks INTEGER DEFAULT 0,
ADD COLUMN quality_score INTEGER,
ADD COLUMN quality_passed BOOLEAN DEFAULT FALSE,
ADD COLUMN processing_duration_ms INTEGER,
ADD COLUMN error_message TEXT;

-- Add foreign key constraint
ALTER TABLE data_ingestion_jobs
ADD CONSTRAINT fk_data_ingestion_jobs_document_id
FOREIGN KEY (document_id) REFERENCES documents_metadata_v2(document_id);

-- Create the missing enums
CREATE TYPE documentstatus AS ENUM (
    'PENDING', 'PROCESSING', 'QUALITY_CHECK', 'CHUNKING',
    'EMBEDDING', 'STORAGE', 'INDEXING', 'COMPLETED',
    'FAILED', 'CANCELLED', 'RETRYING'
);

CREATE TYPE processingstage AS ENUM (
    'quality_control', 'chunking', 'embedding', 'storage', 'indexing'
);

-- Update column types
ALTER TABLE data_ingestion_jobs
ALTER COLUMN status TYPE documentstatus USING status::documentstatus,
ALTER COLUMN current_stage TYPE processingstage USING current_stage::processingstage;
```

## 📋 **Additional Schema Requirements**

### **Missing Tables**
FR03.3 also expects these tables that may not exist in FR02.1:

1. **`chunk_processing_logs`** - Individual chunk processing tracking
2. **`pipeline_metrics`** - Pipeline performance metrics
3. **`processing_errors`** - Error logging and analysis

### **Missing Enums**
1. **`DocumentStatus`** enum with FR03.3 specific values
2. **`ProcessingStage`** enum for pipeline stages

## 🔧 **Recommended Solution**

### **Phase 1: Critical Fix (Immediate)**
1. Add `document_id` column to `data_ingestion_jobs` table
2. Add `source_file` column
3. Add basic quality tracking columns (`quality_score`, `quality_passed`)

### **Phase 2: Full Compatibility (Next Iteration)**
1. Add all missing columns from FR03.3 schema
2. Create missing enums with proper types
3. Add missing tables (`chunk_processing_logs`, `pipeline_metrics`, `processing_errors`)
4. Update indexes for new columns

### **Phase 3: Schema Unification (Future)**
1. Reconcile duplicate/overlapping columns
2. Create unified schema that serves both FR02.1 and FR03.3 needs
3. Deprecate redundant columns

## 🚀 **Implementation Steps**

### **For FR02.1 Team:**
1. **Create migration script** with Phase 1 changes
2. **Test migration** on development database
3. **Apply to production** database used by both systems
4. **Verify compatibility** with existing FR02.1 functionality

### **For FR03.3 Team:**
1. **Update models** to handle optional new columns gracefully
2. **Add fallback logic** for missing columns during transition
3. **Test integration** after FR02.1 schema updates

## 📊 **Impact Assessment**

### **Risk Level**: Medium-High
- **Blocking Issue**: Document submission completely fails
- **Compatibility**: May affect existing FR02.1 functionality
- **Data Integrity**: Requires careful migration planning

### **Effort Estimate**:
- **Database Migration**: 2-4 hours
- **Testing**: 4-8 hours
- **Coordination**: 2-4 hours
- **Total**: 1-2 days

## 🎯 **Success Criteria**

✅ **FR03.3 can successfully submit documents**
✅ **FR02.1 functionality remains unaffected**
✅ **Quality assessment integration works**
✅ **No data loss during migration**
✅ **Performance impact is minimal**

## 📞 **Next Actions**

1. **FR02.1 Database Team**: Review and approve migration script
2. **DevOps**: Schedule maintenance window for schema update
3. **FR03.3 Team**: Prepare integration testing procedures
4. **QA**: Develop comprehensive test cases for both systems

---

**Generated**: September 15, 2025
**Context**: FR03.2 Document Quality Assessment Integration
**Reporter**: Claude Code Assistant
**Priority**: HIGH - Blocking Integration