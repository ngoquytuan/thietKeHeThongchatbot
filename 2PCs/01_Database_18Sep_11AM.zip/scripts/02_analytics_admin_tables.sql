-- ================================
-- FR-07 ANALYTICS TABLES
-- ================================

-- Search Analytics
CREATE TABLE IF NOT EXISTS search_analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    query_text TEXT NOT NULL,
    processing_time_ms INTEGER,
    results_count INTEGER,
    has_results BOOLEAN DEFAULT FALSE,
    cache_hit BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- User Activity Summary
CREATE TABLE IF NOT EXISTS user_activity_summary (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    date DATE NOT NULL,
    search_count INTEGER DEFAULT 0,
    session_duration_minutes INTEGER DEFAULT 0,
    documents_accessed INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, date)
);

-- Document Usage Statistics
CREATE TABLE IF NOT EXISTS document_usage_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES documents_metadata_v2(document_id),
    access_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMPTZ,
    most_frequent_user_level user_level,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- System Metrics
CREATE TABLE IF NOT EXISTS system_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(100) NOT NULL,
    metric_value FLOAT,
    metric_unit VARCHAR(20),
    component VARCHAR(50),
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Analytics Cache
CREATE TABLE IF NOT EXISTS analytics_cache (
    cache_key VARCHAR(255) PRIMARY KEY,
    cache_value JSONB NOT NULL,
    cache_type VARCHAR(50) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ================================
-- FR-08 ADMIN TABLES
-- ================================

-- Admin Actions Log
CREATE TABLE IF NOT EXISTS admin_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_user_id UUID REFERENCES users(user_id),
    action_type VARCHAR(50) NOT NULL,
    target_resource VARCHAR(100),
    target_id VARCHAR(100),
    action_details JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- System Health Log
CREATE TABLE IF NOT EXISTS system_health_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component_name VARCHAR(50) NOT NULL,
    status VARCHAR(20) CHECK (status IN ('healthy', 'unhealthy', 'degraded')),
    cpu_usage FLOAT,
    memory_usage FLOAT,
    disk_usage FLOAT,
    response_time_ms INTEGER,
    error_message TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Backup Status
CREATE TABLE IF NOT EXISTS backup_status (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    backup_type VARCHAR(50) NOT NULL,
    backup_path VARCHAR(500),
    file_size_bytes BIGINT,
    status VARCHAR(20) CHECK (status IN ('started', 'completed', 'failed')),
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_message TEXT
);

-- ================================
-- INDEXES FOR PERFORMANCE
-- ================================

-- Analytics indexes
CREATE INDEX IF NOT EXISTS idx_search_analytics_timestamp ON search_analytics(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_search_analytics_user_date ON search_analytics(user_id, DATE(timestamp));
CREATE INDEX IF NOT EXISTS idx_user_activity_date ON user_activity_summary(date DESC);
CREATE INDEX IF NOT EXISTS idx_document_usage_access_count ON document_usage_stats(access_count DESC);
CREATE INDEX IF NOT EXISTS idx_system_metrics_component_timestamp ON system_metrics(component, timestamp DESC);

-- Admin indexes
CREATE INDEX IF NOT EXISTS idx_admin_actions_admin_timestamp ON admin_actions(admin_user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_admin_actions_type_timestamp ON admin_actions(action_type, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_system_health_component_timestamp ON system_health_log(component_name, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_backup_status_timestamp ON backup_status(started_at DESC);

-- ================================
-- INSERT SAMPLE DATA FOR TESTING
-- ================================

-- Insert sample analytics data
INSERT INTO search_analytics (user_id, query_text, processing_time_ms, results_count, has_results, cache_hit)
SELECT
    user_id,
    'sample search query ' || floor(random() * 100),
    floor(random() * 2000 + 100)::integer,
    floor(random() * 50)::integer,
    random() > 0.3,
    random() > 0.7
FROM users LIMIT 5
ON CONFLICT DO NOTHING;

-- Insert sample system metrics
INSERT INTO system_metrics (metric_name, metric_value, metric_unit, component)
VALUES
    ('cpu_usage', 45.2, 'percent', 'fr02-main'),
    ('memory_usage', 512.8, 'MB', 'fr02-main'),
    ('response_time', 150, 'ms', 'api'),
    ('disk_usage', 75.5, 'percent', 'postgres')
ON CONFLICT DO NOTHING;

COMMIT;