#!/bin/bash

# FR-02.1 v2.0 System Validation Script
# Comprehensive validation of the dual database system

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Validation results
VALIDATION_RESULTS=()
TOTAL_CHECKS=0
PASSED_CHECKS=0

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validation function
validate() {
    local test_name="$1"
    local command="$2"
    local expected_result="${3:-0}"
    
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    echo -n "Testing ${test_name}... "
    
    if eval "$command" > /dev/null 2>&1; then
        if [ $? -eq $expected_result ]; then
            echo -e "${GREEN}✅ PASS${NC}"
            VALIDATION_RESULTS+=("✅ $test_name")
            PASSED_CHECKS=$((PASSED_CHECKS + 1))
        else
            echo -e "${RED}❌ FAIL${NC}"
            VALIDATION_RESULTS+=("❌ $test_name")
        fi
    else
        echo -e "${RED}❌ FAIL${NC}"
        VALIDATION_RESULTS+=("❌ $test_name")
    fi
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    validate "Docker installed" "command -v docker"
    validate "Docker Compose installed" "command -v docker-compose"
    validate "curl available" "command -v curl"
    validate "PostgreSQL client available" "command -v psql"
}

# Check Docker containers
check_containers() {
    log_info "Checking Docker containers..."
    
    validate "PostgreSQL container running" "docker-compose ps postgres | grep -q 'Up'"
    validate "ChromaDB container running" "docker-compose ps chroma | grep -q 'Up'"
    validate "Redis Master running" "docker-compose ps redis-master | grep -q 'Up'"
    validate "Redis Replica running" "docker-compose ps redis-replica | grep -q 'Up'"
    validate "Prometheus running" "docker-compose ps prometheus | grep -q 'Up'"
    validate "Grafana running" "docker-compose ps grafana | grep -q 'Up'"
    validate "NGINX running" "docker-compose ps nginx | grep -q 'Up'"
}

# Check service connectivity
check_services() {
    log_info "Checking service connectivity..."
    
    validate "PostgreSQL connection" "docker-compose exec postgres pg_isready -U kb_admin -d knowledge_base_v2"
    validate "ChromaDB health" "curl -f http://localhost:8000/api/v1/heartbeat"
    validate "Redis Master connection" "docker-compose exec redis-master redis-cli ping | grep -q PONG"
    validate "Prometheus health" "curl -f http://localhost:9090/-/healthy"
    validate "Grafana health" "curl -f http://localhost:3000/api/health"
    validate "NGINX health" "curl -f http://localhost/health"
}

# Check database schema
check_database_schema() {
    log_info "Checking database schema..."
    
    # Check if required tables exist
    local tables=("users" "documents_metadata_v2" "document_chunks_enhanced" "vietnamese_text_analysis" "data_ingestion_jobs" "system_health_metrics")
    
    for table in "${tables[@]}"; do
        validate "Table $table exists" "docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -c \"SELECT 1 FROM $table LIMIT 1;\""
    done
    
    # Check Vietnamese functions
    validate "Vietnamese text normalization function" "docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -c \"SELECT normalize_vietnamese_text('Hướng dẫn');\""
    validate "Email extraction function" "docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -c \"SELECT extract_emails_from_text('test@example.com');\""
}

# Check ChromaDB collections
check_chromadb() {
    log_info "Checking ChromaDB configuration..."
    
    validate "ChromaDB API access" "curl -f http://localhost:8000/api/v1/collections"
    validate "ChromaDB version" "curl -f http://localhost:8000/api/v1/version"
    
    # Test collection creation (will be cleaned up)
    local test_collection="validation_test_$(date +%s)"
    validate "ChromaDB collection creation" "curl -f -X POST http://localhost:8000/api/v1/collections -H 'Content-Type: application/json' -d '{\"name\": \"$test_collection\", \"metadata\": {\"description\": \"validation test\"}}'"
    
    # Cleanup test collection
    curl -f -X DELETE "http://localhost:8000/api/v1/collections/$test_collection" > /dev/null 2>&1 || true
}

# Check Redis functionality
check_redis() {
    log_info "Checking Redis functionality..."
    
    validate "Redis SET operation" "docker-compose exec redis-master redis-cli SET validation_test 'test_value'"
    validate "Redis GET operation" "docker-compose exec redis-master redis-cli GET validation_test | grep -q 'test_value'"
    validate "Redis replication" "docker-compose exec redis-replica redis-cli GET validation_test | grep -q 'test_value'"
    
    # Cleanup test data
    docker-compose exec redis-master redis-cli DEL validation_test > /dev/null 2>&1 || true
}

# Check monitoring
check_monitoring() {
    log_info "Checking monitoring setup..."
    
    validate "Prometheus targets" "curl -f http://localhost:9090/api/v1/targets | grep -q '\"health\":\"up\"'"
    validate "PostgreSQL metrics" "curl -f http://localhost:9090/api/v1/query?query=pg_up"
    validate "Redis metrics" "curl -f http://localhost:9090/api/v1/query?query=redis_up"
    validate "Node exporter metrics" "curl -f http://localhost:9090/api/v1/query?query=up{job=\"node\"}"
    
    # Check if Grafana can access Prometheus
    local grafana_password=${GRAFANA_PASSWORD:-admin}
    validate "Grafana Prometheus datasource" "curl -f -u admin:$grafana_password http://localhost:3000/api/datasources | grep -q prometheus"
}

# Check file permissions and security
check_security() {
    log_info "Checking security configuration..."
    
    validate "Environment file permissions" "[ \$(stat -c %a .env 2>/dev/null || echo '000') = '600' ]"
    validate "Backup directory exists" "[ -d '/opt/backups' ] || [ -d 'backups' ]"
    validate "Log directory writable" "touch logs/test.log && rm logs/test.log"
}

# Performance validation
check_performance() {
    log_info "Running performance validation..."
    
    # Test database query performance
    local start_time=$(date +%s%N)
    docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -c "SELECT COUNT(*) FROM users;" > /dev/null 2>&1
    local end_time=$(date +%s%N)
    local duration=$(( (end_time - start_time) / 1000000 )) # Convert to milliseconds
    
    if [ $duration -lt 1000 ]; then
        echo -e "Database query performance: ${GREEN}✅ ${duration}ms (<1000ms)${NC}"
        VALIDATION_RESULTS+=("✅ Database query performance: ${duration}ms")
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        echo -e "Database query performance: ${YELLOW}⚠️ ${duration}ms (>1000ms)${NC}"
        VALIDATION_RESULTS+=("⚠️ Database query performance: ${duration}ms")
    fi
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    
    # Test Redis performance
    start_time=$(date +%s%N)
    docker-compose exec redis-master redis-cli SET perf_test "value" > /dev/null 2>&1
    docker-compose exec redis-master redis-cli GET perf_test > /dev/null 2>&1
    docker-compose exec redis-master redis-cli DEL perf_test > /dev/null 2>&1
    end_time=$(date +%s%N)
    duration=$(( (end_time - start_time) / 1000000 ))
    
    if [ $duration -lt 100 ]; then
        echo -e "Redis performance: ${GREEN}✅ ${duration}ms (<100ms)${NC}"
        VALIDATION_RESULTS+=("✅ Redis performance: ${duration}ms")
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
    else
        echo -e "Redis performance: ${YELLOW}⚠️ ${duration}ms (>100ms)${NC}"
        VALIDATION_RESULTS+=("⚠️ Redis performance: ${duration}ms")
    fi
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
}

# Generate validation report
generate_report() {
    local report_file="validation_report_$(date +%Y%m%d_%H%M%S).txt"
    
    cat > "$report_file" << EOF
FR-02.1 v2.0 System Validation Report
=====================================
Date: $(date)
System: $(uname -a)

Summary:
- Total Checks: $TOTAL_CHECKS
- Passed: $PASSED_CHECKS
- Failed: $((TOTAL_CHECKS - PASSED_CHECKS))
- Success Rate: $(( PASSED_CHECKS * 100 / TOTAL_CHECKS ))%

Detailed Results:
EOF

    for result in "${VALIDATION_RESULTS[@]}"; do
        echo "$result" >> "$report_file"
    done
    
    cat >> "$report_file" << EOF

System Information:
- Docker Version: $(docker --version)
- Docker Compose Version: $(docker-compose --version)
- Available Memory: $(free -h | awk 'NR==2{printf "%.1f/%.1f GB\n", $3/1024/1024,$2/1024/1024}')
- Available Disk: $(df -h . | awk 'NR==2{print $4}')

Container Status:
$(docker-compose ps)

EOF
    
    log_success "Validation report generated: $report_file"
}

# Main validation function
main() {
    echo "🔍 FR-02.1 v2.0 System Validation"
    echo "=================================="
    echo ""
    
    # Load environment if exists
    if [ -f ".env" ]; then
        set -a
        source .env
        set +a
        log_info "Environment loaded from .env"
    else
        log_warning "No .env file found, using defaults"
    fi
    
    # Run validation checks
    check_prerequisites
    echo ""
    check_containers
    echo ""
    check_services
    echo ""
    check_database_schema
    echo ""
    check_chromadb
    echo ""
    check_redis
    echo ""
    check_monitoring
    echo ""
    check_security
    echo ""
    check_performance
    echo ""
    
    # Generate final report
    echo "📊 Validation Summary"
    echo "===================="
    echo "Total Checks: $TOTAL_CHECKS"
    echo "Passed: $PASSED_CHECKS"
    echo "Failed: $((TOTAL_CHECKS - PASSED_CHECKS))"
    echo "Success Rate: $(( PASSED_CHECKS * 100 / TOTAL_CHECKS ))%"
    echo ""
    
    if [ $PASSED_CHECKS -eq $TOTAL_CHECKS ]; then
        log_success "🎉 All validation checks passed! System is ready for production."
    elif [ $PASSED_CHECKS -gt $((TOTAL_CHECKS * 80 / 100)) ]; then
        log_warning "⚠️ Most checks passed, but some issues need attention."
    else
        log_error "❌ Multiple validation failures detected. Please review and fix issues."
    fi
    
    generate_report
    
    # Return appropriate exit code
    if [ $PASSED_CHECKS -eq $TOTAL_CHECKS ]; then
        exit 0
    else
        exit 1
    fi
}

# Run main function
main "$@"