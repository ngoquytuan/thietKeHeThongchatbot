#!/bin/bash
# scripts/setup-storage.sh

# Tạo base storage directory
sudo mkdir -p /opt/chatbot-storage
cd /opt/chatbot-storage

# Tạo cấu trúc thư mục
sudo mkdir -p {original,packages,processed,temp,backup}
sudo mkdir -p original/{2025,2024}
sudo mkdir -p packages/{2025,2024}

# Tạo subdirectories theo tháng cho năm hiện tại
for month in {01..12}; do
    sudo mkdir -p original/2025/${month}
    sudo mkdir -p packages/2025/${month}
    for day in {01..31}; do
        sudo mkdir -p original/2025/${month}/${day}
        sudo mkdir -p packages/2025/${month}/${day}
    done
done

# Set permissions để containers có thể write
sudo chown -R 999:999 /opt/chatbot-storage  # PostgreSQL UID:GID
sudo chmod -R 755 /opt/chatbot-storage

# Create access logs directory
sudo mkdir -p /opt/chatbot-storage/logs
sudo chmod 766 /opt/chatbot-storage/logs

echo "✅ Storage structure created at /opt/chatbot-storage"