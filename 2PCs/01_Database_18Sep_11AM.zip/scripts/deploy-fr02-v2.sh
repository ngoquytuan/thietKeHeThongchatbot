#!/bin/bash

# FR-02.1 v2.0 Deployment Script
# Enhanced Dual Database System with Vietnamese Support

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="fr02-dual-database-v2"
DEPLOY_DIR="/opt/${PROJECT_NAME}"
BACKUP_DIR="/opt/backups"
LOG_FILE="/var/log/fr02-deployment.log"

# Environment variables
export POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-$(openssl rand -base64 32)}
export GRAFANA_PASSWORD=${GRAFANA_PASSWORD:-$(openssl rand -base64 16)}
export CHROMA_AUTH_TOKEN=${CHROMA_AUTH_TOKEN:-$(openssl rand -hex 32)}

# Logging function
log() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log_info() {
    log "${BLUE}[INFO]${NC} $1"
}

log_success() {
    log "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    log "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    log "${RED}[ERROR]${NC} $1"
}

# Prerequisites check
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Check available memory
    AVAILABLE_MEMORY=$(free -g | awk '/^Mem:/{print $7}')
    if [ "$AVAILABLE_MEMORY" -lt 8 ]; then
        log_warning "Available memory is ${AVAILABLE_MEMORY}GB. Recommended: 8GB+"
    fi
    
    # Check disk space
    AVAILABLE_DISK=$(df -BG / | awk 'NR==2{print $4}' | sed 's/G//')
    if [ "$AVAILABLE_DISK" -lt 50 ]; then
        log_error "Available disk space is ${AVAILABLE_DISK}GB. Required: 50GB+"
        exit 1
    fi
    
    log_success "Prerequisites check passed"
}

# Create project structure
create_project_structure() {
    log_info "Creating project structure..."
    
    mkdir -p "$DEPLOY_DIR"/{config,scripts,data,logs,backups}
    mkdir -p "$DEPLOY_DIR"/data/{postgres,chroma,redis,prometheus,grafana}
    mkdir -p "$DEPLOY_DIR"/config/{grafana,prometheus,nginx,ssl}
    
    # Set proper permissions
    chmod 755 "$DEPLOY_DIR"
    chmod 700 "$DEPLOY_DIR"/data
    
    log_success "Project structure created"
}

# Setup environment file
setup_environment() {
    log_info "Setting up environment variables..."
    
    cat > "$DEPLOY_DIR/.env" << EOF
# FR-02.1 v2.0 Environment Configuration
PROJECT_NAME=${PROJECT_NAME}
ENVIRONMENT=production

# Database Configuration
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
POSTGRES_USER=kb_admin
POSTGRES_DB=knowledge_base_v2
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

# Redis Configuration
REDIS_PASSWORD=${REDIS_PASSWORD:-}
REDIS_HOST=redis-master
REDIS_PORT=6379

# ChromaDB Configuration
CHROMA_AUTH_TOKEN=${CHROMA_AUTH_TOKEN}
CHROMA_HOST=chroma
CHROMA_PORT=8000

# Monitoring Configuration
GRAFANA_PASSWORD=${GRAFANA_PASSWORD}
PROMETHEUS_RETENTION=30d

# Security Configuration
JWT_SECRET=${JWT_SECRET:-$(openssl rand -hex 32)}
ENCRYPTION_KEY=${ENCRYPTION_KEY:-$(openssl rand -hex 32)}

# Vietnamese NLP Configuration
VIETNAMESE_NLP_MODEL=pyvi
EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B
EMBEDDING_DIMENSION=1024

# Performance Configuration
MAX_CONNECTIONS=200
WORKER_PROCESSES=4
CACHE_TTL=3600
EOF

    chmod 600 "$DEPLOY_DIR/.env"
    log_success "Environment file created"
}

# Deploy database schema
deploy_database_schema() {
    log_info "Deploying enhanced database schema..."
    
    # Wait for PostgreSQL to be ready
    log_info "Waiting for PostgreSQL to be ready..."
    timeout 120 bash -c 'until docker-compose exec postgres pg_isready -U kb_admin -d knowledge_base_v2; do sleep 5; done'
    
    # Run schema migrations
    docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -f /docker-entrypoint-initdb.d/02_schema.sql
    
    # Verify schema deployment
    TABLES_COUNT=$(docker-compose exec postgres psql -U kb_admin -d knowledge_base_v2 -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';")
    
    if [ "$TABLES_COUNT" -ge 15 ]; then
        log_success "Database schema deployed successfully ($TABLES_COUNT tables created)"
    else
        log_error "Database schema deployment failed (only $TABLES_COUNT tables found)"
        exit 1
    fi
}

# Setup vector database
setup_vector_database() {
    log_info "Setting up ChromaDB vector database..."
    
    # Wait for ChromaDB to be ready
    timeout 120 bash -c 'until curl -f http://localhost:8000/api/v1/heartbeat; do sleep 5; done'
    
    log_success "Vector database setup completed"
}

# Setup monitoring
setup_monitoring() {
    log_info "Setting up monitoring stack..."
    
    # Create Grafana datasources configuration (already created in previous steps)
    # Create alert rules (already created in previous steps)
    
    log_success "Monitoring setup completed"
}

# Run health checks
run_health_checks() {
    log_info "Running comprehensive health checks..."
    
    # Check PostgreSQL
    if docker-compose exec postgres pg_isready -U kb_admin -d knowledge_base_v2 > /dev/null 2>&1; then
        log_success "✅ PostgreSQL is healthy"
    else
        log_error "❌ PostgreSQL health check failed"
        return 1
    fi
    
    # Check ChromaDB
    if curl -f http://localhost:8000/api/v1/heartbeat > /dev/null 2>&1; then
        log_success "✅ ChromaDB is healthy"
    else
        log_error "❌ ChromaDB health check failed"
        return 1
    fi
    
    # Check Redis
    if docker-compose exec redis-master redis-cli ping | grep PONG > /dev/null 2>&1; then
        log_success "✅ Redis is healthy"
    else
        log_error "❌ Redis health check failed"
        return 1
    fi
    
    # Check Prometheus
    if curl -f http://localhost:9090/-/healthy > /dev/null 2>&1; then
        log_success "✅ Prometheus is healthy"
    else
        log_error "❌ Prometheus health check failed"
        return 1
    fi
    
    # Check Grafana
    if curl -f http://localhost:3000/api/health > /dev/null 2>&1; then
        log_success "✅ Grafana is healthy"
    else
        log_error "❌ Grafana health check failed"
        return 1
    fi
    
    log_success "All health checks passed!"
}

# Setup backup strategy
setup_backup_strategy() {
    log_info "Setting up backup strategy..."
    
    # Create backup script
    cat > "$DEPLOY_DIR/scripts/backup.sh" << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# PostgreSQL backup
pg_dump -h localhost -U kb_admin -d knowledge_base_v2 \
    | gzip > "$BACKUP_DIR/postgres_backup_$DATE.sql.gz"

# ChromaDB backup
docker-compose exec chroma /bin/sh -c "tar czf - /chroma/chroma" \
    > "$BACKUP_DIR/chroma_backup_$DATE.tar.gz"

# Redis backup
docker-compose exec redis-master redis-cli --rdb - \
    > "$BACKUP_DIR/redis_backup_$DATE.rdb"

# Cleanup old backups (keep last 7 days)
find "$BACKUP_DIR" -name "*backup*" -mtime +7 -delete

echo "Backup completed: $DATE"
EOF

    chmod +x "$DEPLOY_DIR/scripts/backup.sh"
    
    # Setup cron job for daily backups
    (crontab -l 2>/dev/null; echo "0 2 * * * $DEPLOY_DIR/scripts/backup.sh") | crontab -
    
    log_success "Backup strategy configured"
}

# Main deployment function
main() {
    log_info "Starting FR-02.1 v2.0 deployment..."
    
    # Pre-deployment
    check_prerequisites
    create_project_structure
    setup_environment
    
    # Change to deployment directory
    cd "$DEPLOY_DIR"
    
    # Copy configuration files (assuming they exist in current directory)
    if [ -f "docker-compose.yml" ]; then
        cp docker-compose.yml "$DEPLOY_DIR/"
    else
        log_error "docker-compose.yml not found"
        exit 1
    fi
    
    # Deploy services
    log_info "Starting Docker services..."
    docker-compose up -d
    
    # Wait for services to be ready
    sleep 30
    
    # Post-deployment setup
    deploy_database_schema
    setup_vector_database
    setup_monitoring
    setup_backup_strategy
    
    # Final checks
    run_health_checks
    
    # Display access information
    log_success "🎉 FR-02.1 v2.0 deployment completed successfully!"
    echo ""
    echo "📊 Service Access URLs:"
    echo "  PostgreSQL: localhost:5432 (user: kb_admin)"
    echo "  PgBouncer: localhost:6432"
    echo "  ChromaDB: http://localhost:8000"
    echo "  Redis: localhost:6379"
    echo "  Prometheus: http://localhost:9090"
    echo "  Grafana: http://localhost:3000 (admin/${GRAFANA_PASSWORD})"
    echo ""
    echo "📁 Important Directories:"
    echo "  Project: $DEPLOY_DIR"
    echo "  Data: $DEPLOY_DIR/data"
    echo "  Logs: $DEPLOY_DIR/logs"
    echo "  Backups: $BACKUP_DIR"
    echo ""
    echo "🔐 Generated Passwords saved in: $DEPLOY_DIR/.env"
    echo ""
    echo "📖 Next Steps:"
    echo "  1. Access Grafana and import dashboards"
    echo "  2. Configure application connections"
    echo "  3. Load initial data"
    echo "  4. Run integration tests"
}

# Error handling
trap 'log_error "Deployment failed at line $LINENO"' ERR

# Run main function
main "$@"