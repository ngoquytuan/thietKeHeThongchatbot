#!/bin/bash

# Generate secure environment configuration for FR-02.1 v2.0

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if .env already exists
if [ -f ".env" ]; then
    log_warning ".env file already exists!"
    read -p "Do you want to overwrite it? (yes/no): " overwrite
    if [ "$overwrite" != "yes" ]; then
        log_info "Environment generation cancelled"
        exit 0
    fi
    mv .env .env.backup.$(date +%Y%m%d_%H%M%S)
    log_info "Existing .env backed up"
fi

log_info "Generating secure environment configuration..."

# Generate secure passwords and tokens
POSTGRES_PASSWORD=$(openssl rand -base64 32 | tr -d '\n')
GRAFANA_PASSWORD=$(openssl rand -base64 16 | tr -d '\n')
CHROMA_AUTH_TOKEN=$(openssl rand -hex 32 | tr -d '\n')
JWT_SECRET=$(openssl rand -hex 32 | tr -d '\n')
ENCRYPTION_KEY=$(openssl rand -hex 32 | tr -d '\n')
REDIS_PASSWORD=$(openssl rand -base64 24 | tr -d '\n')

# Create .env file
cat > .env << EOF
# FR-02.1 v2.0 Environment Configuration
# Generated on: $(date)
# ⚠️  KEEP THIS FILE SECURE - CONTAINS SENSITIVE DATA

# Project Configuration
PROJECT_NAME=fr02-dual-database-v2
ENVIRONMENT=production

# Database Configuration
POSTGRES_PASSWORD=$POSTGRES_PASSWORD
POSTGRES_USER=kb_admin
POSTGRES_DB=knowledge_base_v2
POSTGRES_HOST=postgres
POSTGRES_PORT=5432

# Redis Configuration
REDIS_PASSWORD=$REDIS_PASSWORD
REDIS_HOST=redis-master
REDIS_PORT=6379

# ChromaDB Configuration
CHROMA_AUTH_TOKEN=$CHROMA_AUTH_TOKEN
CHROMA_HOST=chroma
CHROMA_PORT=8000

# Monitoring Configuration
GRAFANA_PASSWORD=$GRAFANA_PASSWORD
PROMETHEUS_RETENTION=30d

# Security Configuration
JWT_SECRET=$JWT_SECRET
ENCRYPTION_KEY=$ENCRYPTION_KEY

# Vietnamese NLP Configuration
VIETNAMESE_NLP_MODEL=pyvi
EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B
EMBEDDING_DIMENSION=1024

# Performance Configuration
MAX_CONNECTIONS=200
WORKER_PROCESSES=4
CACHE_TTL=3600

# Backup Configuration
BACKUP_RETENTION_DAYS=7
BACKUP_SCHEDULE="0 2 * * *"

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=/var/log/fr02-system.log

# Network Configuration
NETWORK_SUBNET=172.20.0.0/16
EOF

# Set secure permissions
chmod 600 .env

log_success "Environment configuration generated successfully!"
echo ""
echo "📋 Generated Credentials Summary:"
echo "================================"
echo "PostgreSQL Admin: kb_admin"
echo "Grafana Admin: admin"
echo ""
echo "🔐 All passwords and tokens have been randomly generated"
echo "📁 Configuration saved to: .env (permissions: 600)"
echo ""
echo "⚠️  Important Security Notes:"
echo "- Keep the .env file secure and never commit it to version control"
echo "- Backup your .env file in a secure location"
echo "- Change default passwords after first login"
echo "- Consider using a secrets management system for production"
echo ""
echo "🚀 Next steps:"
echo "1. Review the generated .env file"
echo "2. Run: docker-compose up -d"
echo "3. Access services using the generated credentials"