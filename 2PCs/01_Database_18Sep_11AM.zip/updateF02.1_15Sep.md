## DOCKER TRÊN WINDOWS VS UBUNTU

### **Vấn đề với Docker trên Windows:**

**Volume Mounting khác biệt:**
```yaml
# Trên Windows
volumes:
  chatbot_storage:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: C:\chatbot-storage  # Windows path

# Trên Ubuntu  
volumes:
  chatbot_storage:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /opt/chatbot-storage  # Linux path
```

**File Permissions:**
- Windows: Không có concept của UID/GID như Linux
- Ubuntu: Cần set chính xác permissions cho containers

**Giải pháp đa platform:**
```yaml
# docker-compose.yml with environment-specific override
volumes:
  chatbot_storage:
    driver: local
    # Base configuration - override in docker-compose.override.yml

# docker-compose.override.yml (Windows)
volumes:
  chatbot_storage:
    driver: local
    driver_opts:
      type: none  
      o: bind
      device: C:\chatbot-storage

# docker-compose.override.yml (Ubuntu)  
volumes:
  chatbot_storage:
    driver: local
    driver_opts:
      type: none
      o: bind 
      device: /opt/chatbot-storage
```

## LOGIC NGHIỆP VỤ FILE MANAGEMENT

### **Architecture Overview:**
```
┌─────────────────┐    HTTP API    ┌─────────────────┐
│    FR-03.3      │ ─────────────► │    FR-02.1      │
│ File Processing │                │ File Storage    │
└─────────────────┘                └─────────────────┘
        │                                   │
        ▼                                   ▼
┌─────────────────────────────────────────────────────┐
│           Shared Storage Volume                     │
│    /opt/chatbot-storage (hoặc C:\chatbot-storage)   │
└─────────────────────────────────────────────────────┘
```

### **FR-02.1 Enhanced API cho File Management:**

```python
# api/enhanced_main.py
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse
import os
import json
import uuid
import asyncpg
import shutil
from datetime import datetime
from pathlib import Path
import hashlib
from typing import List, Optional

app = FastAPI(title="FR-02.1 File Management API", version="2.0")

class FileManager:
    def __init__(self, storage_base="/opt/chatbot-storage"):
        self.storage_base = Path(storage_base)
        self.original_dir = self.storage_base / "original"
        self.packages_dir = self.storage_base / "packages"
        
    async def store_file(self, file_data: dict, job_id: str) -> dict:
        """Store file và return metadata"""
        
        # Create date-based directory structure
        now = datetime.now()
        date_path = Path(f"{now.year:04d}/{now.month:02d}/{now.day:02d}")
        package_name = file_data.get('package_name', f'UPLOAD_{job_id}')
        
        storage_dir = self.original_dir / date_path / package_name
        storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Save file
        file_path = storage_dir / file_data['filename']
        with open(file_path, 'wb') as f:
            f.write(file_data['content'])
        
        # Create metadata
        file_metadata = {
            "original_filename": file_data['filename'],
            "preserved_at": now.isoformat(),
            "file_size": len(file_data['content']),
            "file_hash": self._calculate_hash(file_data['content']),
            "processing_job_id": job_id,
            "storage_location": str(file_path),
            "relative_path": str(date_path / package_name / file_data['filename'])
        }
        
        metadata_file = storage_dir / 'file_metadata.json'
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(file_metadata, f, ensure_ascii=False, indent=2)
        
        return file_metadata
    
    def _calculate_hash(self, content: bytes) -> str:
        return f"sha256:{hashlib.sha256(content).hexdigest()}"

file_manager = FileManager()

# API Endpoints for File Management

@app.post("/api/files/upload")
async def upload_file(
    file: UploadFile = File(...),
    job_id: str = None,
    package_name: str = None,
    document_metadata: str = None  # JSON string
):
    """API để FR-03.3 upload file"""
    
    if not job_id:
        job_id = str(uuid.uuid4())
    
    try:
        # Read file content
        file_content = await file.read()
        
        # Store file
        file_data = {
            'filename': file.filename,
            'content': file_content,
            'package_name': package_name or f'UPLOAD_{job_id}',
            'mime_type': file.content_type
        }
        
        stored_metadata = await file_manager.store_file(file_data, job_id)
        
        # Parse document metadata if provided
        if document_metadata:
            doc_meta = json.loads(document_metadata)
            document_id = await _insert_document_with_file(doc_meta, stored_metadata)
            stored_metadata['document_id'] = str(document_id)
        
        return {
            "status": "success",
            "job_id": job_id,
            "file_metadata": stored_metadata,
            "message": "File uploaded and stored successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"File upload failed: {str(e)}")

@app.get("/api/files/list")
async def list_files(
    page: int = 1,
    per_page: int = 20,
    department: str = None,
    date_from: str = None,
    date_to: str = None
):
    """List all files trong database với pagination"""
    
    conn = await get_db_connection()
    
    try:
        # Build query với filters
        where_conditions = ["original_file_info IS NOT NULL"]
        params = []
        
        if department:
            where_conditions.append("department_owner = $" + str(len(params) + 1))
            params.append(department)
        
        if date_from:
            where_conditions.append("created_at >= $" + str(len(params) + 1))
            params.append(date_from)
        
        if date_to:
            where_conditions.append("created_at <= $" + str(len(params) + 1))
            params.append(date_to)
        
        where_clause = " AND ".join(where_conditions)
        
        # Count total
        count_query = f"SELECT COUNT(*) FROM documents_metadata_v2 WHERE {where_clause}"
        total = await conn.fetchval(count_query, *params)
        
        # Get files với pagination
        offset = (page - 1) * per_page
        files_query = f"""
            SELECT document_id, title, original_file_info, file_access_info,
                   department_owner, author, created_at, updated_at
            FROM documents_metadata_v2 
            WHERE {where_clause}
            ORDER BY created_at DESC
            LIMIT ${ len(params) + 1} OFFSET ${ len(params) + 2}
        """
        
        files = await conn.fetch(files_query, *params, per_page, offset)
        
        # Format response
        files_list = []
        for file_record in files:
            original_info = json.loads(file_record['original_file_info']) if file_record['original_file_info'] else {}
            access_info = json.loads(file_record['file_access_info']) if file_record['file_access_info'] else {}
            
            files_list.append({
                "document_id": str(file_record['document_id']),
                "title": file_record['title'],
                "filename": original_info.get('original_filename'),
                "file_size": original_info.get('file_size_bytes'),
                "upload_date": file_record['created_at'].isoformat(),
                "department": file_record['department_owner'],
                "author": file_record['author'],
                "access_count": access_info.get('access_count', 0),
                "file_accessible": original_info.get('file_accessible', False)
            })
        
        return {
            "files": files_list,
            "pagination": {
                "page": page,
                "per_page": per_page,
                "total": total,
                "total_pages": (total + per_page - 1) // per_page
            }
        }
        
    finally:
        await conn.close()

@app.delete("/api/files/{document_id}")
async def delete_file(document_id: str, permanent: bool = False):
    """Xóa file - soft delete hoặc permanent delete"""
    
    conn = await get_db_connection()
    
    try:
        # Get file information
        file_info = await conn.fetchrow("""
            SELECT original_file_info, export_package_info, title
            FROM documents_metadata_v2 
            WHERE document_id = $1
        """, uuid.UUID(document_id))
        
        if not file_info:
            raise HTTPException(status_code=404, detail="File not found")
        
        original_info = json.loads(file_info['original_file_info']) if file_info['original_file_info'] else {}
        package_info = json.loads(file_info['export_package_info']) if file_info['export_package_info'] else {}
        
        if permanent:
            # Permanent delete - remove files và database record
            file_path = original_info.get('original_file_path')
            package_path = package_info.get('fr03_1_package_path')
            
            # Delete physical files
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
                # Remove directory if empty
                parent_dir = os.path.dirname(file_path)
                try:
                    os.rmdir(parent_dir)
                except OSError:
                    pass  # Directory not empty
            
            if package_path and os.path.exists(package_path):
                os.remove(package_path)
            
            # Delete database record
            await conn.execute("""
                DELETE FROM documents_metadata_v2 WHERE document_id = $1
            """, uuid.UUID(document_id))
            
            return {"status": "permanently_deleted", "message": "File and data permanently removed"}
        
        else:
            # Soft delete - mark as inaccessible
            updated_original_info = original_info.copy()
            updated_original_info['file_accessible'] = False
            updated_original_info['deleted_at'] = datetime.now().isoformat()
            
            await conn.execute("""
                UPDATE documents_metadata_v2 
                SET original_file_info = $1, updated_at = $2
                WHERE document_id = $3
            """, json.dumps(updated_original_info), datetime.now(), uuid.UUID(document_id))
            
            return {"status": "soft_deleted", "message": "File marked as deleted but preserved"}
        
    finally:
        await conn.close()

@app.get("/api/files/stats")
async def get_file_stats():
    """Thống kê files trong hệ thống"""
    
    conn = await get_db_connection()
    
    try:
        stats = await conn.fetchrow("""
            SELECT 
                COUNT(*) as total_files,
                COUNT(CASE WHEN (original_file_info->>'file_accessible')::boolean = true THEN 1 END) as accessible_files,
                COUNT(CASE WHEN (original_file_info->>'file_accessible')::boolean = false THEN 1 END) as deleted_files,
                SUM((original_file_info->>'file_size_bytes')::bigint) as total_size_bytes,
                COUNT(DISTINCT department_owner) as departments_count
            FROM documents_metadata_v2 
            WHERE original_file_info IS NOT NULL
        """)
        
        # Storage statistics
        storage_stats = _get_storage_stats()
        
        return {
            "database_stats": dict(stats),
            "storage_stats": storage_stats,
            "generated_at": datetime.now().isoformat()
        }
        
    finally:
        await conn.close()

def _get_storage_stats():
    """Get storage filesystem statistics"""
    
    original_dir = file_manager.original_dir
    packages_dir = file_manager.packages_dir
    
    def get_dir_size(path):
        total = 0
        count = 0
        try:
            for entry in path.rglob('*'):
                if entry.is_file():
                    total += entry.stat().st_size
                    count += 1
        except:
            pass
        return total, count
    
    original_size, original_count = get_dir_size(original_dir)
    packages_size, packages_count = get_dir_size(packages_dir)
    
    return {
        "original_files": {
            "count": original_count,
            "size_bytes": original_size
        },
        "packages": {
            "count": packages_count,
            "size_bytes": packages_size
        },
        "total_storage_bytes": original_size + packages_size
    }

async def _insert_document_with_file(doc_metadata: dict, file_metadata: dict) -> uuid.UUID:
    """Insert document với file metadata"""
    
    conn = await get_db_connection()
    
    try:
        # Prepare file information for database
        original_file_info = {
            "original_file_path": file_metadata['storage_location'],
            "original_filename": file_metadata['original_filename'],
            "file_size_bytes": file_metadata['file_size'],
            "file_hash": file_metadata['file_hash'],
            "mime_type": doc_metadata.get('mime_type', 'application/octet-stream'),
            "upload_timestamp": file_metadata['preserved_at'],
            "uploaded_by": doc_metadata.get('author', 'system'),
            "file_accessible": True,
            "preservation_status": "preserved"
        }
        
        file_access_info = {
            "storage_tier": "warm",
            "access_count": 0,
            "last_accessed": None,
            "retention_policy": "7_years",
            "legal_hold": False
        }
        
        document_id = uuid.uuid4()
        
        await conn.execute("""
            INSERT INTO documents_metadata_v2 (
                document_id, title, content, document_type, access_level,
                department_owner, author, status, language_detected,
                original_file_info, file_access_info, created_at, updated_at
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
            )
        """,
        document_id,
        doc_metadata.get('title', 'Uploaded Document'),
        doc_metadata.get('content', ''),
        doc_metadata.get('document_type', 'manual'),
        doc_metadata.get('access_level', 'employee_only'),
        doc_metadata.get('department_owner', 'IT'),
        doc_metadata.get('author', 'System'),
        doc_metadata.get('status', 'approved'),
        doc_metadata.get('language_detected', 'vi'),
        json.dumps(original_file_info),
        json.dumps(file_access_info),
        datetime.now(),
        datetime.now()
        )
        
        return document_id
        
    finally:
        await conn.close()

async def get_db_connection():
    database_url = os.getenv("DATABASE_URL")
    return await asyncpg.connect(database_url)
```

### **FR-03.3 Integration với FR-02.1 API:**

```python
# fr03_3/file_uploader.py
import aiohttp
import asyncio
from pathlib import Path

class FR021FileUploader:
    def __init__(self, fr02_api_base="http://fr02-file-api:8000"):
        self.api_base = fr02_api_base
        
    async def upload_file_to_fr02(self, file_path: str, job_id: str, 
                                document_metadata: dict) -> dict:
        """Upload file tới FR-02.1 API"""
        
        async with aiohttp.ClientSession() as session:
            # Prepare multipart form data
            with open(file_path, 'rb') as f:
                form_data = aiohttp.FormData()
                form_data.add_field('file', f, filename=Path(file_path).name)
                form_data.add_field('job_id', job_id)
                form_data.add_field('package_name', document_metadata.get('package_name', ''))
                form_data.add_field('document_metadata', json.dumps(document_metadata))
                
                async with session.post(f'{self.api_base}/api/files/upload', 
                                      data=form_data) as response:
                    
                    if response.status == 200:
                        result = await response.json()
                        return {
                            'status': 'success',
                            'document_id': result.get('file_metadata', {}).get('document_id'),
                            'file_metadata': result.get('file_metadata')
                        }
                    else:
                        error_text = await response.text()
                        return {
                            'status': 'failed',
                            'error': f"Upload failed: {response.status} - {error_text}"
                        }
```

## TỔNG KẾT LOGIC NGHIỆP VỤ

### **Workflow hoàn chỉnh:**

1. **FR-03.3 nhận FR03.1 package** → Extract files
2. **FR-03.3 call FR-02.1 API** → Upload original file + metadata  
3. **FR-02.1 store file** → Shared storage + database record
4. **FR-03.3 process chunks** → ChromaDB + enhanced database records
5. **Users access files** → Through FR-02.1 file serving API

### **File Lifecycle Management:**

- **Upload**: FR-03.3 → FR-02.1 API
- **Storage**: FR-02.1 quản lý shared volume
- **Access**: FR-02.1 serve files với authentication
- **Delete**: FR-02.1 API với soft/hard delete options
- **List/Stats**: FR-02.1 cung cấp file management dashboard

### **Database Role:**
- **File Registry**: Database lưu danh sách tất cả files
- **Metadata Storage**: File paths, sizes, hashes, access info
- **Access Control**: Permissions và audit logs
- **Lifecycle Tracking**: Upload date, access count, retention policy

Cách tiếp cận này tạo ra clear separation of concerns và API-driven architecture cho file management.