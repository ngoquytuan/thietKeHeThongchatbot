# Tài liệu Thiết kế Module FR-07: Analytics & Reporting

**📅 Ngày:** 09/09/2025  
**👨‍💼 Người soạn thảo:** [Tên bạn]  
**🏗️ Dự án:** Hệ thống Trợ lý Tri thức AI (RAG Knowledge Assistant)  
**📋 Module:** FR-07 - Analytics & Reporting  
**📊 Trạng thái:** Thiết kế ban đầu, chờ phê duyệt  

---

## 1. Mục đích của Module

Module **FR-07: Analytics & Reporting** cung cấp các công cụ để thu thập, phân tích, và trình bày dữ liệu liên quan đến:
- **Hiệu suất hệ thống**: Thời gian phản hồi, tỷ lệ cache hit, số lượng tài liệu xử lý.
- **Hành vi người dùng**: Tần suất truy vấn, loại tài liệu được truy cập, mức độ tương tác theo cấp người dùng (Guest, Employee, Manager, Director, System Admin).
- **Sử dụng tài liệu**: Tài liệu phổ biến, tỷ lệ truy xuất thành công, thống kê chất lượng dữ liệu.
- **Báo cáo quản trị**: Dashboard và báo cáo định kỳ cho Manager/Director để đánh giá hiệu quả hệ thống.

Module này hỗ trợ đội ngũ quản trị và kỹ thuật trong việc:
- Theo dõi hiệu suất hệ thống (FR-04: RAG Core, FR-02.1: CSDL).
- Phân tích hành vi người dùng để tối ưu hóa trải nghiệm (FR-05: Giao diện Chatbot).
- Đưa ra quyết định cải tiến dựa trên dữ liệu thực tế.

---

## 2. Yêu cầu Chức năng

Dựa trên tài liệu `update_docs_handovers.md` và schema SQL, module FR-07 bao gồm các chức năng sau:

### 2.1. Thu thập Dữ liệu Phân tích
- **Search Analytics**:
  - Ghi lại các thông số truy vấn từ FR-04 (RAG Core): `query_text`, `processing_time_ms`, `results_count`, `user_id`, `timestamp`.
  - Bảng: `search_analytics`.
- **User Activity**:
  - Theo dõi hành vi người dùng: số lượng truy vấn, thời gian phiên, loại tài liệu truy cập.
  - Bảng: `user_activity_summary`.
- **Document Usage**:
  - Thống kê tài liệu được truy xuất: `document_id`, `access_count`, `last_accessed`.
  - Bảng: `document_usage_stats`.
- **System Metrics**:
  - Ghi lại hiệu suất hệ thống: `response_time_ms`, `cpu_usage_percent`, `memory_usage_mb`.
  - Bảng: `system_metrics`.

### 2.2. Xử lý và Phân tích Dữ liệu
- Tổng hợp dữ liệu từ các bảng trên để tạo số liệu thống kê:
  - **Tỷ lệ cache hit**: `cache_hit_count / total_requests`.
  - **Thời gian phản hồi trung bình**: `AVG(processing_time_ms)` từ `search_analytics`.
  - **Top tài liệu truy cập**: `document_id` với `access_count` cao nhất từ `document_usage_stats`.
  - **Hiệu suất theo user level**: Số lượng truy vấn theo `user_level` (Guest, Employee, Manager, v.v.).
- Tính toán các chỉ số hiệu suất (KPIs):
  - Hit Rate@5 ≥ 75% (tỷ lệ tìm kiếm chính xác trong top 5 kết quả).
  - MRR (Mean Reciprocal Rank) ≥ 0.65.
  - System uptime ≥ 99.5%.

### 2.3. Báo cáo và Dashboard
- **API báo cáo**: Cung cấp endpoint `/api/analytics` để trả về dữ liệu phân tích theo định dạng JSON.
- **Dashboard giao diện**: Sử dụng Streamlit để tạo dashboard trực quan, hiển thị:
  - Biểu đồ thời gian phản hồi theo thời gian.
  - Top 10 tài liệu truy cập nhiều nhất.
  - Thống kê truy vấn theo user level.
  - Biểu đồ hiệu suất hệ thống (CPU, memory, throughput).
- **Báo cáo định kỳ**: Xuất báo cáo PDF/CSV theo yêu cầu (hàng tuần/tháng).
- **Quyền truy cập**: Chỉ Manager, Director, System Admin được xem báo cáo đầy đủ (theo FR-06: RBAC).

### 2.4. Tích hợp với Hệ thống
- Kết nối với **FR-02.1 (Hệ thống CSDL kép)** để truy vấn `search_analytics`, `user_activity_summary`, `document_usage_stats`, `system_metrics`.
- Tích hợp với **FR-04 (RAG Core)** để thu thập dữ liệu truy vấn (thông qua logging middleware).
- Tích hợp với **FR-06 (Bảo mật và Phân quyền)** để kiểm soát truy cập báo cáo dựa trên RBAC.
- Tích hợp với **External Services** (Prometheus, Grafana) để lấy metrics hệ thống.

---

## 3. Yêu cầu Phi Chức năng

- **Hiệu suất**:
  - Thời gian xử lý truy vấn báo cáo: < 2 giây cho 10,000 bản ghi.
  - Throughput: Hỗ trợ 50 yêu cầu báo cáo đồng thời.
- **Bảo mật**:
  - Chỉ Manager, Director, System Admin truy cập được endpoint `/api/analytics` (JWT + RBAC).
  - Dữ liệu nhạy cảm (như `user_id`, `email`) được ẩn (content masking).
- **Khả năng mở rộng**:
  - Hỗ trợ phân tích ≥ 100,000 truy vấn/ngày.
  - Tương thích với read replica của PostgreSQL (FR-02.1).
- **Tính sẵn sàng**: Uptime ≥ 99.5%, tích hợp với Prometheus/Grafana để giám sát.

---

## 4. Công nghệ Sử dụng

Dựa trên danh sách công nghệ và tài liệu `update_docs_handovers.md`:

| **Component**         | **Công nghệ**                     | **Version** | **Lý do lựa chọn**                     |
|-----------------------|-----------------------------------|-------------|---------------------------------------|
| **Backend API**       | FastAPI                          | 0.104.1+    | Hiệu suất cao, async, tích hợp dễ     |
| **Database**          | PostgreSQL                       | 15+         | Full-text search, schema mạnh         |
| **Data Processing**   | pandas                           | 2.0.3       | Phân tích dữ liệu nhanh, linh hoạt    |
| **Dashboard**         | Streamlit                        | 1.28.2      | Tạo dashboard trực quan, dễ dùng      |
| **Monitoring**        | prometheus-client, Grafana       | 0.17.0      | Thu thập và hiển thị metrics          |
| **Logging**           | loguru                           | Latest      | Ghi log cấu trúc, dễ debug           |
| **Deployment**        | Docker, Docker Compose           | 20.10+      | Container hóa, dễ triển khai          |

**Môi trường triển khai**: Python 3.11 + Docker + Ubuntu

---

## 5. Thiết kế Kỹ thuật

### 5.1. Schema Cơ sở Dữ liệu
Dựa trên schema SQL từ tài liệu, các bảng liên quan đến FR-07 bao gồm:

- **`search_analytics`**:
  ```sql
  CREATE TABLE search_analytics (
      id SERIAL PRIMARY KEY,
      user_id UUID REFERENCES users(id),
      query_text TEXT,
      processing_time_ms INTEGER,
      results_count INTEGER,
      cache_hit BOOLEAN,
      timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
  );
  ```
  - Lưu trữ dữ liệu truy vấn từ FR-04 (RAG Core).
  - Index: `CREATE INDEX idx_search_analytics_timestamp ON search_analytics(timestamp);`

- **`user_activity_summary`**:
  ```sql
  CREATE TABLE user_activity_summary (
      user_id UUID PRIMARY KEY REFERENCES users(id),
      total_queries INTEGER,
      avg_session_duration_ms INTEGER,
      last_active TIMESTAMPTZ,
      user_level VARCHAR(20) CHECK (user_level IN ('Guest', 'Employee', 'Manager', 'Director', 'System Admin'))
  );
  ```
  - Tổng hợp hoạt động người dùng, cập nhật bởi FR-02.2.

- **`document_usage_stats`**:
  ```sql
  CREATE TABLE document_usage_stats (
      document_id UUID PRIMARY KEY REFERENCES documents_metadata_v2(id),
      access_count INTEGER,
      last_accessed TIMESTAMPTZ,
      most_frequent_user_level VARCHAR(20)
  );
  ```
  - Theo dõi sử dụng tài liệu từ FR-03 và FR-04.

- **`report_generation`**:
  ```sql
  CREATE TABLE report_generation (
      report_id SERIAL PRIMARY KEY,
      report_type VARCHAR(50) CHECK (report_type IN ('daily', 'weekly', 'monthly')),
      generated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
      file_path VARCHAR(255),
      user_id UUID REFERENCES users(id)
  );
  ```
  - Lưu trữ metadata của báo cáo đã xuất.

### 5.2. API Endpoints
Module FR-07 cung cấp các endpoint sau (tích hợp với FastAPI):

| **Endpoint**            | **Phương thức** | **Mô tả**                                     | **Quyền truy cập**        |
|-------------------------|-----------------|-----------------------------------------------|---------------------------|
| `/api/analytics/search` | GET             | Trả về thống kê truy vấn (theo thời gian, user level) | Manager, Director, Admin |
| `/api/analytics/users`  | GET             | Thống kê hành vi người dùng                  | Manager, Director, Admin |
| `/api/analytics/docs`   | GET             | Thống kê sử dụng tài liệu                    | Manager, Director, Admin |
| `/api/analytics/report` | POST            | Tạo và xuất báo cáo (PDF/CSV)                | Director, Admin           |
| `/api/analytics/system` | GET             | Thống kê hiệu suất hệ thống (CPU, memory)    | System Admin             |

**Ví dụ endpoint**:
```python
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class SearchAnalyticsQuery(BaseModel):
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    user_level: Optional[str]

@app.get("/api/analytics/search")
async def get_search_analytics(query: SearchAnalyticsQuery = Depends(), user_id: str = Depends(get_current_user)):
    if not has_permission(user_id, ["Manager", "Director", "System Admin"]):
        raise HTTPException(status_code=403, detail="Insufficient permissions")
    # Truy vấn PostgreSQL
    # SELECT AVG(processing_time_ms), COUNT(*) FROM search_analytics WHERE timestamp BETWEEN start_date AND end_date
    return {"avg_response_time_ms": 100, "total_queries": 5000}
```

### 5.3. Dashboard Streamlit
- **Giao diện**: Streamlit dashboard hiển thị:
  - Biểu đồ đường: Thời gian phản hồi trung bình theo ngày.
  - Biểu đồ cột: Top 10 tài liệu truy cập nhiều nhất.
  - Bảng: Số lượng truy vấn theo user level.
  - Gauge: CPU usage, memory usage (từ Prometheus).
- **Cấu hình**:
  ```python
  import streamlit as st
  import pandas as pd
  import plotly.express as px
  from sqlalchemy import create_engine

  st.title("RAG Knowledge Assistant Analytics")
  engine = create_engine("postgresql://user:pass@postgres:5432/rag_db")

  # Biểu đồ thời gian phản hồi
  df = pd.read_sql("SELECT timestamp, AVG(processing_time_ms) FROM search_analytics GROUP BY timestamp", engine)
  fig = px.line(df, x="timestamp", y="avg_processing_time_ms", title="Thời gian phản hồi trung bình")
  st.plotly_chart(fig)
  ```

### 5.4. Luồng Dữ liệu
```mermaid
graph TD
    FR04[FR-04: RAG Core] -->|Ghi log truy vấn| Data_FR021[FR-02.1: PostgreSQL<br/>search_analytics]
    FR022[FR-02.2: API Quản trị] -->|Ghi hoạt động người dùng| Data_FR021[FR-02.1: PostgreSQL<br/>user_activity_summary]
    FR03[FR-03: Xử lý Dữ liệu] -->|Ghi sử dụng tài liệu| Data_FR021[FR-02.1: PostgreSQL<br/>document_usage_stats]
    Data_FR021 --> FR07[FR-07: Analytics & Reporting]
    FR07 -->|API/Dashboard| Gateway[FR-06: Gateway<br/>JWT + RBAC]
    FR07 -->|Metrics| External[External Services<br/>Prometheus, Grafana]
    Gateway --> Users[Người dùng<br/>Manager, Director, Admin]
```

---

## 6. Triển khai

### 6.1. Môi trường
- **OS**: Ubuntu 22.04
- **Container**: Docker 20.10+, Docker Compose 2.0+
- **Python**: 3.11
- **Database**: PostgreSQL 15 (với read replica), connect qua `pgbouncer`

### 6.2. Cấu hình Docker
**`docker-compose.yml`**:
```yaml
version: '3.8'
services:
  analytics:
    image: python:3.11
    volumes:
      - ./analytics:/app
    working_dir: /app
    command: uvicorn main:app --host 0.0.0.0 --port 8001
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/rag_db
      - PROMETHEUS_MULTIPROC_DIR=/tmp
    depends_on:
      - postgres
      - redis
    networks:
      - rag_network
  streamlit:
    image: python:3.11
    volumes:
      - ./streamlit:/app
    working_dir: /app
    command: streamlit run dashboard.py --server.port 8501
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/rag_db
    depends_on:
      - postgres
    networks:
      - rag_network
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=rag_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - rag_network
  redis:
    image: redis:7
    networks:
      - rag_network

volumes:
  postgres_data:

networks:
  rag_network:
    driver: bridge
```

### 6.3. Cấu hình Prometheus
- Thêm endpoint `/metrics` vào FastAPI để Prometheus scrape:
```python
from prometheus_client import Counter, Histogram
from fastapi import FastAPI

app = FastAPI()
requests_total = Counter("http_requests_total", "Total HTTP requests", ["endpoint"])
response_time = Histogram("http_response_time_seconds", "Response time", ["endpoint"])

@app.get("/metrics")
async def metrics():
    return generate_latest()
```

- Cấu hình Prometheus trong `prometheus.yml`:
```yaml
scrape_configs:
  - job_name: 'analytics'
    static_configs:
      - targets: ['analytics:8001']
```

---

## 7. Các Bước Triển khai

1. **Khởi tạo cơ sở dữ liệu**:
   - Tạo các bảng `search_analytics`, `user_activity_summary`, `document_usage_stats`, `report_generation` trong PostgreSQL.
   - Chạy script SQL để tạo index và kiểm tra schema.

2. **Cài đặt môi trường**:
   - Cài Python 3.11, Docker, Docker Compose trên Ubuntu.
   - Cài các thư viện: `pip install fastapi==0.104.1 pandas==2.0.3 streamlit==1.28.2 sqlalchemy==2.0.23 prometheus-client==0.17.0 loguru`.

3. **Triển khai API**:
   - Tạo file `main.py` cho FastAPI với các endpoint `/api/analytics/*`.
   - Thêm middleware JWT (tích hợp với FR-06) và logging (loguru).

4. **Triển khai Dashboard**:
   - Tạo file `dashboard.py` cho Streamlit với các biểu đồ và bảng.
   - Cấu hình kết nối PostgreSQL và Prometheus.

5. **Chạy Docker Compose**:
   ```bash
   docker-compose up -d
   ```

6. **Kiểm tra**:
   - Test endpoint: `curl http://localhost:8001/api/analytics/search`.
   - Truy cập dashboard: `http://localhost:8501`.
   - Kiểm tra metrics trên Grafana: `http://grafana:3000`.

7. **Tích hợp với FR-06**:
   - Cập nhật RBAC để chỉ Manager, Director, Admin truy cập được `/api/analytics`.

---

## 8. Rủi ro và Giải pháp

| **Rủi ro**                                    | **Giải pháp**                                                                 |
|-----------------------------------------------|------------------------------------------------------------------------------|
| Truy vấn báo cáo chậm với dữ liệu lớn         | Sử dụng read replica (FR-02.1) và index trên `timestamp`, `user_id`.          |
| Thiếu dữ liệu từ FR-04, FR-02.2              | Đảm bảo logging middleware ghi đầy đủ vào `search_analytics`, `user_activity_summary`. |
| Lỗi quyền truy cập báo cáo                   | Kiểm tra JWT và RBAC trong FR-06 trước khi xử lý yêu cầu.                    |
| Dashboard Streamlit không hiển thị đúng       | Kiểm tra kết nối PostgreSQL và định dạng dữ liệu trong pandas.                |

---

## 9. Kế hoạch Phát triển

- **Tuần 1**: Tạo schema, triển khai endpoint `/api/analytics/search` và `/api/analytics/users`.
- **Tuần 2**: Triển khai endpoint `/api/analytics/docs` và `/api/analytics/system`.
- **Tuần 3**: Xây dựng dashboard Streamlit và tích hợp Prometheus/Grafana.
- **Tuần 4**: Test tích hợp, tối ưu hiệu suất, và xuất báo cáo PDF/CSV.

---

## 10. Hỗ trợ Cần thiết

- **Từ đội kỹ thuật**:
  - Xác nhận schema `search_analytics`, `user_activity_summary` đã sẵn sàng.
  - Cung cấp quyền truy cập Prometheus/Grafana cho metrics.
- **Từ management**:
  - Phê duyệt cấu hình Docker và tài nguyên (CPU, RAM) cho Streamlit.
  - Xác nhận yêu cầu báo cáo (daily, weekly, monthly) từ stakeholders.

---

**📧 Liên hệ:** [Your email]  
**📱 Phone:** [Your phone]  
**📊 Tài liệu chi tiết:** Có sẵn trong project knowledge base