# FR-02.1 v2.0 - Dual Database System

Enhanced Dual Database System with Vietnamese language support, optimized for production deployment.

Date: 11-Sep-2025

## 🏗️ Architecture Overview

- **PostgreSQL 15**: Enhanced relational database with Vietnamese text processing
- **ChromaDB 1.0.0**: Vector database with Qwen embeddings (1024-dim)
- **Redis Cluster**: High-performance caching with Vietnamese text optimization
- **Monitoring Stack**: Prometheus + Grafana with comprehensive dashboards
- **Load Balancer**: NGINX with security hardening

## 🚀 Quick Start

### Prerequisites

- Docker & Docker Compose
- Python 3.10+ (for testing)
- Minimum 8GB RAM, 50GB storage
- Ubuntu 22.04 LTS / Windows 11 with WSL2

### 1. Generate Environment Configuration

```bash
# Generate secure passwords and tokens
./scripts/generate-env.sh
```

### 2. Deploy All Services

```bash
# Automated deployment
./scripts/deploy-fr02-v2.sh

# Or manual deployment
docker-compose up -d
```

### 3. Verify Deployment

```bash
# Run health checks
curl http://localhost:8000/api/v1/heartbeat  # ChromaDB
curl http://localhost:9090/-/healthy         # Prometheus
curl http://localhost:3000/api/health        # Grafana

# Run integration tests
cd tests
pip install -r requirements.txt
pytest test_dual_database_v2.py -v
```

## 📊 Service Access

| Service    | URL                   | Credentials             |
| ---------- | --------------------- | ----------------------- |
| PostgreSQL | localhost:5432        | kb_admin / (from .env)  |
| PgBouncer  | localhost:6432        | Connection pooling      |
| ChromaDB   | http://localhost:8000 | Token-based (from .env) |
| Redis      | localhost:6379        | Master instance         |
| Prometheus | http://localhost:9090 | No auth                 |
| Grafana    | http://localhost:3000 | admin / (from .env)     |

## 🗄️ Database Schema

### Enhanced Tables

- **users**: User management with Vietnamese names support
- **documents_metadata_v2**: Enhanced document metadata with language detection
- **document_chunks_enhanced**: Advanced chunking with semantic boundaries
- **vietnamese_text_analysis**: Vietnamese-specific text analysis and quality metrics
- **data_ingestion_jobs**: Job tracking for document processing
- **system_health_metrics**: System performance monitoring

### Vietnamese Language Features

- Text normalization functions
- Diacritic handling
- Compound word recognition
- Technical term extraction
- Quality scoring

## 🔧 Configuration

### Environment Variables

Key configuration in `.env`:

```bash
POSTGRES_PASSWORD=your_secure_password
CHROMA_AUTH_TOKEN=your_auth_token
GRAFANA_PASSWORD=your_grafana_password
EMBEDDING_MODEL=Qwen/Qwen3-Embedding-0.6B
EMBEDDING_DIMENSION=1024
```

### Performance Tuning

PostgreSQL settings in `config/postgres.conf`:

- `shared_buffers = 2GB`
- `effective_cache_size = 6GB`
- `max_connections = 200`

Redis settings in `config/redis-master.conf`:

- `maxmemory = 4gb`
- `maxmemory-policy = allkeys-lru`

## 🔍 Testing

Run comprehensive tests:

```bash
cd tests
pip install -r requirements.txt

# Run all tests
pytest test_dual_database_v2.py -v

# Run specific test categories
pytest -k "vietnamese" -v        # Vietnamese language tests
pytest -k "performance" -v       # Performance benchmarks
pytest -k "integration" -v       # Integration tests
```

## 💾 Backup & Recovery

### Automated Backups

Daily backups configured via cron:

```bash
# Manual backup
./scripts/backup.sh

# List available backups
./scripts/restore.sh --list

# Restore from backup
./scripts/restore.sh 20231215_143022
```

### Backup Contents

- PostgreSQL database dump (compressed)
- ChromaDB vector data (tar.gz)
- Redis RDB snapshot
- Configuration files

## 📈 Monitoring

### Grafana Dashboards

Access at http://localhost:3000:

- **System Overview**: Service health and uptime
- **Database Performance**: Query times and connections
- **Vector Search Performance**: ChromaDB response times
- **Cache Performance**: Redis hit rates and memory usage
- **Vietnamese Language Metrics**: Text processing quality

### Alerts

Configured alerts for:

- Service downtime (5+ minutes)
- High database connections (>150)
- Memory usage (>80%)
- Disk space low (<10%)

## 🔒 Security

### Access Control

- Database user isolation
- ChromaDB token authentication
- Network segmentation (172.20.0.0/16)
- NGINX rate limiting

### Data Protection

- Encrypted passwords in environment
- Secure file permissions (600)
- Audit logging enabled
- Regular security updates

## 🚨 Troubleshooting

### Common Issues

**PostgreSQL Connection Issues:**

```bash
# Check container status
docker-compose ps postgres

# Check logs
docker-compose logs postgres

# Test connection
docker-compose exec postgres pg_isready -U kb_admin
```

**ChromaDB Performance:**

```bash
# Check memory usage
docker stats fr02-chroma-v2

# Monitor collections
curl http://localhost:8000/api/v1/collections
```

**Redis Memory Issues:**

```bash
# Check memory usage
docker-compose exec redis-master redis-cli info memory

# Clear cache if needed
docker-compose exec redis-master redis-cli flushall
```

## 🔧 Maintenance

### Regular Tasks

- Monitor system health via Grafana
- Review backup logs daily
- Update Docker images monthly
- Optimize database indexes quarterly

### Log Locations

- System logs: `/var/log/fr02-system.log`
- Backup logs: `/var/log/fr02-backup.log`
- Deployment logs: `/var/log/fr02-deployment.log`

## 🎯 Performance Targets

| Metric                    | Target | Monitoring          |
| ------------------------- | ------ | ------------------- |
| PostgreSQL Query Response | <100ms | Prometheus          |
| ChromaDB Search Time      | <500ms | Application metrics |
| Redis Cache Hit Rate      | >90%   | Redis exporter      |
| System Uptime             | >99.5% | Health checks       |
| Concurrent Users          | 100+   | Load testing        |

## 📚 Documentation

- [FR-02.1 v2.0 Technical Specification](FR-02.1%20v2.0.md)
- [Database Schema Documentation](scripts/enhanced-schema.sql)
- [API Integration Guide](tests/test_dual_database_v2.py)

## 🆘 Support

For technical support and issues:

1. Check service logs: `docker-compose logs [service]`
2. Review monitoring dashboards
3. Run diagnostic tests: `pytest tests/ -v`
4. Check system resources: `docker stats`

---

**Version**: 2.0  
**Status**: ✅ Production Ready  
**Last Updated**: December 2024  
**Next Phase**: FR-04 RAG Core Engine Integration