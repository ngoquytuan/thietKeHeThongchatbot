#!/bin/bash
# FR01.2 Enhanced Deployment Verification Script v2.0
# Tests all components and v2.0 database schema with FR03.1 compatibility

echo "🚀 Starting FR01.2 Enhanced Deployment Verification v2.0..."
echo "============================================================"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

PASS_COUNT=0
FAIL_COUNT=0

# Function to log test results
log_test() {
    if [ $1 -eq 0 ]; then
        echo -e "${GREEN}✅ $2${NC}"
        ((PASS_COUNT++))
    else
        echo -e "${RED}❌ $2${NC}"
        ((FAIL_COUNT++))
    fi
}

# Test 1: Docker Compose Services Health
echo -e "\n${BLUE}📋 Test 1: Checking Docker Compose services...${NC}"
docker-compose ps | grep -q "Up.*healthy"
log_test $? "All containers are running and healthy"

if [ $? -ne 0 ]; then
    echo -e "${YELLOW}Service Status:${NC}"
    docker-compose ps
fi

# Test 2: PostgreSQL Connection & Enhanced Database Structure v2.0
echo -e "\n${BLUE}📋 Test 2: Testing PostgreSQL database v2.0...${NC}"

# Check basic connection
docker-compose exec -T postgres-test pg_isready -U kb_admin -d knowledge_base_test > /dev/null 2>&1
log_test $? "PostgreSQL service is ready"

# Check v2.0 database tables (expecting 10 tables in v2.0)
DB_TABLES=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "\dt" 2>/dev/null | grep "public |" | wc -l)
if [ "$DB_TABLES" -eq 10 ]; then
    log_test 0 "All 10 v2.0 database tables present"
else
    log_test 1 "Expected 10 v2.0 tables, found $DB_TABLES"
fi

# Verify specific v2.0 tables
V2_TABLES="users user_sessions documents_metadata_v2 document_chunks_enhanced document_bm25_index rag_pipeline_sessions vietnamese_text_analysis search_analytics data_ingestion_jobs chunk_processing_logs"
V2_TABLES_FOUND=0

for table in $V2_TABLES; do
    docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "\dt $table" 2>/dev/null | grep -q "$table"
    if [ $? -eq 0 ]; then
        ((V2_TABLES_FOUND++))
    fi
done

if [ $V2_TABLES_FOUND -eq 10 ]; then
    log_test 0 "All 10 v2.0 enhanced tables verified"
else
    log_test 1 "Only $V2_TABLES_FOUND/10 v2.0 tables found"
fi

# Test 3: Enhanced Database Functions v2.0
echo -e "\n${BLUE}📋 Test 3: Testing v2.0 Vietnamese processing functions...${NC}"

# Test Vietnamese normalization function
VN_FUNCTION_TEST=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT normalize_vietnamese_text('Tiếng Việt');" -t 2>/dev/null | tr -d ' \n')
if [ -n "$VN_FUNCTION_TEST" ]; then
    log_test 0 "Vietnamese text normalization function working"
else
    log_test 1 "Vietnamese normalization function failed"
fi

# Test email extraction function
EMAIL_FUNCTION_TEST=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT array_length(extract_emails_from_text('test@example.com'), 1);" -t 2>/dev/null | tr -d ' \n')
if [ "$EMAIL_FUNCTION_TEST" = "1" ]; then
    log_test 0 "Email extraction function working"
else
    log_test 1 "Email extraction function failed"
fi

# Test phone extraction function
PHONE_FUNCTION_TEST=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT array_length(extract_phones_from_text('0123456789'), 1);" -t 2>/dev/null | tr -d ' \n')
if [ "$PHONE_FUNCTION_TEST" = "1" ]; then
    log_test 0 "Phone extraction function working"
else
    log_test 1 "Phone extraction function failed"
fi

# Test 4: Enhanced Schema Features
echo -e "\n${BLUE}📋 Test 4: Testing v2.0 enhanced schema features...${NC}"

# Test chunking method enum
CHUNKING_METHODS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT count(*) FROM unnest(enum_range(NULL::chunking_method_enum));" -t 2>/dev/null | tr -d ' \n')
if [ "$CHUNKING_METHODS" -eq 5 ]; then
    log_test 0 "Chunking method enum properly defined (5 methods)"
else
    log_test 1 "Chunking method enum issues (found $CHUNKING_METHODS methods, expected 5)"
fi

# Test user level enum
USER_LEVELS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT count(*) FROM unnest(enum_range(NULL::userlevel));" -t 2>/dev/null | tr -d ' \n')
if [ "$USER_LEVELS" -eq 5 ]; then
    log_test 0 "User level enum properly defined (5 levels)"
else
    log_test 1 "User level enum issues (found $USER_LEVELS levels, expected 5)"
fi

# Test 5: Redis Connection
echo -e "\n${BLUE}📋 Test 5: Testing Redis cache layer...${NC}"
REDIS_RESPONSE=$(docker-compose exec -T redis-test redis-cli ping 2>/dev/null)
if [[ "$REDIS_RESPONSE" == "PONG" ]]; then
    log_test 0 "Redis cache layer responding correctly"
else
    log_test 1 "Redis connection failed (expected PONG, got: $REDIS_RESPONSE)"
fi

# Test 6: ChromaDB Vector Database
echo -e "\n${BLUE}📋 Test 6: Testing ChromaDB vector database...${NC}"
curl -sf http://localhost:8001/api/v2/heartbeat > /dev/null 2>&1
log_test $? "ChromaDB vector database accessible"

# Test ChromaDB version info
CHROMA_VERSION=$(curl -s http://localhost:8001/api/v2/version 2>/dev/null | grep -o '"[^"]*"' | head -n1 | tr -d '"')
if [ -n "$CHROMA_VERSION" ]; then
    echo -e "  ${GREEN}→${NC} ChromaDB version: $CHROMA_VERSION"
fi

# Test 7: Enhanced Sample Data Verification v2.0
echo -e "\n${BLUE}📋 Test 7: Verifying v2.0 sample data integrity...${NC}"

# Check core sample documents
DOC_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2;" -t 2>/dev/null | tr -d ' \n')
if [[ $DOC_COUNT -ge 3 ]]; then
    log_test 0 "Sample Vietnamese documents loaded ($DOC_COUNT documents)"
else
    log_test 1 "Insufficient sample documents (found: $DOC_COUNT, expected: ≥3)"
fi

# Check Vietnamese language detection
VN_DOCS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2 WHERE language_detected = 'vi';" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$VN_DOCS" -gt 0 ] && echo 0 || echo 1) "Vietnamese language detection working ($VN_DOCS Vietnamese docs)"

# Check v2.0 enhanced fields
DOCS_WITH_EMAILS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2 WHERE array_length(extracted_emails, 1) > 0;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$DOCS_WITH_EMAILS" -gt 0 ] && echo 0 || echo 1) "Email extraction working ($DOCS_WITH_EMAILS docs with emails)"

DOCS_WITH_NORMALIZED=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2 WHERE search_text_normalized IS NOT NULL;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$DOCS_WITH_NORMALIZED" -gt 0 ] && echo 0 || echo 1) "Text normalization working ($DOCS_WITH_NORMALIZED docs normalized)"

# Test 8: User Management System v2.0
echo -e "\n${BLUE}📋 Test 8: Testing user management system...${NC}"

# Check sample users
USER_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM users;" -t 2>/dev/null | tr -d ' \n')
if [[ $USER_COUNT -ge 4 ]]; then
    log_test 0 "Sample users loaded ($USER_COUNT users)"
else
    log_test 1 "Insufficient sample users (found: $USER_COUNT, expected: ≥4)"
fi

# Check user levels diversity
USER_LEVELS_USED=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(DISTINCT user_level) FROM users;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$USER_LEVELS_USED" -gt 1 ] && echo 0 || echo 1) "User levels diversity verified ($USER_LEVELS_USED different levels)"

# Test 9: Analytics Infrastructure v2.0
echo -e "\n${BLUE}📋 Test 9: Testing v2.0 analytics infrastructure...${NC}"

# Check search analytics table
SEARCH_ANALYTICS_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM search_analytics;" -t 2>/dev/null | tr -d ' \n')
echo -e "  ${GREEN}→${NC} Search analytics ready (table created, $SEARCH_ANALYTICS_COUNT records)"
log_test 0 "Search analytics table operational"

# Check data ingestion jobs table
DATA_JOBS_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM data_ingestion_jobs;" -t 2>/dev/null | tr -d ' \n')
echo -e "  ${GREEN}→${NC} Data ingestion jobs ready ($DATA_JOBS_COUNT jobs tracked)"
log_test 0 "Data ingestion job tracking operational"

# Check pipeline sessions
PIPELINE_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM rag_pipeline_sessions;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$PIPELINE_COUNT" -gt 0 ] && echo 0 || echo 1) "RAG pipeline sessions tracking ($PIPELINE_COUNT sessions)"

# Test 10: Triggers and Automation v2.0
echo -e "\n${BLUE}📋 Test 10: Testing automatic triggers...${NC}"

# Test document trigger by inserting test data
docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "INSERT INTO documents_metadata_v2 (title, content, document_type, department_owner, author) VALUES ('Trigger Test', 'Email: trigger@test.com Phone: 0999123456', 'technical_guide', 'IT', 'Test Script');" > /dev/null 2>&1

# Check if trigger populated fields
TRIGGER_EMAILS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT array_length(extracted_emails, 1) FROM documents_metadata_v2 WHERE title = 'Trigger Test';" -t 2>/dev/null | tr -d ' \n')
TRIGGER_PHONES=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT array_length(extracted_phones, 1) FROM documents_metadata_v2 WHERE title = 'Trigger Test';" -t 2>/dev/null | tr -d ' \n')

if [ "$TRIGGER_EMAILS" = "1" ] && [ "$TRIGGER_PHONES" = "1" ]; then
    log_test 0 "Document triggers working (auto-extracted email and phone)"
else
    log_test 1 "Document triggers failed (emails: $TRIGGER_EMAILS, phones: $TRIGGER_PHONES)"
fi

# Clean up test data
docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "DELETE FROM documents_metadata_v2 WHERE title = 'Trigger Test';" > /dev/null 2>&1

# Test 11: Web Interfaces
echo -e "\n${BLUE}📋 Test 11: Testing web interfaces...${NC}"

# Adminer database admin interface
curl -sf http://localhost:8080 > /dev/null 2>&1
log_test $? "Adminer database admin interface accessible (http://localhost:8080)"

# ChromaDB REST API
curl -sf http://localhost:8001/api/v2/collections > /dev/null 2>&1
log_test $? "ChromaDB REST API responding (http://localhost:8001)"

# Test 12: Database Performance & Indexes v2.0
echo -e "\n${BLUE}📋 Test 12: Testing database performance...${NC}"

# Test query performance on enhanced schema
QUERY_START=$(date +%s%N)
docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2 WHERE language_detected = 'vi';" > /dev/null 2>&1
QUERY_END=$(date +%s%N)
QUERY_TIME=$(( (QUERY_END - QUERY_START) / 1000000 ))

if [ $QUERY_TIME -lt 1000 ]; then
    log_test 0 "Database query performance acceptable (${QUERY_TIME}ms)"
else
    log_test 1 "Database query performance slow (${QUERY_TIME}ms)"
fi

# Check v2.0 indexes exist (should be 25+)
INDEX_COUNT=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM pg_indexes WHERE schemaname = 'public';" -t 2>/dev/null | tr -d ' \n')
if [ "$INDEX_COUNT" -gt 25 ]; then
    log_test 0 "Enhanced v2.0 indexes properly created ($INDEX_COUNT indexes)"
else
    log_test 1 "Insufficient v2.0 indexes ($INDEX_COUNT found, expected >25)"
fi

# Test 13: Vietnamese Text Processing Advanced
echo -e "\n${BLUE}📋 Test 13: Testing advanced Vietnamese language support...${NC}"

# Check Vietnamese sample text processing
VN_SAMPLE=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT title FROM documents_metadata_v2 WHERE title LIKE '%nghỉ phép%' LIMIT 1;" -t 2>/dev/null | tr -d ' \n')
if [ -n "$VN_SAMPLE" ]; then
    log_test 0 "Vietnamese text processing verified"
else
    log_test 1 "Vietnamese text processing may have issues"
fi

# Test search tokens generation
SEARCH_TOKENS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM documents_metadata_v2 WHERE search_tokens IS NOT NULL;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$SEARCH_TOKENS" -gt 0 ] && echo 0 || echo 1) "Full-text search tokens generated ($SEARCH_TOKENS documents indexed)"

# Test BM25 tokens for chunks
BM25_TOKENS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM document_chunks_enhanced WHERE bm25_tokens IS NOT NULL;" -t 2>/dev/null | tr -d ' \n')
log_test $([ "$BM25_TOKENS" -gt 0 ] && echo 0 || echo 1) "BM25 tokens generated for chunks ($BM25_TOKENS chunks indexed)"

# Test 14: Data Persistence v2.0
echo -e "\n${BLUE}📋 Test 14: Testing data persistence...${NC}"

# Check Docker volumes (expecting 3 volumes for v2.0)
VOLUME_COUNT=$(docker volume ls | grep -c "fr01")
if [ "$VOLUME_COUNT" -ge 3 ]; then
    log_test 0 "Persistent volumes created ($VOLUME_COUNT volumes: postgres, redis, chromadb)"
else
    log_test 1 "Volume creation issues ($VOLUME_COUNT volumes found, expected ≥3)"
fi

# Test 15: FR03.1 Compatibility Check
echo -e "\n${BLUE}📋 Test 15: Testing FR03.1 compatibility features...${NC}"

# Check enhanced chunking fields
ENHANCED_CHUNKS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'document_chunks_enhanced' AND column_name IN ('overlap_with_prev', 'overlap_with_next', 'is_final_part');" -t 2>/dev/null | tr -d ' \n')
if [ "$ENHANCED_CHUNKS" -eq 3 ]; then
    log_test 0 "FR03.1 enhanced chunking fields present"
else
    log_test 1 "FR03.1 chunking fields missing ($ENHANCED_CHUNKS/3 found)"
fi

# Check extraction fields in documents
EXTRACTION_FIELDS=$(docker-compose exec -T postgres-test psql -U kb_admin -d knowledge_base_test -c "SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'documents_metadata_v2' AND column_name IN ('extracted_emails', 'extracted_phones', 'search_text_normalized');" -t 2>/dev/null | tr -d ' \n')
if [ "$EXTRACTION_FIELDS" -eq 3 ]; then
    log_test 0 "FR03.1 extraction fields present"
else
    log_test 1 "FR03.1 extraction fields missing ($EXTRACTION_FIELDS/3 found)"
fi

# Final Results
echo -e "\n${BLUE}============================================================${NC}"
echo -e "🎯 ${BLUE}FR01.2 Enhanced Deployment Verification Results v2.0${NC}"
echo -e "${BLUE}============================================================${NC}"

if [ $FAIL_COUNT -eq 0 ]; then
    echo -e "${GREEN}🎉 ALL TESTS PASSED! ($PASS_COUNT/$((PASS_COUNT + FAIL_COUNT)))${NC}"
    echo -e "${GREEN}✅ Enhanced v2.0 deployment is successful and ready for FR03.3!${NC}"
    EXIT_CODE=0
else
    echo -e "${RED}⚠️  SOME TESTS FAILED ($FAIL_COUNT failures, $PASS_COUNT passed)${NC}"
    echo -e "${YELLOW}Please review the failures above before proceeding.${NC}"
    EXIT_CODE=1
fi

echo -e "\n${BLUE}📊 Enhanced Deployment Summary v2.0:${NC}"
echo -e "   • PostgreSQL: ✅ Port 5433 (10 tables with v2.0 enhancements)"
echo -e "   • Redis: ✅ Port 6380 (session & cache layer)"
echo -e "   • ChromaDB: ✅ Port 8001 (vector database with 1024-dim support)"
echo -e "   • Adminer: ✅ Port 8080 (database admin interface)"
echo -e "   • Vietnamese Support: ✅ Advanced text processing & extraction"
echo -e "   • User Management: ✅ Role-based access control system"
echo -e "   • Analytics: ✅ Search analytics & performance monitoring"
echo -e "   • Data Pipeline: ✅ FR03.3 infrastructure ready"
echo -e "   • FR03.1 Compatibility: ✅ Enhanced chunking & processing"

echo -e "\n${BLUE}🔗 Access Points:${NC}"
echo -e "   • Database Admin: ${YELLOW}http://localhost:8080${NC}"
echo -e "     Username: kb_admin | Password: test_password_123"
echo -e "   • ChromaDB API: ${YELLOW}http://localhost:8001${NC}"
echo -e "   • Vector Collections: ${YELLOW}http://localhost:8001/api/v2/collections${NC}"

echo -e "\n${PURPLE}🆕 New v2.0 Capabilities:${NC}"
echo -e "   • Vietnamese text normalization & contact extraction"
echo -e "   • User management with 5 permission levels"
echo -e "   • Real-time search analytics tracking"
echo -e "   • Automatic trigger functions for field updates"
echo -e "   • Advanced chunking with overlap support"
echo -e "   • Data ingestion job tracking (FR03.3 ready)"

echo -e "\n${BLUE}📚 Next Steps:${NC}"
if [ $EXIT_CODE -eq 0 ]; then
    echo -e "   1. System ready for FR03.3 Data Ingestion Pipeline implementation"
    echo -e "   2. Connect your applications to enhanced v2.0 database services"
    echo -e "   3. Test Vietnamese processing functions in production workload"
    echo -e "   4. Configure user management and role-based access control"
    echo -e "   5. Set up search analytics monitoring dashboards"
else
    echo -e "   1. Review failed test results above"
    echo -e "   2. Check container logs: ${YELLOW}docker-compose logs [service-name]${NC}"
    echo -e "   3. Verify v2.0 schema migration completed successfully"
    echo -e "   4. Re-run this test after addressing issues"
fi

echo -e "\n${BLUE}============================================================${NC}"

exit $EXIT_CODE