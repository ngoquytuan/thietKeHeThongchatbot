from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import FileResponse
import os
import json
import uuid
import asyncpg
from typing import Optional
import mimetypes

app = FastAPI(title="FR-02.1 File API", version="2.0")

# Database connection
async def get_db_connection():
    database_url = os.getenv("DATABASE_URL")
    return await asyncpg.connect(database_url)

@app.get("/")
async def root():
    return {"message": "FR-02.1 File API v2.0", "status": "running"}

@app.get("/api/documents/{document_id}/original")
async def get_original_file(document_id: str):
    """Download original file cho document"""

    try:
        conn = await get_db_connection()

        # Get file information from database
        file_info = await conn.fetchrow("""
            SELECT original_file_info, file_access_info, access_level, title
            FROM documents_metadata_v2
            WHERE document_id = $1
        """, uuid.UUID(document_id))

        await conn.close()

        if not file_info:
            raise HTTPException(status_code=404, detail="Document not found")

        original_file_info = json.loads(file_info['original_file_info']) if file_info['original_file_info'] else {}
        file_path = original_file_info.get('original_file_path')

        if not file_path or not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="Original file not accessible")

        # Determine mime type
        mime_type = original_file_info.get('mime_type')
        if not mime_type:
            mime_type, _ = mimetypes.guess_type(file_path)

        return FileResponse(
            file_path,
            media_type=mime_type,
            filename=original_file_info.get('original_filename', 'document')
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/api/documents/{document_id}/package")
async def get_export_package(document_id: str):
    """Download FR03.1 export package"""

    try:
        conn = await get_db_connection()

        file_info = await conn.fetchrow("""
            SELECT export_package_info, title
            FROM documents_metadata_v2
            WHERE document_id = $1
        """, uuid.UUID(document_id))

        await conn.close()

        if not file_info:
            raise HTTPException(status_code=404, detail="Document not found")

        export_info = json.loads(file_info['export_package_info']) if file_info['export_package_info'] else {}
        package_path = export_info.get('fr03_1_package_path')

        if not package_path or not os.path.exists(package_path):
            raise HTTPException(status_code=404, detail="Export package not accessible")

        return FileResponse(
            package_path,
            media_type='application/zip',
            filename=f"{file_info['title']}_export_package.zip"
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    storage_path = os.getenv("STORAGE_BASE_PATH", "/opt/chatbot-storage")
    return {
        "status": "healthy",
        "storage_accessible": os.path.exists(storage_path),
        "storage_path": storage_path
    }