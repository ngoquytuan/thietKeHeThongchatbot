#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FR-02.1 v2.0 Deployment Health Check Script
===========================================

This script checks if the Vietnamese Chatbot Dual Database System deployment
is finished and working correctly. It tests all services and identifies issues.

Usage: python check_deployment.py
"""

import sys
import os
import json
import time
import requests
import subprocess
from datetime import datetime
from typing import Dict, List, Tuple, Any

# Set encoding for Windows
if os.name == 'nt':  # Windows
    sys.stdout.reconfigure(encoding='utf-8')

# Try importing optional dependencies
try:
    import psycopg2
    HAS_PSYCOPG2 = True
except ImportError:
    HAS_PSYCOPG2 = False

try:
    import redis
    HAS_REDIS = True
except ImportError:
    HAS_REDIS = False

try:
    import chromadb
    from chromadb.config import Settings
    HAS_CHROMADB = True
except ImportError:
    HAS_CHROMADB = False

# Color codes for output
class Colors:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'

class DeploymentChecker:
    def __init__(self):
        self.results = []
        self.issues = []
        self.total_checks = 0
        self.passed_checks = 0
        
        # Configuration
        self.config = {
            'postgres': {
                'host': 'localhost',
                'port': 5432,
                'database': 'knowledge_base_v2',
                'user': 'kb_admin',
                'password': '1234567890'
            },
            'redis': {
                'host': 'localhost',
                'port': 6379
            },
            'chroma': {
                'host': 'localhost',
                'port': 8001,
                'auth_token': '1234567890'
            },
            'grafana': {
                'url': 'http://localhost:3009',
                'username': 'admin',
                'password': '1234567890'
            },
            'prometheus': {
                'url': 'http://localhost:9090'
            },
            'adminer': {
                'url': 'http://localhost:8081'
            }
        }

    def print_header(self):
        """Print script header"""
        print(f"{Colors.CYAN}{Colors.BOLD}")
        print("=" * 70)
        print("[CHECK] FR-02.1 v2.0 DEPLOYMENT HEALTH CHECK")
        print("        Vietnamese Chatbot Dual Database System")
        print("=" * 70)
        print(f"{Colors.END}")
        print(f"[TIME] Check Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()

    def log_result(self, service: str, check: str, status: bool, message: str = "", details: str = ""):
        """Log check result"""
        self.total_checks += 1
        if status:
            self.passed_checks += 1
            symbol = f"{Colors.GREEN}[PASS]{Colors.END}"
            status_text = f"{Colors.GREEN}PASS{Colors.END}"
        else:
            symbol = f"{Colors.RED}[FAIL]{Colors.END}"
            status_text = f"{Colors.RED}FAIL{Colors.END}"
            self.issues.append(f"{service}: {check} - {message}")
        
        result = {
            'service': service,
            'check': check,
            'status': status,
            'message': message,
            'details': details,
            'timestamp': datetime.now().isoformat()
        }
        self.results.append(result)
        
        print(f"{symbol} {Colors.BOLD}{service}{Colors.END} - {check}: {status_text}")
        if message:
            print(f"    [INFO] {message}")
        if details and not status:
            print(f"    [DETAILS] {Colors.YELLOW}{details}{Colors.END}")
        print()

    def check_docker_containers(self) -> None:
        """Check if all Docker containers are running"""
        print(f"{Colors.BLUE}{Colors.BOLD}[DOCKER] CHECKING DOCKER CONTAINERS{Colors.END}")
        print("-" * 50)
        
        try:
            result = subprocess.run(['docker-compose', 'ps'], 
                                  capture_output=True, text=True, cwd='.')
            
            if result.returncode != 0:
                self.log_result("Docker", "Docker Compose Status", False, 
                              "Failed to run docker-compose ps", result.stderr)
                return
            
            # Parse container status
            lines = result.stdout.strip().split('\n')[1:]  # Skip header
            containers = {}
            
            for line in lines:
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 4:
                        name = parts[0]
                        status = ' '.join(parts[4:])
                        containers[name] = status
            
            # Expected containers
            expected_containers = [
                'fr02-postgres-v2', 'fr02-chroma-v2', 'fr02-redis-master',
                'fr02-grafana', 'fr02-prometheus', 'fr02-adminer',
                'fr02-pgbouncer', 'fr02-redis-replica', 'fr02-nginx'
            ]
            
            for container in expected_containers:
                if container in containers:
                    status = containers[container]
                    is_running = 'Up' in status and 'Restarting' not in status
                    self.log_result("Docker", f"Container {container}", is_running, 
                                  f"Status: {status}")
                else:
                    self.log_result("Docker", f"Container {container}", False, 
                                  "Container not found")
                                  
        except Exception as e:
            self.log_result("Docker", "Container Check", False, 
                          f"Error checking containers: {str(e)}")

    def check_postgresql(self) -> None:
        """Check PostgreSQL database connectivity and structure"""
        print(f"{Colors.BLUE}{Colors.BOLD}[POSTGRES] CHECKING POSTGRESQL DATABASE{Colors.END}")
        print("-" * 50)
        
        if not HAS_PSYCOPG2:
            self.log_result("PostgreSQL", "Dependencies", False, 
                          "psycopg2 not installed. Run: pip install psycopg2-binary")
            return
        
        try:
            # Test connection
            conn = psycopg2.connect(
                host=self.config['postgres']['host'],
                port=self.config['postgres']['port'],
                database=self.config['postgres']['database'],
                user=self.config['postgres']['user'],
                password=self.config['postgres']['password']
            )
            
            self.log_result("PostgreSQL", "Database Connection", True, 
                          "Successfully connected to PostgreSQL")
            
            cursor = conn.cursor()
            
            # Check version
            cursor.execute("SELECT version();")
            version = cursor.fetchone()[0]
            self.log_result("PostgreSQL", "Version Check", True, 
                          f"Version: {version.split(',')[0]}")
            
            # Check all 15 required tables from 01_init_database_V2.sql
            cursor.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_schema = 'public' ORDER BY table_name;
            """)
            tables = [row[0] for row in cursor.fetchall()]

            # Complete list of all 15 expected tables
            expected_tables = [
                'users',                        # Table 1
                'user_sessions',                # Table 2
                'documents_metadata_v2',        # Table 3
                'document_chunks_enhanced',     # Table 4
                'document_bm25_index',          # Table 5
                'rag_pipeline_sessions',        # Table 6
                'vietnamese_text_analysis',     # Table 7
                'search_analytics',             # Table 8
                'user_activity_summary',        # Table 9
                'user_events',                  # Table 10
                'system_metrics',               # Table 11
                'document_usage_stats',         # Table 12
                'report_generation',            # Table 13
                'data_ingestion_jobs',          # Table 14
                'chunk_processing_logs'         # Table 15
            ]

            self.log_result("PostgreSQL", "Total Tables Found", len(tables) >= 15,
                          f"Found {len(tables)} tables, expected 15")

            for table in expected_tables:
                if table in tables:
                    try:
                        # Check table structure and count
                        cursor.execute(f"SELECT COUNT(*) FROM {table};")
                        count = cursor.fetchone()[0]

                        # Get column count
                        cursor.execute(f"""
                            SELECT COUNT(*) FROM information_schema.columns
                            WHERE table_name = '{table}' AND table_schema = 'public';
                        """)
                        column_count = cursor.fetchone()[0]

                        self.log_result("PostgreSQL", f"Table {table}", True,
                                      f"Table exists with {count} records, {column_count} columns")

                    except Exception as e:
                        self.log_result("PostgreSQL", f"Table {table}", False,
                                      f"Error accessing table: {str(e)}")
                else:
                    self.log_result("PostgreSQL", f"Table {table}", False,
                                  "Required table missing")

            # Check for sample data in key tables
            sample_data_checks = [
                ('users', 'Sample users loaded'),
                ('documents_metadata_v2', 'Sample documents loaded'),
                ('data_ingestion_jobs', 'Sample ingestion jobs created'),
                ('vietnamese_text_analysis', 'Vietnamese analysis data available')
            ]

            for table, description in sample_data_checks:
                if table in tables:
                    try:
                        cursor.execute(f"SELECT COUNT(*) FROM {table};")
                        count = cursor.fetchone()[0]
                        has_data = count > 0
                        self.log_result("PostgreSQL", f"Sample Data {table}", has_data,
                                      f"{description}: {count} records" if has_data else
                                      f"No sample data in {table}")
                    except Exception as e:
                        self.log_result("PostgreSQL", f"Sample Data {table}", False,
                                      f"Error checking sample data: {str(e)}")

            # Check database schema versioning and functions
            try:
                cursor.execute("""
                    SELECT routine_name FROM information_schema.routines
                    WHERE routine_schema = 'public' AND routine_type = 'FUNCTION';
                """)
                functions = [row[0] for row in cursor.fetchall()]
                expected_functions = [
                    'normalize_vietnamese_text',
                    'extract_emails_from_text',
                    'extract_phones_from_text',
                    'update_document_search_fields',
                    'update_chunk_bm25_tokens'
                ]

                function_count = sum(1 for func in expected_functions if func in functions)
                self.log_result("PostgreSQL", "Database Functions", function_count >= 3,
                              f"Found {function_count}/{len(expected_functions)} expected functions")

            except Exception as e:
                self.log_result("PostgreSQL", "Database Functions", False,
                              f"Error checking functions: {str(e)}")

            # Check triggers
            try:
                cursor.execute("""
                    SELECT trigger_name FROM information_schema.triggers
                    WHERE trigger_schema = 'public';
                """)
                triggers = [row[0] for row in cursor.fetchall()]
                expected_triggers = [
                    'trigger_update_document_search_fields',
                    'trigger_update_chunk_bm25_tokens'
                ]

                trigger_count = sum(1 for trigger in expected_triggers if trigger in triggers)
                self.log_result("PostgreSQL", "Database Triggers", trigger_count >= 1,
                              f"Found {trigger_count}/{len(expected_triggers)} expected triggers")

            except Exception as e:
                self.log_result("PostgreSQL", "Database Triggers", False,
                              f"Error checking triggers: {str(e)}")

            # Check views
            try:
                cursor.execute("""
                    SELECT table_name FROM information_schema.views
                    WHERE table_schema = 'public';
                """)
                views = [row[0] for row in cursor.fetchall()]
                expected_views = [
                    'vw_document_processing_stats',
                    'vw_chunking_performance',
                    'vw_ingestion_job_summary'
                ]

                view_count = sum(1 for view in expected_views if view in views)
                self.log_result("PostgreSQL", "Database Views", view_count >= 2,
                              f"Found {view_count}/{len(expected_views)} performance monitoring views")

            except Exception as e:
                self.log_result("PostgreSQL", "Database Views", False,
                              f"Error checking views: {str(e)}")
            
            # Check extensions
            cursor.execute("SELECT extname FROM pg_extension;")
            extensions = [row[0] for row in cursor.fetchall()]
            
            required_extensions = ['uuid-ossp', 'pg_trgm', 'btree_gin', 'unaccent']
            for ext in required_extensions:
                if ext in extensions:
                    self.log_result("PostgreSQL", f"Extension {ext}", True, 
                                  "Extension installed")
                else:
                    self.log_result("PostgreSQL", f"Extension {ext}", False, 
                                  "Required extension missing")
            
            conn.close()
            
        except psycopg2.Error as e:
            self.log_result("PostgreSQL", "Database Connection", False, 
                          f"PostgreSQL connection failed: {str(e)}")
        except Exception as e:
            self.log_result("PostgreSQL", "Database Check", False, 
                          f"Unexpected error: {str(e)}")

    def check_redis(self) -> None:
        """Check Redis cache connectivity and configuration"""
        print(f"{Colors.BLUE}{Colors.BOLD}🔴 CHECKING REDIS CACHE{Colors.END}")
        print("-" * 50)
        
        try:
            # Test Redis master
            r_master = redis.Redis(
                host=self.config['redis']['host'],
                port=self.config['redis']['port'],
                decode_responses=True
            )
            
            # Test connection
            if r_master.ping():
                self.log_result("Redis", "Master Connection", True, 
                              "Successfully connected to Redis master")
                
                # Get Redis info
                info = r_master.info()
                self.log_result("Redis", "Version Check", True, 
                              f"Version: {info.get('redis_version', 'Unknown')}")
                
                # Test basic operations
                test_key = "deployment_check_test"
                r_master.set(test_key, "test_value", ex=60)
                value = r_master.get(test_key)
                
                if value == "test_value":
                    self.log_result("Redis", "Read/Write Test", True, 
                                  "Redis read/write operations working")
                    r_master.delete(test_key)
                else:
                    self.log_result("Redis", "Read/Write Test", False, 
                                  "Redis read/write test failed")
                
                # Check memory usage
                memory_info = r_master.info('memory')
                used_memory = memory_info.get('used_memory_human', 'Unknown')
                self.log_result("Redis", "Memory Usage", True, 
                              f"Used memory: {used_memory}")
                
            else:
                self.log_result("Redis", "Master Connection", False, 
                              "Failed to ping Redis master")
            
            # Test Redis replica
            try:
                r_replica = redis.Redis(host=self.config['redis']['host'], port=6380, decode_responses=True)
                if r_replica.ping():
                    self.log_result("Redis", "Replica Connection", True, 
                                  "Successfully connected to Redis replica")
                else:
                    self.log_result("Redis", "Replica Connection", False, 
                                  "Failed to ping Redis replica")
            except Exception as e:
                self.log_result("Redis", "Replica Connection", False, 
                              f"Redis replica connection error: {str(e)}")
                
        except redis.ConnectionError as e:
            self.log_result("Redis", "Master Connection", False, 
                          f"Redis connection failed: {str(e)}")
        except Exception as e:
            self.log_result("Redis", "Redis Check", False, 
                          f"Unexpected error: {str(e)}")

    def check_chromadb(self) -> None:
        """Check ChromaDB vector database connectivity"""
        print(f"{Colors.BLUE}{Colors.BOLD}📢 CHECKING CHROMADB VECTOR DATABASE{Colors.END}")
        print("-" * 50)
        
        try:
            # Test heartbeat
            heartbeat_url = f"http://{self.config['chroma']['host']}:{self.config['chroma']['port']}/api/v2/heartbeat"
            response = requests.get(heartbeat_url, timeout=10)
            
            if response.status_code == 200:
                self.log_result("ChromaDB", "Heartbeat Check", True, 
                              "ChromaDB is responding to heartbeat")
                
                # Test with ChromaDB client
                try:
                    client = chromadb.HttpClient(
                        host=self.config['chroma']['host'],
                        port=self.config['chroma']['port'],
                        settings=Settings(
                            chroma_server_host=self.config['chroma']['host'],
                            chroma_server_cors_allow_origins=["*"]
                        )
                    )
                    
                    # List collections
                    collections = client.list_collections()
                    self.log_result("ChromaDB", "Client Connection", True, 
                                  f"Connected successfully, found {len(collections)} collections")
                    
                    # Check for expected collections
                    collection_names = [col.name for col in collections]
                    expected_collections = ['knowledge_base_v2']
                    
                    for coll_name in expected_collections:
                        if coll_name in collection_names:
                            try:
                                collection = client.get_collection(coll_name)
                                count = collection.count()
                                self.log_result("ChromaDB", f"Collection {coll_name}", True, 
                                              f"Collection exists with {count} items")
                            except Exception as e:
                                self.log_result("ChromaDB", f"Collection {coll_name}", False, 
                                              f"Error accessing collection: {str(e)}")
                        else:
                            self.log_result("ChromaDB", f"Collection {coll_name}", False, 
                                          "Expected collection not found")
                    
                except Exception as e:
                    self.log_result("ChromaDB", "Client Connection", False, 
                                  f"ChromaDB client error: {str(e)}")
                
            else:
                self.log_result("ChromaDB", "Heartbeat Check", False, 
                              f"ChromaDB heartbeat failed with status {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            self.log_result("ChromaDB", "Connection", False, 
                          "ChromaDB service is not accessible")
        except Exception as e:
            self.log_result("ChromaDB", "ChromaDB Check", False, 
                          f"Unexpected error: {str(e)}")

    def check_web_interfaces(self) -> None:
        """Check web interfaces (Grafana, Prometheus, Adminer)"""
        print(f"{Colors.BLUE}{Colors.BOLD}🌐 CHECKING WEB INTERFACES{Colors.END}")
        print("-" * 50)
        
        # Check Grafana
        try:
            grafana_health_url = f"{self.config['grafana']['url']}/api/health"
            response = requests.get(grafana_health_url, timeout=10)
            
            if response.status_code == 200:
                health_data = response.json()
                self.log_result("Grafana", "Health Check", True, 
                              f"Grafana is healthy, version: {health_data.get('version', 'Unknown')}")
                
                # Test login
                login_url = f"{self.config['grafana']['url']}/api/user"
                auth = (self.config['grafana']['username'], self.config['grafana']['password'])
                login_response = requests.get(login_url, auth=auth, timeout=10)
                
                if login_response.status_code == 200:
                    user_data = login_response.json()
                    self.log_result("Grafana", "Authentication", True, 
                                  f"Login successful for user: {user_data.get('login', 'Unknown')}")
                else:
                    self.log_result("Grafana", "Authentication", False, 
                                  f"Login failed with status {login_response.status_code}")
            else:
                self.log_result("Grafana", "Health Check", False, 
                              f"Grafana health check failed with status {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            self.log_result("Grafana", "Connection", False, 
                          "Grafana service is not accessible")
        except Exception as e:
            self.log_result("Grafana", "Grafana Check", False, 
                          f"Unexpected error: {str(e)}")
        
        # Check Prometheus
        try:
            prometheus_health_url = f"{self.config['prometheus']['url']}/-/healthy"
            response = requests.get(prometheus_health_url, timeout=10)
            
            if response.status_code == 200:
                self.log_result("Prometheus", "Health Check", True, 
                              "Prometheus is healthy")
                
                # Check metrics endpoint
                metrics_url = f"{self.config['prometheus']['url']}/api/v1/label/__name__/values"
                metrics_response = requests.get(metrics_url, timeout=10)
                
                if metrics_response.status_code == 200:
                    metrics_data = metrics_response.json()
                    metric_count = len(metrics_data.get('data', []))
                    self.log_result("Prometheus", "Metrics Collection", True, 
                                  f"Collecting {metric_count} different metrics")
                else:
                    self.log_result("Prometheus", "Metrics Collection", False, 
                                  "Failed to retrieve metrics list")
            else:
                self.log_result("Prometheus", "Health Check", False, 
                              f"Prometheus health check failed with status {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            self.log_result("Prometheus", "Connection", False, 
                          "Prometheus service is not accessible")
        except Exception as e:
            self.log_result("Prometheus", "Prometheus Check", False, 
                          f"Unexpected error: {str(e)}")
        
        # Check Adminer
        try:
            response = requests.get(self.config['adminer']['url'], timeout=10)
            
            if response.status_code == 200 and "Adminer" in response.text:
                self.log_result("Adminer", "Web Interface", True, 
                              "Adminer web interface is accessible")
            else:
                self.log_result("Adminer", "Web Interface", False, 
                              f"Adminer check failed with status {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            self.log_result("Adminer", "Connection", False, 
                          "Adminer service is not accessible")
        except Exception as e:
            self.log_result("Adminer", "Adminer Check", False, 
                          f"Unexpected error: {str(e)}")

    def check_network_connectivity(self) -> None:
        """Check internal Docker network connectivity"""
        print(f"{Colors.BLUE}{Colors.BOLD}🌐 CHECKING NETWORK CONNECTIVITY{Colors.END}")
        print("-" * 50)
        
        # Check if containers can reach each other
        network_tests = [
            ("Adminer to PostgreSQL", "adminer", "postgres", 5432),
            ("Grafana to Prometheus", "grafana", "prometheus", 9090),
            ("Application to ChromaDB", "postgres", "chroma", 8001),
            ("Application to Redis", "postgres", "redis-master", 6379)
        ]
        
        for test_name, from_container, to_container, port in network_tests:
            try:
                # Test network connectivity using nc (netcat)
                result = subprocess.run([
                    'docker-compose', 'exec', '-T', from_container, 
                    'sh', '-c', f'nc -zv {to_container} {port} 2>&1'
                ], capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0 or 'open' in result.stdout.lower():
                    self.log_result("Network", test_name, True, 
                                  f"Connection successful: {from_container} → {to_container}:{port}")
                else:
                    self.log_result("Network", test_name, False, 
                                  f"Connection failed: {from_container} → {to_container}:{port}",
                                  result.stdout + result.stderr)
                    
            except subprocess.TimeoutExpired:
                self.log_result("Network", test_name, False, 
                              "Network test timed out")
            except Exception as e:
                self.log_result("Network", test_name, False, 
                              f"Network test error: {str(e)}")

    def generate_report(self) -> None:
        """Generate final deployment report"""
        print(f"{Colors.MAGENTA}{Colors.BOLD}")
        print("=" * 70)
        print("📊 DEPLOYMENT HEALTH REPORT")
        print("=" * 70)
        print(f"{Colors.END}")
        
        # Overall status
        success_rate = (self.passed_checks / self.total_checks) * 100 if self.total_checks > 0 else 0
        
        if success_rate >= 90:
            status_color = Colors.GREEN
            status_text = "🟢 EXCELLENT"
        elif success_rate >= 75:
            status_color = Colors.YELLOW  
            status_text = "🟡 GOOD"
        elif success_rate >= 50:
            status_color = Colors.YELLOW
            status_text = "🟠 NEEDS ATTENTION"
        else:
            status_color = Colors.RED
            status_text = "🔴 CRITICAL ISSUES"
        
        print(f"📈 Overall Status: {status_color}{Colors.BOLD}{status_text}{Colors.END}")
        print(f"✅ Passed: {self.passed_checks}/{self.total_checks} ({success_rate:.1f}%)")
        print(f"❌ Failed: {len(self.issues)}")
        print()
        
        # Service summary
        services = {}
        for result in self.results:
            service = result['service']
            if service not in services:
                services[service] = {'passed': 0, 'total': 0}
            services[service]['total'] += 1
            if result['status']:
                services[service]['passed'] += 1
        
        print(f"{Colors.CYAN}{Colors.BOLD}🔍 SERVICE STATUS SUMMARY:{Colors.END}")
        for service, stats in services.items():
            rate = (stats['passed'] / stats['total']) * 100
            if rate == 100:
                icon = "🟢"
            elif rate >= 75:
                icon = "🟡"
            else:
                icon = "🔴"
            print(f"  {icon} {service}: {stats['passed']}/{stats['total']} ({rate:.0f}%)")
        print()
        
        # Issues summary
        if self.issues:
            print(f"{Colors.RED}{Colors.BOLD}🚨 ISSUES FOUND:{Colors.END}")
            for i, issue in enumerate(self.issues, 1):
                print(f"  {i}. {issue}")
            print()
        
        # Recommendations
        print(f"{Colors.BLUE}{Colors.BOLD}💡 RECOMMENDATIONS:{Colors.END}")
        
        if success_rate >= 90:
            print("  ✅ Deployment is successful and ready for production!")
            print("  📝 Consider setting up monitoring alerts")
            print("  🔒 Review security configurations for production")
        elif success_rate >= 75:
            print("  ⚠️  Most services are working, but some issues need attention")
            print("  🔧 Fix the failed checks before proceeding to production")
            print("  📋 Review configuration files")
        else:
            print("  🚨 Critical issues detected - deployment is not ready")
            print("  🛠️  Address all failed checks before continuing")
            print("  📞 Consider consulting the deployment documentation")
        
        print()
        print(f"📋 Detailed logs saved to: deployment_check_results.json")
        
        # Save detailed results to file
        with open('deployment_check_results.json', 'w') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'summary': {
                    'total_checks': self.total_checks,
                    'passed_checks': self.passed_checks,
                    'success_rate': success_rate,
                    'status': status_text
                },
                'services': services,
                'issues': self.issues,
                'detailed_results': self.results
            }, f, indent=2)

    def run_all_checks(self) -> None:
        """Run all deployment checks"""
        self.print_header()
        
        # Run checks
        self.check_docker_containers()
        self.check_postgresql()
        self.check_redis()
        self.check_chromadb()
        self.check_web_interfaces()
        self.check_network_connectivity()
        
        # Generate report
        self.generate_report()

def main():
    """Main function"""
    checker = DeploymentChecker()
    
    try:
        checker.run_all_checks()
        
        # Exit with appropriate code
        success_rate = (checker.passed_checks / checker.total_checks) * 100 if checker.total_checks > 0 else 0
        sys.exit(0 if success_rate >= 75 else 1)
        
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}⚠️  Check interrupted by user{Colors.END}")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}💥 Unexpected error: {str(e)}{Colors.END}")
        sys.exit(1)

if __name__ == "__main__":
    main()