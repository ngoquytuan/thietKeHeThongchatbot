# FR08_master - Quick Start Guide

## 🎯 What You Have

**FR08_master** is your complete admin control panel **without any authentication**. It gives you full access to:

- **User Management** - Create, edit, delete users
- **Document Management** - Control document visibility
- **System Monitoring** - CPU, memory, container status
- **Database Maintenance** - Backups, optimization, cleanup
- **Real-time Metrics** - Performance monitoring and alerts

## 🚀 How to Run (Windows)

### Method 1: Simple Windows Batch Files

1. **Install Dependencies:**
   ```cmd
   cd FR08_master\standalone
   install.bat
   ```

2. **Run the Server:**
   ```cmd
   run_windows.bat
   ```

### Method 2: Python Direct

1. **Install:**
   ```cmd
   cd FR08_master
   pip install -r requirements.txt
   ```

2. **Run:**
   ```cmd
   python run.py
   ```

### Method 3: Advanced Python

```cmd
cd FR08_master\standalone
python run_standalone.py
```

## 🌐 Access Your Admin Panel

Once running, open your browser:

- **Main Dashboard:** http://localhost:8009
- **API Documentation:** http://localhost:8009/docs
- **Health Check:** http://localhost:8009/health

## ⚡ Quick Actions

### Create Database Backup
```bash
curl -X POST http://localhost:8009/api/admin/backup
```

### View All Users
```bash
curl http://localhost:8009/api/admin/users
```

### Check System Health
```bash
curl http://localhost:8009/api/admin/system/health
```

### Clean Old Data (30 days)
```bash
curl -X POST http://localhost:8009/api/admin/cleanup/metrics?days=30
```

### Clear Redis Cache
```bash
curl -X POST http://localhost:8009/api/admin/cache/clear
```

## 🔧 What Each Endpoint Does

| Endpoint | Purpose |
|----------|---------|
| `/api/admin/users` | Manage user accounts |
| `/api/admin/documents` | Control document access |
| `/api/admin/system` | Monitor system performance |
| `/api/admin/backup` | Create database backups |
| `/api/admin/optimize` | Speed up database |
| `/api/admin/health` | Check system health |

## 🛠️ Troubleshooting

### "Database connection failed"
- Make sure PostgreSQL is running on port 5432
- Check credentials: `kb_admin:1234567890`

### "Redis connection failed"
- Make sure Redis is running on port 6379

### "Port 8009 already in use"
- Change the port in `run.py`: `port=8010`

### "Import errors"
- Run: `pip install -r requirements.txt`

## 🎮 Usage Examples

### Add a New User
```bash
curl -X POST http://localhost:8009/api/admin/users \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@company.com",
    "password": "securepass123",
    "user_level": "Employee",
    "full_name": "New Employee",
    "department": "Engineering"
  }'
```

### Deactivate a Document
```bash
curl -X PUT http://localhost:8009/api/admin/documents/{document_id} \
  -H "Content-Type: application/json" \
  -d '{"is_active": false}'
```

### Get System Alerts
```bash
curl http://localhost:8009/api/admin/system/alerts
```

## 🔒 Security Note

**⚠️ IMPORTANT:** This tool has **NO AUTHENTICATION** and gives **FULL ADMIN ACCESS**.

**Safe to use:**
- Internal networks
- Development environments
- Behind firewalls
- Trusted environments

**DO NOT expose to public internet** without additional security.

## 📊 Dashboard Features

The web interface gives you:
- **One-click access** to all admin functions
- **Real-time system monitoring**
- **Visual health indicators**
- **Direct API testing** interface
- **Complete documentation** built-in

## 🎯 Why Use FR08_master?

Instead of complex authentication and multiple tools, you get:
- **Instant access** to all admin functions
- **No login required** - just open and use
- **Complete control** over the entire system
- **Built-in documentation** and testing
- **Works standalone** or with existing services

---

**You're ready to go!** Just run it and open http://localhost:8009 in your browser.