-- FR08_master Database Initialization Script
-- This creates the minimal tables needed for FR08_master functionality

-- Create extension for UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    user_level VARCHAR(20) DEFAULT 'Guest',
    department VARCHAR(100),
    full_name VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_level ON users(user_level);
CREATE INDEX IF NOT EXISTS idx_users_department ON users(department);

-- Documents metadata table
CREATE TABLE IF NOT EXISTS documents_metadata_v2 (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true
);

-- Create indexes for documents table
CREATE INDEX IF NOT EXISTS idx_documents_category_active ON documents_metadata_v2(category, is_active);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents_metadata_v2(created_at);

-- System metrics table
CREATE TABLE IF NOT EXISTS system_metrics (
    id SERIAL PRIMARY KEY,
    container_id VARCHAR(64),
    response_time_ms INTEGER,
    cpu_usage_percent REAL,
    memory_usage_mb REAL,
    disk_io REAL,
    network_throughput REAL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for system metrics table
CREATE INDEX IF NOT EXISTS idx_system_metrics_container_timestamp ON system_metrics(container_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp_desc ON system_metrics(timestamp DESC);

-- Insert default admin user
INSERT INTO users (email, password_hash, user_level, department, full_name, is_active)
VALUES (
    'admin@fr08master.com',
    'hashed_admin123',
    'SYSTEM_ADMIN',
    'IT',
    'FR08 Master Admin',
    true
) ON CONFLICT (email) DO NOTHING;

-- Insert some sample users for testing
INSERT INTO users (email, password_hash, user_level, department, full_name, is_active)
VALUES
    ('user1@example.com', 'hashed_password1', 'Employee', 'Engineering', 'John Doe', true),
    ('user2@example.com', 'hashed_password2', 'Manager', 'Sales', 'Jane Smith', true),
    ('user3@example.com', 'hashed_password3', 'Director', 'Operations', 'Bob Johnson', true)
ON CONFLICT (email) DO NOTHING;

-- Insert some sample documents for testing
INSERT INTO documents_metadata_v2 (title, category, is_active)
VALUES
    ('Sample Document 1', 'Policy', true),
    ('Sample Document 2', 'Procedure', true),
    ('Sample Document 3', 'Manual', false),
    ('Sample Document 4', 'Guide', true)
ON CONFLICT DO NOTHING;

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for users table
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();