# FR08_master - Standalone Admin & Maintenance Tools

**Complete system administration without authentication requirements**

## 🎯 What is FR08_master?

FR08_master is a standalone version of the FR-08 admin tools that provides **full administrative access** without any authentication requirements. It includes all the functionality of the original FR-08 but can be deployed independently and accessed directly.

## ✨ Features

### 👥 User Management
- List, create, edit, and delete users
- Change user permission levels
- Search and filter users
- No authentication required

### 📄 Document Management
- View and manage all documents
- Activate/deactivate documents
- Edit document metadata
- Search and categorize documents

### 📊 System Monitoring
- Real-time CPU, memory, disk usage
- Docker container monitoring
- System health checks
- Performance alerts and thresholds
- Historical metrics tracking

### 🔧 Database Maintenance
- Create PostgreSQL backups
- Optimize database performance
- Clean up old metrics data
- Clear Redis cache
- ChromaDB optimization
- Database health monitoring

## 🚀 Quick Start

### Option 1: Windows Standalone (Recommended for you)

1. **Install Dependencies:**
   ```cmd
   cd FR08_master\standalone
   install.bat
   ```

2. **Run the Server:**
   ```cmd
   run_windows.bat
   ```

   Or manually:
   ```cmd
   python run_standalone.py
   ```

3. **Access the Dashboard:**
   - Open: http://localhost:8009
   - API Docs: http://localhost:8009/docs

### Option 2: Docker Deployment

#### Connect to Existing Services (Default)
```bash
cd FR08_master/docker
docker-compose up -d
```

#### Standalone Mode (Independent)
```bash
cd FR08_master/docker
docker-compose --profile standalone up -d
```

## 📋 Configuration

### Environment Variables

#### Connecting to Existing Services (Default)
```env
DATABASE_URL=postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2
REDIS_MASTER_URL=redis://localhost:6379/0
REDIS_REPLICA_URL=redis://localhost:6380/0
CHROMA_URL=http://localhost:8001
```

#### Standalone Mode
```env
DATABASE_URL=postgresql://fr08_admin:fr08_password123@fr08-postgres:5432/fr08_admin
REDIS_MASTER_URL=redis://fr08-redis:6379/0
CHROMA_URL=http://localhost:8001
```

## 🌐 API Endpoints

### System Health & Monitoring
- `GET /health` - Service health check
- `GET /api/admin/system` - Current system metrics
- `GET /api/admin/system/health` - Overall system health
- `GET /api/admin/system/alerts` - Current alerts
- `GET /api/admin/containers` - Docker container status

### User Management
- `GET /api/admin/users` - List all users
- `POST /api/admin/users` - Create new user
- `GET /api/admin/users/{id}` - Get specific user
- `PUT /api/admin/users/{id}` - Update user
- `DELETE /api/admin/users/{id}` - Delete user

### Document Management
- `GET /api/admin/documents` - List all documents
- `GET /api/admin/documents/{id}` - Get specific document
- `PUT /api/admin/documents/{id}` - Update document
- `DELETE /api/admin/documents/{id}` - Delete document

### Maintenance Operations
- `POST /api/admin/backup` - Create database backup
- `POST /api/admin/optimize` - Optimize database
- `POST /api/admin/cleanup/metrics?days=30` - Clean old metrics
- `POST /api/admin/cache/clear` - Clear Redis cache
- `GET /api/admin/health` - Database health check

## 🔧 Usage Examples

### Create Database Backup
```bash
curl -X POST http://localhost:8009/api/admin/backup
```

### Get System Health
```bash
curl http://localhost:8009/api/admin/system/health
```

### List All Users
```bash
curl http://localhost:8009/api/admin/users
```

### Create New User
```bash
curl -X POST http://localhost:8009/api/admin/users \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "password": "securepassword",
    "user_level": "Employee",
    "full_name": "New User",
    "department": "IT"
  }'
```

### Clean Up Old Metrics (30 days)
```bash
curl -X POST http://localhost:8009/api/admin/cleanup/metrics?days=30
```

## 📊 Dashboard Features

The web dashboard at http://localhost:8009 provides:

- **Quick Access Links** to all major functions
- **System Health Overview** with real-time metrics
- **Direct API Testing** through the interface
- **Complete API Documentation** at `/docs`

## 🔒 Security Note

**⚠️ Important:** FR08_master has **NO AUTHENTICATION** and provides **FULL ADMIN ACCESS**.

**Recommended Usage:**
- Internal networks only
- Development/testing environments
- Trusted environments
- Behind a firewall/VPN

**Do NOT expose to the public internet** without additional security measures.

## 🛠️ Troubleshooting

### Common Issues

#### "Database connection failed"
- Check if PostgreSQL is running on port 5432
- Verify credentials: `kb_admin:1234567890`
- Ensure database `knowledge_base_v2` exists

#### "Redis connection failed"
- Check if Redis is running on port 6379
- Verify Redis is accepting connections

#### "Docker containers not visible"
- Ensure Docker daemon is running
- Check Docker socket permissions
- Run with proper Docker access

#### Port 8009 already in use
- Change port in settings: `PORT=8010`
- Or stop other services using port 8009

### Logs and Debugging

Enable debug mode:
```env
DEBUG=true
LOG_LEVEL=DEBUG
```

## 📁 Directory Structure

```
FR08_master/
├── app/                    # Main application code
│   ├── api/               # API routes
│   ├── config/            # Configuration
│   ├── models/            # Database models
│   └── services/          # Business logic
├── docker/                # Docker deployment
│   ├── Dockerfile
│   ├── docker-compose.yml
│   └── init.sql
├── standalone/            # Standalone deployment
│   ├── run_standalone.py
│   ├── install.bat
│   └── run_windows.bat
└── requirements.txt
```

## 🔄 Updates and Maintenance

### Update Dependencies
```cmd
pip install -r requirements.txt --upgrade
```

### Database Migrations
Run through the maintenance interface:
- POST `/api/admin/optimize` - Update indexes and optimize
- POST `/api/admin/backup` - Create backup before changes

## 📞 Support

For issues or questions:
1. Check the logs in the console output
2. Verify all services are running
3. Check the `/health` endpoint
4. Review the API documentation at `/docs`

---

**FR08_master** - Complete administrative control, simplified deployment. ⚡