"""
Admin API routes for user and document management - NO AUTHENTICATION REQUIRED
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime
from loguru import logger

from ..config.database import get_db
from ..models.users import User
from ..models.documents import DocumentMetadata

admin_router = APIRouter()

# Pydantic models for request/response
class UserResponse(BaseModel):
    id: str
    email: str
    user_level: str
    department: Optional[str]
    full_name: Optional[str]
    is_active: bool
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True

class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    user_level: str = "Guest"
    department: Optional[str] = None
    full_name: Optional[str] = None
    is_active: bool = True

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    user_level: Optional[str] = None
    password: Optional[str] = Field(None, min_length=8)
    department: Optional[str] = None
    full_name: Optional[str] = None
    is_active: Optional[bool] = None

class DocumentResponse(BaseModel):
    id: str
    title: str
    category: Optional[str]
    created_at: str
    is_active: bool

    class Config:
        from_attributes = True

class DocumentUpdate(BaseModel):
    title: Optional[str] = Field(None, max_length=255)
    category: Optional[str] = Field(None, max_length=100)
    is_active: Optional[bool] = None

class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int

# User management endpoints
@admin_router.get("/users", response_model=PaginatedResponse)
async def list_users(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    user_level: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List all users with pagination and filtering - NO AUTH REQUIRED"""
    try:
        # Build query
        query = select(User)
        count_query = select(func.count(User.user_id))

        # Apply filters
        if search:
            search_filter = or_(
                User.email.ilike(f"%{search}%"),
                User.full_name.ilike(f"%{search}%") if User.full_name else False
            )
            query = query.where(search_filter)
            count_query = count_query.where(search_filter)

        if user_level:
            query = query.where(User.user_level == user_level)
            count_query = count_query.where(User.user_level == user_level)

        # Get total count
        total_result = await db.execute(count_query)
        total = total_result.scalar()

        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size).order_by(User.created_at.desc())

        result = await db.execute(query)
        users = result.scalars().all()

        # Convert to response format
        user_responses = []
        for user in users:
            user_responses.append(UserResponse(
                id=str(user.user_id),
                email=user.email,
                user_level=user.user_level or "Guest",
                department=user.department,
                full_name=user.full_name,
                is_active=user.is_active or True,
                created_at=user.created_at.isoformat() if user.created_at else "",
                updated_at=user.updated_at.isoformat() if user.updated_at else ""
            ))

        pages = (total + size - 1) // size

        logger.info(f"📋 Listed {len(user_responses)} users (no auth required)")

        return PaginatedResponse(
            items=user_responses,
            total=total,
            page=page,
            size=size,
            pages=pages
        )

    except Exception as e:
        logger.error(f"❌ Error listing users: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve users"
        )

@admin_router.get("/users/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get specific user by ID - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(User).where(User.user_id == user_id))
        user = result.scalar_one_or_none()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        logger.info(f"👤 Retrieved user {user.email} (no auth required)")

        return UserResponse(
            id=str(user.user_id),
            email=user.email,
            user_level=user.user_level or "Guest",
            department=user.department,
            full_name=user.full_name,
            is_active=user.is_active or True,
            created_at=user.created_at.isoformat() if user.created_at else "",
            updated_at=user.updated_at.isoformat() if user.updated_at else ""
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error getting user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve user"
        )

@admin_router.post("/users", response_model=UserResponse)
async def create_user(
    user_create: UserCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create new user - NO AUTH REQUIRED"""
    try:
        # Check if email already exists
        existing = await db.execute(select(User).where(User.email == user_create.email))
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already exists"
            )

        # Create new user
        new_user = User(
            email=user_create.email,
            password_hash=f"hashed_{user_create.password}",  # In production, properly hash this
            user_level=user_create.user_level,
            department=user_create.department,
            full_name=user_create.full_name,
            is_active=user_create.is_active
        )

        db.add(new_user)
        await db.commit()
        await db.refresh(new_user)

        logger.info(f"✅ Created new user: {new_user.email}")

        return UserResponse(
            id=str(new_user.user_id),
            email=new_user.email,
            user_level=new_user.user_level or "Guest",
            department=new_user.department,
            full_name=new_user.full_name,
            is_active=new_user.is_active or True,
            created_at=new_user.created_at.isoformat() if new_user.created_at else "",
            updated_at=new_user.updated_at.isoformat() if new_user.updated_at else ""
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"❌ Error creating user: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create user"
        )

@admin_router.put("/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    user_update: UserUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update specific user - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(User).where(User.user_id == user_id))
        user = result.scalar_one_or_none()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        # Update fields
        if user_update.email is not None:
            # Check if email already exists
            existing = await db.execute(
                select(User).where(and_(User.email == user_update.email, User.user_id != user_id))
            )
            if existing.scalar_one_or_none():
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Email already exists"
                )
            user.email = user_update.email

        if user_update.user_level is not None:
            user.user_level = user_update.user_level

        if user_update.department is not None:
            user.department = user_update.department

        if user_update.full_name is not None:
            user.full_name = user_update.full_name

        if user_update.is_active is not None:
            user.is_active = user_update.is_active

        if user_update.password is not None:
            user.password_hash = f"hashed_{user_update.password}"

        user.updated_at = datetime.utcnow()

        await db.commit()
        await db.refresh(user)

        logger.info(f"✅ Updated user: {user.email}")

        return UserResponse(
            id=str(user.user_id),
            email=user.email,
            user_level=user.user_level or "Guest",
            department=user.department,
            full_name=user.full_name,
            is_active=user.is_active or True,
            created_at=user.created_at.isoformat() if user.created_at else "",
            updated_at=user.updated_at.isoformat() if user.updated_at else ""
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"❌ Error updating user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update user"
        )

@admin_router.delete("/users/{user_id}")
async def delete_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete specific user - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(User).where(User.user_id == user_id))
        user = result.scalar_one_or_none()

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        await db.delete(user)
        await db.commit()

        logger.info(f"🗑️ Deleted user: {user.email}")

        return {"message": "User deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"❌ Error deleting user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete user"
        )

# Document management endpoints
@admin_router.get("/documents", response_model=PaginatedResponse)
async def list_documents(
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=100),
    search: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List all documents with pagination and filtering - NO AUTH REQUIRED"""
    try:
        # Build query
        query = select(DocumentMetadata)
        count_query = select(func.count(DocumentMetadata.id))

        # Apply filters
        filters = []
        if search:
            filters.append(or_(
                DocumentMetadata.title.ilike(f"%{search}%"),
                DocumentMetadata.category.ilike(f"%{search}%") if DocumentMetadata.category else False
            ))

        if category:
            filters.append(DocumentMetadata.category == category)

        if is_active is not None:
            filters.append(DocumentMetadata.is_active == is_active)

        if filters:
            filter_condition = and_(*filters)
            query = query.where(filter_condition)
            count_query = count_query.where(filter_condition)

        # Get total count
        total_result = await db.execute(count_query)
        total = total_result.scalar()

        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size).order_by(DocumentMetadata.created_at.desc())

        result = await db.execute(query)
        documents = result.scalars().all()

        # Convert to response format
        document_responses = []
        for doc in documents:
            document_responses.append(DocumentResponse(
                id=str(doc.id),
                title=doc.title,
                category=doc.category,
                created_at=doc.created_at.isoformat() if doc.created_at else "",
                is_active=doc.is_active
            ))

        pages = (total + size - 1) // size

        logger.info(f"📄 Listed {len(document_responses)} documents (no auth required)")

        return PaginatedResponse(
            items=document_responses,
            total=total,
            page=page,
            size=size,
            pages=pages
        )

    except Exception as e:
        logger.error(f"❌ Error listing documents: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve documents"
        )

@admin_router.get("/documents/{document_id}", response_model=DocumentResponse)
async def get_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Get specific document by ID - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()

        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )

        logger.info(f"📄 Retrieved document: {document.title}")

        return DocumentResponse(
            id=str(document.id),
            title=document.title,
            category=document.category,
            created_at=document.created_at.isoformat() if document.created_at else "",
            is_active=document.is_active
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error getting document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve document"
        )

@admin_router.put("/documents/{document_id}", response_model=DocumentResponse)
async def update_document(
    document_id: UUID,
    doc_update: DocumentUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update specific document - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()

        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )

        # Update fields
        if doc_update.title is not None:
            document.title = doc_update.title

        if doc_update.category is not None:
            document.category = doc_update.category

        if doc_update.is_active is not None:
            document.is_active = doc_update.is_active

        await db.commit()
        await db.refresh(document)

        logger.info(f"✅ Updated document: {document.title}")

        return DocumentResponse(
            id=str(document.id),
            title=document.title,
            category=document.category,
            created_at=document.created_at.isoformat() if document.created_at else "",
            is_active=document.is_active
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"❌ Error updating document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update document"
        )

@admin_router.delete("/documents/{document_id}")
async def delete_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """Delete specific document - NO AUTH REQUIRED"""
    try:
        result = await db.execute(select(DocumentMetadata).where(DocumentMetadata.id == document_id))
        document = result.scalar_one_or_none()

        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )

        await db.delete(document)
        await db.commit()

        logger.info(f"🗑️ Deleted document: {document.title}")

        return {"message": "Document deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        logger.error(f"❌ Error deleting document {document_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete document"
        )