"""
API package for FR08_master
"""

from .admin_routes import admin_router
from .monitoring_routes import monitoring_router
from .maintenance_routes import maintenance_router

__all__ = ["admin_router", "monitoring_router", "maintenance_router"]