"""
Database configuration for FR08_master
"""

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy import text
import redis.asyncio as redis
import asyncio
from loguru import logger

from .settings import settings

# SQLAlchemy
engine = create_async_engine(
    settings.DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://"),
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    echo=settings.DEBUG
)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)
Base = declarative_base()

# Redis connections
redis_master = None
redis_replica = None

async def get_db() -> AsyncSession:
    """Get database session"""
    async with AsyncSessionLocal() as session:
        yield session

async def get_redis_master():
    """Get Redis master connection"""
    global redis_master
    if redis_master is None:
        redis_master = redis.from_url(settings.REDIS_MASTER_URL)
    return redis_master

async def get_redis_replica():
    """Get Redis replica connection"""
    global redis_replica
    if redis_replica is None:
        redis_replica = redis.from_url(settings.REDIS_REPLICA_URL)
    return redis_replica

async def init_db():
    """Initialize database connections"""
    try:
        # Test PostgreSQL connection
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("✅ PostgreSQL connection successful")

        # Test Redis connections
        redis_m = await get_redis_master()
        await redis_m.ping()
        logger.info("✅ Redis master connection successful")

        redis_r = await get_redis_replica()
        await redis_r.ping()
        logger.info("✅ Redis replica connection successful")

        # Create tables if they don't exist
        async with engine.begin() as conn:
            from ..models.users import User
            from ..models.documents import DocumentMetadata
            from ..models.system_metrics import SystemMetrics

            await conn.run_sync(Base.metadata.create_all)
        logger.info("✅ Database tables verified/created")

    except Exception as e:
        logger.error(f"❌ Database initialization failed: {e}")
        raise

async def close_db():
    """Close database connections"""
    global redis_master, redis_replica

    if redis_master:
        await redis_master.close()
    if redis_replica:
        await redis_replica.close()

    await engine.dispose()
    logger.info("🔄 Database connections closed")