"""
FR08_master Settings - Simplified configuration without authentication
"""

from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    """Application settings"""

    # Application
    APP_NAME: str = "FR08_master"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8009

    # Database
    DATABASE_URL: str = "postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_MASTER_URL: str = "redis://localhost:6379/0"
    REDIS_REPLICA_URL: str = "redis://localhost:6380/0"

    # ChromaDB
    CHROMA_HOST: str = "localhost"
    CHROMA_PORT: int = 8001
    CHROMA_URL: str = f"http://{CHROMA_HOST}:{CHROMA_PORT}"

    # Monitoring
    PROMETHEUS_PORT: int = 9090
    GRAFANA_PORT: int = 3009

    # Maintenance
    BACKUP_DIRECTORY: str = "/tmp/backups"
    MAX_BACKUP_FILES: int = 10
    METRICS_RETENTION_DAYS: int = 30

    # CORS
    ALLOWED_ORIGINS: List[str] = ["*"]

    # Docker (for container monitoring)
    DOCKER_SOCKET: str = "unix:///var/run/docker.sock"

    # Logging
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"
        case_sensitive = True

# Global settings instance
settings = Settings()