"""
FR08_master - Standalone Admin & Maintenance Tools
No authentication required - direct access to all admin functionality
"""

__version__ = "1.0.0"
__author__ = "FR08_master"
__description__ = "Standalone Admin & Maintenance Tools without authentication"