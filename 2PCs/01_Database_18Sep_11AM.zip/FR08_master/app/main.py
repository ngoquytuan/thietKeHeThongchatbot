"""
FR08_master - Standalone Admin & Maintenance Tools
No authentication required - direct access to all admin functionality
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from contextlib import asynccontextmanager
import time
import logging
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

from app.config.settings import Settings
from app.config.database import init_db
from app.api.admin_routes import admin_router
from app.api.monitoring_routes import monitoring_router
from app.api.maintenance_routes import maintenance_router

settings = Settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    print("Starting FR08_master - Standalone Admin Tools")
    await init_db()
    yield
    print("Shutting down FR08_master")

app = FastAPI(
    title="FR08_master - Standalone Admin Tools",
    description="Complete administrative and maintenance tools without authentication",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add request processing time"""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Main dashboard page"""
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>FR08_master - Admin Dashboard</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
            .header { text-align: center; margin-bottom: 40px; }
            .section { margin: 30px 0; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
            .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
            .card { padding: 20px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #007bff; }
            .button { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin: 5px; }
            .button:hover { background: #0056b3; }
            .endpoint { font-family: monospace; background: #e9ecef; padding: 5px 10px; border-radius: 3px; margin: 5px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>FR08_master Admin Dashboard</h1>
                <p>Complete system administration without authentication</p>
            </div>

            <div class="section">
                <h2>Quick Access</h2>
                <div class="grid">
                    <div class="card">
                        <h3>API Documentation</h3>
                        <a href="/docs" class="button">OpenAPI Docs</a>
                        <a href="/redoc" class="button">ReDoc</a>
                    </div>
                    <div class="card">
                        <h3>System Health</h3>
                        <a href="/api/admin/system/health" class="button">Health Check</a>
                        <a href="/api/admin/system" class="button">System Metrics</a>
                    </div>
                    <div class="card">
                        <h3>Monitoring</h3>
                        <a href="/api/admin/system/alerts" class="button">Current Alerts</a>
                        <a href="/api/admin/containers" class="button">Container Status</a>
                    </div>
                </div>
            </div>

            <div class="section">
                <h2>User Management</h2>
                <div class="endpoint">GET /api/admin/users - List all users</div>
                <div class="endpoint">POST /api/admin/users - Create new user</div>
                <div class="endpoint">PUT /api/admin/users/{id} - Update user</div>
                <div class="endpoint">DELETE /api/admin/users/{id} - Delete user</div>
            </div>

            <div class="section">
                <h2>Document Management</h2>
                <div class="endpoint">GET /api/admin/documents - List all documents</div>
                <div class="endpoint">PUT /api/admin/documents/{id} - Update document</div>
                <div class="endpoint">DELETE /api/admin/documents/{id} - Delete document</div>
            </div>

            <div class="section">
                <h2>System Monitoring</h2>
                <div class="endpoint">GET /api/admin/system - Current system metrics</div>
                <div class="endpoint">GET /api/admin/system/historical - Historical data</div>
                <div class="endpoint">GET /api/admin/system/alerts - System alerts</div>
                <div class="endpoint">GET /api/admin/containers - Container details</div>
            </div>

            <div class="section">
                <h2>Maintenance Tools</h2>
                <div class="endpoint">POST /api/admin/backup - Create database backup</div>
                <div class="endpoint">POST /api/admin/optimize - Optimize database</div>
                <div class="endpoint">POST /api/admin/cleanup/metrics?days=30 - Cleanup old data</div>
                <div class="endpoint">POST /api/admin/cache/clear - Clear Redis cache</div>
            </div>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "FR08_master",
        "version": "1.0.0",
        "authentication": "disabled",
        "timestamp": time.time()
    }

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

# Include routers without authentication
app.include_router(admin_router, prefix="/api/admin", tags=["Admin"])
app.include_router(monitoring_router, prefix="/api/admin", tags=["Monitoring"])
app.include_router(maintenance_router, prefix="/api/admin", tags=["Maintenance"])

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting FR08_master on http://localhost:8009")
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8009,
        reload=True,
        log_level="info"
    )