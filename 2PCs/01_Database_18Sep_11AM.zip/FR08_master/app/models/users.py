"""
User Database Model for FR08_master
"""

from sqlalchemy import Column, String, DateTime, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from datetime import datetime
from enum import Enum as PyEnum
import uuid

from ..config.database import Base


class UserLevel(PyEnum):
    """User access levels for RBAC"""
    GUEST = "Guest"
    EMPLOYEE = "Employee"
    MANAGER = "Manager"
    DIRECTOR = "Director"
    SYSTEM_ADMIN = "System Admin"


class User(Base):
    """Model for users table - matches existing database structure"""

    __tablename__ = "users"

    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255))
    user_level = Column(String(20), default="Guest")
    department = Column(String(100))
    full_name = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<User(id={self.user_id}, email={self.email}, level={self.user_level})>"

    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization"""
        data = {
            "id": str(self.user_id),
            "email": self.email,
            "user_level": self.user_level,
            "department": self.department,
            "full_name": self.full_name,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

        if include_sensitive:
            data["password_hash"] = "***MASKED***"  # Never expose actual hash

        return data

    def is_system_admin(self) -> bool:
        """Check if user is system admin"""
        return self.user_level == "SYSTEM_ADMIN"