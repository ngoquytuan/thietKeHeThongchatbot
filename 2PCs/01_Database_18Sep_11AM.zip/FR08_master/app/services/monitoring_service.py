"""
System Monitoring Service for FR08_master
"""

import psutil
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import docker
from loguru import logger
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, desc

from ..models.system_metrics import SystemMetrics
from ..config.settings import settings


class MonitoringService:
    """Service for system monitoring and metrics collection"""

    def __init__(self):
        self.docker_client = None
        self._init_docker_client()

    def _init_docker_client(self):
        """Initialize Docker client with error handling"""
        try:
            self.docker_client = docker.from_env()
            self.docker_client.ping()
            logger.info("✅ Docker client initialized successfully")
        except Exception as e:
            logger.warning(f"⚠️ Docker client initialization failed: {e}")
            self.docker_client = None

    async def collect_system_metrics(self, db: AsyncSession) -> Dict[str, Any]:
        """Collect comprehensive system metrics"""
        try:
            # System-wide metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            net = psutil.net_io_counters()

            # Network metrics
            network_sent_mb = net.bytes_sent / 1024 / 1024
            network_recv_mb = net.bytes_recv / 1024 / 1024

            # Disk I/O metrics
            disk_io = psutil.disk_io_counters()
            disk_read_mb = disk_io.read_bytes / 1024 / 1024 if disk_io else 0
            disk_write_mb = disk_io.write_bytes / 1024 / 1024 if disk_io else 0

            system_metrics = {
                "cpu_usage_percent": round(cpu_percent, 2),
                "memory_percent": round(memory.percent, 2),
                "memory_used_gb": round(memory.used / 1024 / 1024 / 1024, 2),
                "memory_total_gb": round(memory.total / 1024 / 1024 / 1024, 2),
                "disk_usage_percent": round(disk.used / disk.total * 100, 2),
                "disk_used_gb": round(disk.used / 1024 / 1024 / 1024, 2),
                "disk_total_gb": round(disk.total / 1024 / 1024 / 1024, 2),
                "disk_read_mb": round(disk_read_mb, 2),
                "disk_write_mb": round(disk_write_mb, 2),
                "network_sent_mb": round(network_sent_mb, 2),
                "network_recv_mb": round(network_recv_mb, 2)
            }

            # Container metrics
            containers_data = await self._collect_container_metrics()

            # Store metrics in database
            await self._store_system_metrics(db, system_metrics)

            metrics_data = {
                "system": system_metrics,
                "containers": containers_data,
                "timestamp": datetime.utcnow().isoformat()
            }

            logger.info(f"📊 System metrics collected: CPU {cpu_percent}%, Memory {memory.percent}%")
            return metrics_data

        except Exception as e:
            logger.error(f"❌ Error collecting system metrics: {e}")
            return {
                "system": {},
                "containers": [],
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }

    async def _collect_container_metrics(self) -> List[Dict[str, Any]]:
        """Collect Docker container metrics"""
        containers_data = []

        if not self.docker_client:
            logger.warning("⚠️ Docker client not available")
            return containers_data

        try:
            containers = self.docker_client.containers.list(all=True)

            for container in containers:
                try:
                    # Get container stats
                    stats = None
                    if container.status == 'running':
                        stats = container.stats(stream=False, decode=True)

                    container_data = {
                        "id": container.id[:12],
                        "name": container.name,
                        "status": container.status,
                        "image": container.image.tags[0] if container.image.tags else "unknown",
                        "created": container.attrs['Created'],
                        "cpu_usage_percent": 0.0,
                        "memory_percent": 0.0,
                        "memory_usage_mb": 0.0,
                        "network_rx_mb": 0.0,
                        "network_tx_mb": 0.0
                    }

                    # Calculate metrics if container is running
                    if stats and container.status == 'running':
                        # CPU usage calculation
                        cpu_stats = stats.get('cpu_stats', {})
                        precpu_stats = stats.get('precpu_stats', {})

                        if cpu_stats and precpu_stats:
                            cpu_delta = cpu_stats.get('cpu_usage', {}).get('total_usage', 0) - \
                                       precpu_stats.get('cpu_usage', {}).get('total_usage', 0)
                            system_delta = cpu_stats.get('system_cpu_usage', 0) - \
                                          precpu_stats.get('system_cpu_usage', 0)

                            if system_delta > 0:
                                cpu_percent = (cpu_delta / system_delta) * \
                                            len(cpu_stats.get('cpu_usage', {}).get('percpu_usage', [])) * 100
                                container_data["cpu_usage_percent"] = round(cpu_percent, 2)

                        # Memory usage
                        memory_stats = stats.get('memory_stats', {})
                        if memory_stats:
                            memory_usage = memory_stats.get('usage', 0)
                            memory_limit = memory_stats.get('limit', 1)
                            container_data["memory_usage_mb"] = round(memory_usage / 1024 / 1024, 2)
                            container_data["memory_percent"] = round((memory_usage / memory_limit) * 100, 2)

                        # Network I/O
                        networks = stats.get('networks', {})
                        total_rx = sum(net.get('rx_bytes', 0) for net in networks.values())
                        total_tx = sum(net.get('tx_bytes', 0) for net in networks.values())
                        container_data["network_rx_mb"] = round(total_rx / 1024 / 1024, 2)
                        container_data["network_tx_mb"] = round(total_tx / 1024 / 1024, 2)

                    containers_data.append(container_data)

                except Exception as e:
                    logger.warning(f"⚠️ Error getting stats for container {container.name}: {e}")
                    containers_data.append({
                        "id": container.id[:12],
                        "name": container.name,
                        "status": container.status,
                        "error": str(e)
                    })

        except Exception as e:
            logger.error(f"❌ Error collecting container metrics: {e}")

        return containers_data

    async def _store_system_metrics(self, db: AsyncSession, metrics: Dict[str, Any]):
        """Store system metrics in database"""
        try:
            system_metric = SystemMetrics(
                cpu_usage_percent=metrics.get('cpu_usage_percent'),
                memory_usage_mb=metrics.get('memory_used_gb', 0) * 1024,  # Convert to MB
                disk_io=metrics.get('disk_read_mb', 0) + metrics.get('disk_write_mb', 0),
                network_throughput=metrics.get('network_sent_mb', 0) + metrics.get('network_recv_mb', 0),
                timestamp=datetime.utcnow()
            )

            db.add(system_metric)
            await db.commit()

        except Exception as e:
            logger.error(f"❌ Error storing system metrics: {e}")
            await db.rollback()

    async def get_historical_metrics(self, db: AsyncSession, hours: int = 24,
                                   container_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get historical system metrics"""
        try:
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)

            query = select(SystemMetrics).where(
                SystemMetrics.timestamp >= cutoff_time
            ).order_by(desc(SystemMetrics.timestamp))

            if container_id:
                query = query.where(SystemMetrics.container_id == container_id)

            result = await db.execute(query)
            metrics = result.scalars().all()

            return [metric.to_dict() for metric in metrics]

        except Exception as e:
            logger.error(f"❌ Error retrieving historical metrics: {e}")
            return []

    async def check_thresholds(self, metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check metrics against thresholds and generate alerts"""
        alerts = []

        try:
            system = metrics.get('system', {})
            containers = metrics.get('containers', [])

            # System-level thresholds
            cpu_usage = system.get('cpu_usage_percent', 0)
            if cpu_usage > 90:
                alerts.append({
                    "type": "cpu_high",
                    "message": f"System CPU usage is critical: {cpu_usage}%",
                    "threshold": 90,
                    "current": cpu_usage,
                    "severity": "critical"
                })
            elif cpu_usage > 80:
                alerts.append({
                    "type": "cpu_warning",
                    "message": f"System CPU usage is high: {cpu_usage}%",
                    "threshold": 80,
                    "current": cpu_usage,
                    "severity": "warning"
                })

            memory_usage = system.get('memory_percent', 0)
            if memory_usage > 95:
                alerts.append({
                    "type": "memory_critical",
                    "message": f"System memory usage is critical: {memory_usage}%",
                    "threshold": 95,
                    "current": memory_usage,
                    "severity": "critical"
                })
            elif memory_usage > 85:
                alerts.append({
                    "type": "memory_warning",
                    "message": f"System memory usage is high: {memory_usage}%",
                    "threshold": 85,
                    "current": memory_usage,
                    "severity": "warning"
                })

            disk_usage = system.get('disk_usage_percent', 0)
            if disk_usage > 95:
                alerts.append({
                    "type": "disk_critical",
                    "message": f"Disk usage is critical: {disk_usage}%",
                    "threshold": 95,
                    "current": disk_usage,
                    "severity": "critical"
                })
            elif disk_usage > 85:
                alerts.append({
                    "type": "disk_warning",
                    "message": f"Disk usage is high: {disk_usage}%",
                    "threshold": 85,
                    "current": disk_usage,
                    "severity": "warning"
                })

            # Container-level thresholds
            for container in containers:
                if container.get('status') != 'running':
                    continue

                container_name = container.get('name', 'unknown')
                container_cpu = container.get('cpu_usage_percent', 0)
                container_memory = container.get('memory_percent', 0)

                if container_cpu > 90:
                    alerts.append({
                        "type": "container_cpu_high",
                        "message": f"Container {container_name} CPU usage is high: {container_cpu}%",
                        "threshold": 90,
                        "current": container_cpu,
                        "severity": "warning",
                        "container": container_name
                    })

                if container_memory > 90:
                    alerts.append({
                        "type": "container_memory_high",
                        "message": f"Container {container_name} memory usage is high: {container_memory}%",
                        "threshold": 90,
                        "current": container_memory,
                        "severity": "warning",
                        "container": container_name
                    })

        except Exception as e:
            logger.error(f"❌ Error checking thresholds: {e}")
            alerts.append({
                "type": "monitoring_error",
                "message": f"Error checking system thresholds: {str(e)}",
                "severity": "warning"
            })

        return alerts