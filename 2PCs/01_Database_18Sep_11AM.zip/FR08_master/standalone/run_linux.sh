#!/bin/bash
# FR08_master Linux/macOS Runner

echo "============================================================"
echo "Starting FR08_master Admin Tools"
echo "============================================================"

python3 run_standalone.py