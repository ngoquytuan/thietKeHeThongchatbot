#!/usr/bin/env python3
"""
FR08_master Standalone Runner
Run the admin tools without Docker - direct Python execution
"""

import sys
import os
import subprocess
import platform
from pathlib import Path

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version}")
    return True

def check_and_install_dependencies():
    """Check and install required dependencies"""
    requirements_file = Path(__file__).parent.parent / "requirements.txt"

    if not requirements_file.exists():
        print("❌ Requirements file not found")
        return False

    print("📦 Installing dependencies...")
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", str(requirements_file)
        ])
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies: {e}")
        return False

def check_database_connection():
    """Check if database is accessible"""
    try:
        import asyncpg
        import asyncio

        async def test_connection():
            try:
                # Try to connect to the default database
                conn = await asyncpg.connect(
                    "postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2"
                )
                await conn.close()
                return True
            except Exception as e:
                print(f"⚠️ Database connection failed: {e}")
                return False

        result = asyncio.run(test_connection())
        if result:
            print("✅ Database connection successful")
        else:
            print("⚠️ Database connection failed - some features may not work")
        return result
    except ImportError:
        print("⚠️ asyncpg not available - skipping database check")
        return False

def check_redis_connection():
    """Check if Redis is accessible"""
    try:
        import redis

        # Try master Redis
        try:
            r = redis.from_url("redis://localhost:6379/0")
            r.ping()
            print("✅ Redis master connection successful")
            return True
        except Exception as e:
            print(f"⚠️ Redis connection failed: {e}")
            return False
    except ImportError:
        print("⚠️ redis not available - skipping Redis check")
        return False

def setup_environment():
    """Setup environment variables for standalone mode"""
    env_vars = {
        "DATABASE_URL": "postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2",
        "REDIS_MASTER_URL": "redis://localhost:6379/0",
        "REDIS_REPLICA_URL": "redis://localhost:6380/0",
        "CHROMA_URL": "http://localhost:8001",
        "ENVIRONMENT": "development",
        "DEBUG": "true",
        "LOG_LEVEL": "INFO",
        "HOST": "0.0.0.0",
        "PORT": "8009",
        "BACKUP_DIRECTORY": str(Path.home() / "fr08_backups"),
        "MAX_BACKUP_FILES": "10",
        "METRICS_RETENTION_DAYS": "30"
    }

    print("🔧 Setting up environment variables...")
    for key, value in env_vars.items():
        os.environ[key] = value

    # Create backup directory
    backup_dir = Path(env_vars["BACKUP_DIRECTORY"])
    backup_dir.mkdir(parents=True, exist_ok=True)
    print(f"📁 Backup directory: {backup_dir}")

def run_server():
    """Run the FastAPI server"""
    print("🚀 Starting FR08_master server...")
    print("📍 Server will be available at: http://localhost:8009")
    print("📖 API Documentation: http://localhost:8009/docs")
    print("🛑 Press Ctrl+C to stop the server")
    print("-" * 50)

    # Add the parent directory to Python path so we can import the app
    app_dir = Path(__file__).parent.parent
    sys.path.insert(0, str(app_dir))

    try:
        import uvicorn
        uvicorn.run(
            "app.main:app",
            host="0.0.0.0",
            port=8009,
            reload=True,
            log_level="info"
        )
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Server error: {e}")

def main():
    """Main function"""
    print("=" * 60)
    print("🔧 FR08_master Standalone Setup")
    print("=" * 60)

    # Check Python version
    if not check_python_version():
        return 1

    # Install dependencies
    if not check_and_install_dependencies():
        return 1

    # Setup environment
    setup_environment()

    # Check connections (non-blocking)
    print("\n🔍 Checking service connections...")
    db_ok = check_database_connection()
    redis_ok = check_redis_connection()

    if not db_ok and not redis_ok:
        print("\n⚠️  Warning: No database or Redis connections available")
        print("Some features may not work properly")
        response = input("Continue anyway? (y/N): ")
        if response.lower() != 'y':
            return 1

    print("\n" + "=" * 60)
    print("🎯 All checks completed!")
    print("=" * 60)

    # Run the server
    run_server()
    return 0

if __name__ == "__main__":
    exit(main())