#!/bin/bash
# FR08_master Linux/macOS Installation Script

echo "============================================================"
echo "FR08_master Standalone Installation for Linux/macOS"
echo "============================================================"

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    echo "Please install Python 3.8+ first"
    exit 1
fi

echo "✅ Python found:"
python3 --version

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not available"
    echo "Please install pip3 first"
    exit 1
fi

echo "📦 Installing dependencies..."
pip3 install -r ../requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

# Make run script executable
chmod +x run_linux.sh

echo ""
echo "============================================================"
echo "✅ Installation completed successfully!"
echo "============================================================"
echo ""
echo "To run FR08_master:"
echo "  ./run_linux.sh"
echo "  or"
echo "  python3 run_standalone.py"
echo ""