#!/usr/bin/env python3
"""
Test script for FR08_master
"""

import sys
import requests
import time
from pathlib import Path

# Add the current directory to Python path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

def test_health_endpoint():
    """Test the health endpoint"""
    try:
        response = requests.get("http://localhost:8009/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health check passed: {data}")
            return True
        else:
            print(f"❌ Health check failed: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Health check error: {e}")
        return False

def test_dashboard():
    """Test the dashboard endpoint"""
    try:
        response = requests.get("http://localhost:8009/", timeout=5)
        if response.status_code == 200:
            print("✅ Dashboard accessible")
            return True
        else:
            print(f"❌ Dashboard failed: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Dashboard error: {e}")
        return False

def test_api_docs():
    """Test the API documentation"""
    try:
        response = requests.get("http://localhost:8009/docs", timeout=5)
        if response.status_code == 200:
            print("✅ API documentation accessible")
            return True
        else:
            print(f"❌ API docs failed: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ API docs error: {e}")
        return False

def test_users_endpoint():
    """Test the users endpoint (no auth required)"""
    try:
        response = requests.get("http://localhost:8009/api/admin/users", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Users endpoint accessible: Found {data.get('total', 0)} users")
            return True
        else:
            print(f"❌ Users endpoint failed: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Users endpoint error: {e}")
        return False

def test_system_health():
    """Test the system health endpoint"""
    try:
        response = requests.get("http://localhost:8009/api/admin/system/health", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ System health accessible: Status {data.get('overall_status', 'unknown')}")
            return True
        else:
            print(f"❌ System health failed: Status {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ System health error: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("FR08_master Test Suite")
    print("=" * 60)

    print("Testing FR08_master endpoints...")
    print("Make sure FR08_master is running on http://localhost:8009")
    print("-" * 60)

    tests = [
        ("Health Check", test_health_endpoint),
        ("Dashboard", test_dashboard),
        ("API Documentation", test_api_docs),
        ("Users Endpoint", test_users_endpoint),
        ("System Health", test_system_health)
    ]

    passed = 0
    total = len(tests)

    for test_name, test_func in tests:
        print(f"Testing {test_name}...")
        if test_func():
            passed += 1
        time.sleep(1)  # Small delay between tests

    print("-" * 60)
    print(f"Test Results: {passed}/{total} tests passed")

    if passed == total:
        print("🎉 All tests passed! FR08_master is working correctly.")
        return 0
    else:
        print("⚠️ Some tests failed. Check the server status.")
        return 1

if __name__ == "__main__":
    exit(main())