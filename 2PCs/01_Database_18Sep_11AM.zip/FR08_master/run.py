#!/usr/bin/env python3
"""
FR08_master Entry Point
"""

import sys
import os
from pathlib import Path

# Add the current directory to Python path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

# Set environment variables for development
os.environ.setdefault("DATABASE_URL", "postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2")
os.environ.setdefault("REDIS_MASTER_URL", "redis://localhost:6379/0")
os.environ.setdefault("REDIS_REPLICA_URL", "redis://localhost:6380/0")
os.environ.setdefault("CHROMA_URL", "http://localhost:8001")
os.environ.setdefault("ENVIRONMENT", "development")
os.environ.setdefault("DEBUG", "true")
os.environ.setdefault("LOG_LEVEL", "INFO")
os.environ.setdefault("BACKUP_DIRECTORY", str(Path.home() / "fr08_backups"))

if __name__ == "__main__":
    import uvicorn
    print("Starting FR08_master on http://localhost:8009")
    print("API Documentation: http://localhost:8009/docs")
    print("Press Ctrl+C to stop")

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8009,
        reload=True,
        log_level="info"
    )