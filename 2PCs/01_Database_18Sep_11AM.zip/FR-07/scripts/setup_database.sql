-- FR-07 Analytics & Reporting Database Schema
-- This script creates the required tables for the Analytics module

-- Search Analytics Table
CREATE TABLE IF NOT EXISTS search_analytics (
    id SERIAL PRIMARY KEY,
    user_id UUID,
    query_text TEXT,
    processing_time_ms INTEGER,
    results_count INTEGER,
    cache_hit BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_search_analytics_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_search_analytics_timestamp ON search_analytics(timestamp);
CREATE INDEX IF NOT EXISTS idx_search_analytics_user_id ON search_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_search_analytics_cache_hit ON search_analytics(cache_hit);

-- User Activity Summary Table
CREATE TABLE IF NOT EXISTS user_activity_summary (
    user_id UUID PRIMARY KEY,
    total_queries INTEGER DEFAULT 0,
    avg_session_duration_ms INTEGER DEFAULT 0,
    last_active TIMESTAMPTZ,
    user_level VARCHAR(20) CHECK (user_level IN ('Guest', 'Employee', 'Manager', 'Director', 'System Admin')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_user_activity_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Document Usage Statistics Table
CREATE TABLE IF NOT EXISTS document_usage_stats (
    document_id UUID PRIMARY KEY,
    access_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMPTZ,
    most_frequent_user_level VARCHAR(20),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_document_usage_document FOREIGN KEY (document_id) REFERENCES documents_metadata_v2(id) ON DELETE CASCADE
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_document_usage_access_count ON document_usage_stats(access_count DESC);
CREATE INDEX IF NOT EXISTS idx_document_usage_last_accessed ON document_usage_stats(last_accessed);

-- System Metrics Table
CREATE TABLE IF NOT EXISTS system_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10,4) NOT NULL,
    metric_unit VARCHAR(20),
    component VARCHAR(50),
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_system_metrics_name ON system_metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_system_metrics_component ON system_metrics(component);

-- Report Generation Table
CREATE TABLE IF NOT EXISTS report_generation (
    report_id SERIAL PRIMARY KEY,
    report_type VARCHAR(50) CHECK (report_type IN ('daily', 'weekly', 'monthly', 'custom')),
    report_format VARCHAR(20) CHECK (report_format IN ('pdf', 'csv', 'excel', 'json')),
    report_status VARCHAR(20) CHECK (report_status IN ('pending', 'generating', 'completed', 'failed')) DEFAULT 'pending',
    file_path VARCHAR(255),
    file_size BIGINT,
    generated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    user_id UUID,
    parameters JSONB,
    error_message TEXT,
    CONSTRAINT fk_report_generation_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_report_generation_status ON report_generation(report_status);
CREATE INDEX IF NOT EXISTS idx_report_generation_type ON report_generation(report_type);
CREATE INDEX IF NOT EXISTS idx_report_generation_user ON report_generation(user_id);
CREATE INDEX IF NOT EXISTS idx_report_generation_generated_at ON report_generation(generated_at);

-- Analytics Cache Table (for pre-computed metrics)
CREATE TABLE IF NOT EXISTS analytics_cache (
    cache_key VARCHAR(255) PRIMARY KEY,
    cache_value JSONB NOT NULL,
    cache_type VARCHAR(50) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_analytics_cache_expires ON analytics_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_analytics_cache_type ON analytics_cache(cache_type);

-- Function to update user activity summary
CREATE OR REPLACE FUNCTION update_user_activity_summary()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO user_activity_summary (user_id, total_queries, last_active)
    VALUES (NEW.user_id, 1, NEW.timestamp)
    ON CONFLICT (user_id) 
    DO UPDATE SET
        total_queries = user_activity_summary.total_queries + 1,
        last_active = NEW.timestamp,
        updated_at = CURRENT_TIMESTAMP;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update user activity summary
DROP TRIGGER IF EXISTS trigger_update_user_activity ON search_analytics;
CREATE TRIGGER trigger_update_user_activity
    AFTER INSERT ON search_analytics
    FOR EACH ROW
    EXECUTE FUNCTION update_user_activity_summary();

-- Function to update document usage stats
CREATE OR REPLACE FUNCTION update_document_usage_stats(doc_id UUID, user_level_param VARCHAR(20))
RETURNS VOID AS $$
BEGIN
    INSERT INTO document_usage_stats (document_id, access_count, last_accessed, most_frequent_user_level)
    VALUES (doc_id, 1, CURRENT_TIMESTAMP, user_level_param)
    ON CONFLICT (document_id) 
    DO UPDATE SET
        access_count = document_usage_stats.access_count + 1,
        last_accessed = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP;
END;
$$ LANGUAGE plpgsql;

-- Function to clean up expired cache entries
CREATE OR REPLACE FUNCTION cleanup_expired_cache()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM analytics_cache WHERE expires_at < CURRENT_TIMESTAMP;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Create materialized view for performance dashboard
CREATE MATERIALIZED VIEW IF NOT EXISTS performance_dashboard AS
SELECT 
    date_trunc('hour', timestamp) as hour,
    COUNT(*) as query_count,
    AVG(processing_time_ms) as avg_response_time,
    COUNT(*) FILTER (WHERE cache_hit = true) * 100.0 / COUNT(*) as cache_hit_rate,
    AVG(results_count) as avg_results_count
FROM search_analytics 
WHERE timestamp >= CURRENT_TIMESTAMP - INTERVAL '24 hours'
GROUP BY date_trunc('hour', timestamp)
ORDER BY hour;

-- Create unique index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS idx_performance_dashboard_hour ON performance_dashboard(hour);

-- Function to refresh materialized views
CREATE OR REPLACE FUNCTION refresh_analytics_views()
RETURNS VOID AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY performance_dashboard;
END;
$$ LANGUAGE plpgsql;

-- Insert sample data for testing (commented out for production)
/*
INSERT INTO search_analytics (user_id, query_text, processing_time_ms, results_count, cache_hit) VALUES
(gen_random_uuid(), 'machine learning algorithms', 150, 25, true),
(gen_random_uuid(), 'data science best practices', 200, 18, false),
(gen_random_uuid(), 'python programming tutorial', 120, 42, true),
(gen_random_uuid(), 'artificial intelligence trends', 180, 33, false);

INSERT INTO system_metrics (metric_name, metric_value, metric_unit, component) VALUES
('cpu_usage', 45.5, 'percent', 'analytics-api'),
('memory_usage', 2048, 'mb', 'analytics-api'),
('response_time', 125, 'ms', 'analytics-api'),
('requests_per_second', 15.2, 'rps', 'analytics-api');
*/

-- Grant necessary permissions
-- GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO analytics_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO analytics_user;
-- GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO analytics_user;

-- Comments for documentation
COMMENT ON TABLE search_analytics IS 'Stores all search query metrics and performance data';
COMMENT ON TABLE user_activity_summary IS 'Aggregated user activity and engagement metrics';
COMMENT ON TABLE document_usage_stats IS 'Document access patterns and popularity metrics';
COMMENT ON TABLE system_metrics IS 'System performance and resource utilization metrics';
COMMENT ON TABLE report_generation IS 'Report generation requests and status tracking';
COMMENT ON TABLE analytics_cache IS 'Pre-computed analytics data for improved performance';
COMMENT ON MATERIALIZED VIEW performance_dashboard IS 'Hourly aggregated performance metrics for dashboard';