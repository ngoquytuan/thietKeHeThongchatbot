#!/bin/bash

# FR-07 Analytics & Reporting - Startup Script

set -e

echo "🚀 Starting FR-07 Analytics & Reporting Module..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Copying from .env.example..."
    cp .env.example .env
    echo "📝 Please edit .env file with your configuration before proceeding."
    exit 1
fi

# Load environment variables
source .env

echo "🔧 Checking prerequisites..."

# Check Docker and Docker Compose
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "✅ Prerequisites check passed."

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p reports
mkdir -p logs
mkdir -p config/grafana/dashboards
mkdir -p config/grafana/datasources

# Create Grafana datasource configuration
cat > config/grafana/datasources/prometheus.yml << EOF
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOF

echo "📊 Building and starting services..."

# Stop any existing containers
docker-compose down

# Build and start services
docker-compose up --build -d

echo "⏳ Waiting for services to be ready..."

# Wait for database to be ready
echo "🗄️  Waiting for PostgreSQL..."
timeout 60 bash -c 'until docker-compose exec postgres pg_isready -U $DB_USER -d $DB_NAME; do sleep 2; done'

# Wait for Redis
echo "📋 Waiting for Redis..."
timeout 30 bash -c 'until docker-compose exec redis redis-cli ping; do sleep 2; done'

# Wait for API service
echo "🔌 Waiting for Analytics API..."
timeout 60 bash -c 'until curl -f http://localhost:8001/health; do sleep 5; done'

# Wait for Dashboard
echo "📈 Waiting for Dashboard..."
timeout 60 bash -c 'until curl -f http://localhost:8501; do sleep 5; done'

echo "✅ All services are ready!"

echo ""
echo "🎉 FR-07 Analytics & Reporting Module is now running!"
echo ""
echo "📊 Access points:"
echo "   • Analytics Dashboard: http://localhost:8501"
echo "   • Analytics API: http://localhost:8001"
echo "   • API Documentation: http://localhost:8001/docs"
echo "   • Prometheus: http://localhost:9090"
echo "   • Grafana: http://localhost:3000 (admin/admin)"
echo "   • Nginx Reverse Proxy: http://localhost:80"
echo ""
echo "📋 Service Status:"
docker-compose ps

echo ""
echo "🔧 Useful commands:"
echo "   • View logs: docker-compose logs -f [service_name]"
echo "   • Stop services: docker-compose down"
echo "   • Restart service: docker-compose restart [service_name]"
echo "   • Scale API: docker-compose up --scale analytics-api=3 -d"
echo ""
echo "📖 For more information, check the documentation in handover_FR07.md"