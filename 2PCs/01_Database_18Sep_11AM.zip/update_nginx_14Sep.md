Chúng ta có thể **nâng cấp NGINX** trong FR01.2 thành **full API Gateway**. Điều này sẽ tiết kiệm tài nguyên và giảm complexity.

## **🔄 NÂNG CẤP NGINX TRONG FR01.2 THÀNH API GATEWAY**

### **📝 Cập nhật `nginx.conf` cho API Gateway:**

```nginx
# config/nginx.conf - Enhanced API Gateway
events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for" '
                    'rt=$request_time uct="$upstream_connect_time" '
                    'uht="$upstream_header_time" urt="$upstream_response_time"';

    access_log /var/log/nginx/access.log main;
    error_log /var/log/nginx/error.log warn;

    # Performance optimizations
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 100M;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript
               application/json application/javascript application/xml+rss
               application/atom+xml image/svg+xml;

    # Rate limiting zones
    limit_req_zone $binary_remote_addr zone=auth_limit:10m rate=10r/m;
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=100r/m;
    limit_req_zone $binary_remote_addr zone=rag_limit:10m rate=60r/m;
    limit_req_zone $binary_remote_addr zone=admin_limit:10m rate=30r/m;

    # Connection limiting
    limit_conn_zone $binary_remote_addr zone=conn_limit_per_ip:10m;
    limit_conn_zone $server_name zone=conn_limit_per_server:10m;

    # Upstream definitions
    upstream pc1_auth_service {
        least_conn;
        server host.docker.internal:8001 max_fails=3 fail_timeout=30s;
        keepalive 32;
    }

    upstream pc1_admin_tools {
        least_conn;
        server host.docker.internal:8002 max_fails=3 fail_timeout=30s;
        keepalive 32;
    }

    upstream pc1_analytics {
        least_conn;
        server host.docker.internal:8003 max_fails=3 fail_timeout=30s;
        keepalive 32;
    }

    upstream pc1_web_interface {
        least_conn;
        server host.docker.internal:8004 max_fails=3 fail_timeout=30s;
        keepalive 32;
    }

    upstream pc2_rag_api {
        least_conn;
        server 192.168.1.101:8033 max_fails=3 fail_timeout=30s;
        server 192.168.1.101:8034 max_fails=3 fail_timeout=30s backup;
        keepalive 32;
    }

    upstream pc2_embedding_service {
        least_conn;
        server 192.168.1.101:8010 max_fails=3 fail_timeout=30s;
        keepalive 16;
    }

    # Internal services (same container network)
    upstream internal_postgres {
        server postgres:5432;
    }

    upstream internal_chroma {
        server chroma:8000;
    }

    upstream internal_redis {
        server redis-master:6379;
    }

    upstream internal_grafana {
        server grafana:3000;
    }

    upstream internal_prometheus {
        server prometheus:9090;
    }

    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Main Server Block
    server {
        listen 80 default_server;
        listen [::]:80 default_server;
        listen 443 ssl http2 default_server;
        listen [::]:443 ssl http2 default_server;

        server_name chatbot.local localhost;

        # SSL certificates
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;

        # Connection limits
        limit_conn conn_limit_per_ip 20;
        limit_conn conn_limit_per_server 500;

        # Redirect HTTP to HTTPS
        if ($scheme != "https") {
            return 301 https://$host$request_uri;
        }

        # ===== MAIN WEB INTERFACE =====
        location / {
            limit_req zone=api_limit burst=50 nodelay;

            proxy_pass http://pc1_web_interface;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;

            proxy_connect_timeout 5s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # ===== AUTHENTICATION API (PC1:8001) =====
        location /api/v1/auth/ {
            limit_req zone=auth_limit burst=20 nodelay;

            proxy_pass http://pc1_auth_service/api/v1/auth/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            # Auth-specific timeouts
            proxy_connect_timeout 5s;
            proxy_send_timeout 30s;
            proxy_read_timeout 30s;
        }

        # ===== RAG API (PC2:8033) =====
        location /api/v1/rag/ {
            limit_req zone=rag_limit burst=10 nodelay;

            proxy_pass http://pc2_rag_api/api/v1/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            # RAG-specific timeouts (longer for AI processing)
            proxy_connect_timeout 10s;
            proxy_send_timeout 120s;
            proxy_read_timeout 120s;
            proxy_buffering off;  # For streaming responses
        }

        # ===== ADMIN TOOLS API (PC1:8002) =====
        location /api/v1/admin/ {
            limit_req zone=admin_limit burst=30 nodelay;

            # IP restriction for admin access
            allow 192.168.1.0/24;
            allow 172.20.0.0/16;  # Docker network
            allow 127.0.0.1;
            deny all;

            # Admin authentication check
            auth_request /auth-check;

            proxy_pass http://pc1_admin_tools/api/admin/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # ===== ANALYTICS API (PC1:8003) =====
        location /api/v1/analytics/ {
            limit_req zone=api_limit burst=50 nodelay;

            proxy_pass http://pc1_analytics/api/v1/analytics/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # ===== EMBEDDING SERVICE (PC2:8010) =====
        location /api/v1/embeddings/ {
            limit_req zone=api_limit burst=30 nodelay;

            proxy_pass http://pc2_embedding_service/;
            proxy_http_version 1.1;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            proxy_connect_timeout 10s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # ===== INTERNAL SERVICES ACCESS =====
        # Database Admin (Adminer)
        location /adminer/ {
            allow 192.168.1.0/24;
            allow 172.20.0.0/16;
            deny all;

            proxy_pass http://adminer:8080/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }

        # Grafana Monitoring
        location /grafana/ {
            proxy_pass http://internal_grafana/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;

            # WebSocket support for Grafana
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
        }

        # Prometheus Monitoring
        location /prometheus/ {
            allow 192.168.1.0/24;
            allow 172.20.0.0/16;
            deny all;

            proxy_pass http://internal_prometheus/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }

        # ===== HEALTH CHECKS =====
        location /health {
            access_log off;
            return 200 "healthy\n";
            add_header Content-Type text/plain;
        }

        location /health/detailed {
            access_log off;
            content_by_lua_block {
                local health_status = {
                    status = "healthy",
                    timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ"),
                    services = {}
                }
                ngx.header.content_type = "application/json"
                ngx.say(require("cjson").encode(health_status))
            }
        }

        # Authentication check endpoint
        location = /auth-check {
            internal;
            proxy_pass http://pc1_auth_service/api/v1/auth/verify;
            proxy_pass_request_body off;
            proxy_set_header Content-Length "";
            proxy_set_header X-Original-URI $request_uri;
        }

        # ===== NGINX STATUS & METRICS =====
        location /nginx-status {
            stub_status on;
            access_log off;
            allow 127.0.0.1;
            allow 172.20.0.0/16;
            deny all;
        }

        location /metrics {
            access_log off;
            allow 172.20.0.0/16;
            allow 192.168.1.0/24;
            deny all;

            # Prometheus metrics endpoint
            content_by_lua_block {
                local prometheus = require("resty.prometheus").init("prometheus_metrics")
                prometheus:collect()
            }
        }

        # ===== STATIC ASSETS =====
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
            add_header Vary Accept-Encoding;

            # Try local first, then proxy to web interface
            try_files $uri @proxy_static;
        }

        location @proxy_static {
            proxy_pass http://pc1_web_interface;
            proxy_set_header Host $host;
            proxy_cache static_cache;
            proxy_cache_valid 200 1d;
        }

        # ===== ERROR PAGES =====
        error_page 404 /404.html;
        error_page 500 502 503 504 /50x.html;

        location = /50x.html {
            root /usr/share/nginx/html;
        }
    }

    # Cache configuration
    proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=static_cache:10m inactive=60m;
}
```

### **📝 Cập nhật Docker Compose:**

```yaml
# Thêm vào phần nginx service trong docker-compose.yml hiện tại:
  nginx:
    image: nginx:alpine
    container_name: fr02-nginx-gateway  # Rename để phản ánh vai trò mới
    ports:
      - "80:80"
      - "443:443"
      - "9113:9113"  # nginx-exporter metrics
    volumes:
      - ./config/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./config/ssl:/etc/nginx/ssl:ro
      - ./logs/nginx:/var/log/nginx
      - nginx_cache:/var/cache/nginx
    environment:
      - PC1_IP=${PC1_IP:-192.168.1.100}
      - PC2_IP=${PC2_IP:-192.168.1.101}
    extra_hosts:
      - "host.docker.internal:host-gateway"  # Access to host services
    depends_on:
      - chroma
      - postgres
      - redis-master
      - grafana
      - prometheus
    restart: unless-stopped
    networks:
      - fr02-network
    healthcheck:
      test: ["CMD", "nginx", "-t"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Thêm nginx exporter cho monitoring
  nginx-exporter:
    image: nginx/nginx-prometheus-exporter:latest
    container_name: fr02-nginx-exporter
    ports:
      - "9113:9113"
    command:
      - -nginx.scrape-uri=http://nginx:80/nginx-status
    depends_on:
      - nginx
    restart: unless-stopped
    networks:
      - fr02-network

# Thêm volume cho nginx cache
volumes:
  nginx_cache:
    driver: local
```

### **🔐 Tạo SSL Certificates:**

```bash
#!/bin/bash
# scripts/setup-ssl.sh
mkdir -p config/ssl

# Self-signed certificate cho development
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout config/ssl/key.pem \
    -out config/ssl/cert.pem \
    -subj "/C=VN/ST=HoChiMinh/L=HoChiMinh/O=ChatbotAI/OU=Development/CN=chatbot.local/emailAddress=admin@chatbot.local"

# Set proper permissions
chmod 600 config/ssl/key.pem
chmod 644 config/ssl/cert.pem

echo "✅ SSL certificates created successfully!"
```

### **📊 Cập nhật Prometheus Configuration:**

```yaml
# config/prometheus.yml - Thêm nginx metrics
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  # Existing configs...

  # NGINX Gateway metrics
  - job_name: 'nginx-gateway'
    static_configs:
      - targets: ['nginx-exporter:9113']
    scrape_interval: 30s
    metrics_path: /metrics

  # NGINX status
  - job_name: 'nginx-status'
    static_configs:
      - targets: ['nginx:80']
    metrics_path: /nginx-status
    scrape_interval: 30s
```

### **🚀 Deployment Script cập nhật:**

```bash
#!/bin/bash
# scripts/deploy-enhanced-gateway.sh

echo "🚀 Deploying Enhanced NGINX API Gateway..."

# Load environment
source .env.global

# Setup SSL certificates
./scripts/setup-ssl.sh

# Create log directories
mkdir -p logs/nginx

# Deploy stack with enhanced gateway
docker-compose up -d

# Wait for services
echo "⏳ Waiting for services to start..."
sleep 30

# Health checks
echo "❤️ Running health checks..."
curl -f http://localhost/health || exit 1
curl -f https://localhost/health -k || exit 1

echo "✅ Enhanced NGINX API Gateway deployed successfully!"
echo ""
echo "🌐 Access URLs:"
echo "  Main Interface: https://localhost"
echo "  Admin Tools:    https://localhost/api/v1/admin/"
echo "  Analytics:      https://localhost/api/v1/analytics/"
echo "  RAG API:        https://localhost/api/v1/rag/"
echo "  Grafana:        https://localhost/grafana/"
echo "  Adminer:        https://localhost/adminer/"
echo ""
echo "📊 Monitoring:"
echo "  Prometheus:     https://localhost/prometheus/"
echo "  NGINX Status:   http://localhost/nginx-status"
echo "  NGINX Metrics:  http://localhost:9113/metrics"
```

### **⚙️ Environment Variables mới:**

Thêm vào `.env.global`:

```env
# ===== NGINX API GATEWAY CONFIGURATION =====
# Network IPs
PC1_IP=192.168.1.100
PC2_IP=192.168.1.101

# Rate Limiting
AUTH_RATE_LIMIT=10r/m
API_RATE_LIMIT=100r/m
RAG_RATE_LIMIT=60r/m
ADMIN_RATE_LIMIT=30r/m

# Connection Limits
MAX_CONN_PER_IP=20
MAX_CONN_PER_SERVER=500

# SSL Configuration
SSL_PROTOCOLS="TLSv1.2 TLSv1.3"
SSL_CIPHERS="ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384"

# Cache Settings
PROXY_CACHE_SIZE=10m
PROXY_CACHE_INACTIVE=60m
STATIC_CACHE_EXPIRE=1y

# Timeouts
PROXY_CONNECT_TIMEOUT=10s
PROXY_SEND_TIMEOUT=120s
PROXY_READ_TIMEOUT=120s
```

## **✅ ADVANTAGES của approach này:**

1. **Tái sử dụng Infrastructure**: Không cần module mới
2. **Centralized Management**: Tất cả routing ở một nơi
3. **Performance**: NGINX rất nhanh và ổn định
4. **Monitoring Integration**: Đã có sẵn Prometheus + Grafana
5. **SSL Termination**: Centralized HTTPS handling
6. **Rate Limiting**: Built-in protection
7. **Load Balancing**: Tự động failover
8. **Caching**: Static assets và API responses

## **🎯 FINAL DEPLOYMENT:**

```bash
# 1. Update nginx config
cp enhanced-nginx.conf config/nginx.conf

# 2. Setup SSL
./scripts/setup-ssl.sh

# 3. Deploy
docker-compose up -d --force-recreate nginx

# 4. Test
curl -f https://localhost/health -k
```

**Kết quả: NGINX trong FR01.2 bây giờ trở thành full-featured API Gateway với load balancing, rate limiting, SSL termination, và monitoring - HOÀN HẢO! 🎉**