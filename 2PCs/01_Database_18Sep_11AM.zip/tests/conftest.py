import pytest
import os
import time
import docker
import requests
from typing import Generator

# Load environment variables from .env file if it exists
if os.path.exists('.env'):
    with open('.env') as f:
        for line in f:
            if line.strip() and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                os.environ[key] = value

@pytest.fixture(scope="session")
def docker_client():
    """Docker client for service management"""
    return docker.from_env()

@pytest.fixture(scope="session", autouse=True)
def ensure_services_running(docker_client):
    """Ensure all required services are running before tests"""
    required_services = [
        'fr02-postgres-v2',
        'fr02-chroma-v2',
        'fr02-redis-master',
        'fr02-prometheus',
        'fr02-grafana'
    ]
    
    # Check if services are running
    running_containers = {c.name for c in docker_client.containers.list()}
    
    for service in required_services:
        if service not in running_containers:
            pytest.skip(f"Required service {service} is not running. Please run 'docker-compose up -d' first.")
    
    # Wait for services to be ready
    wait_for_services()

def wait_for_services():
    """Wait for all services to be healthy"""
    services = [
        ('PostgreSQL', 'localhost', 5432, check_postgres),
        ('ChromaDB', 'localhost', 8000, check_chroma),
        ('Redis', 'localhost', 6379, check_redis),
        ('Prometheus', 'localhost', 9090, check_prometheus),
        ('Grafana', 'localhost', 3000, check_grafana)
    ]
    
    for service_name, host, port, check_func in services:
        max_retries = 30
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                if check_func(host, port):
                    print(f"✅ {service_name} is ready")
                    break
            except Exception as e:
                pass
            
            retry_count += 1
            if retry_count >= max_retries:
                pytest.skip(f"{service_name} is not responding after {max_retries} retries")
            
            time.sleep(2)

def check_postgres(host, port):
    """Check if PostgreSQL is ready"""
    import psycopg2
    try:
        password = os.getenv('POSTGRES_PASSWORD', 'changeme')
        conn = psycopg2.connect(
            host=host,
            port=port,
            database='knowledge_base_v2',
            user='kb_admin',
            password=password,
            connect_timeout=5
        )
        conn.close()
        return True
    except:
        return False

def check_chroma(host, port):
    """Check if ChromaDB is ready"""
    try:
        response = requests.get(f'http://{host}:{port}/api/v1/heartbeat', timeout=5)
        return response.status_code == 200
    except:
        return False

def check_redis(host, port):
    """Check if Redis is ready"""
    import redis
    try:
        r = redis.Redis(host=host, port=port, socket_connect_timeout=5)
        return r.ping()
    except:
        return False

def check_prometheus(host, port):
    """Check if Prometheus is ready"""
    try:
        response = requests.get(f'http://{host}:{port}/-/healthy', timeout=5)
        return response.status_code == 200
    except:
        return False

def check_grafana(host, port):
    """Check if Grafana is ready"""
    try:
        response = requests.get(f'http://{host}:{port}/api/health', timeout=5)
        return response.status_code == 200
    except:
        return False