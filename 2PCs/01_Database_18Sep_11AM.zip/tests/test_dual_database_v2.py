import pytest
import asyncio
import asyncpg
import chromadb
import redis
import numpy as np
from typing import Dict, Any
import uuid
import time
import os

@pytest.mark.asyncio
class TestDualDatabaseV2:
    
    @pytest.fixture
    async def postgres_connection(self):
        """Setup PostgreSQL connection for tests"""
        password = os.getenv('POSTGRES_PASSWORD', 'changeme')
        conn = await asyncpg.connect(
            f"postgresql://kb_admin:{password}@localhost:5432/knowledge_base_v2"
        )
        yield conn
        await conn.close()
    
    @pytest.fixture
    def chroma_client(self):
        """Setup ChromaDB client for tests"""
        auth_token = os.getenv('CHROMA_AUTH_TOKEN', '')
        headers = {"X-Chroma-Token": auth_token} if auth_token else {}
        return chromadb.HttpClient(host="localhost", port=8000, headers=headers)
    
    @pytest.fixture
    def redis_client(self):
        """Setup Redis client for tests"""
        return redis.Redis(host="localhost", port=6379, decode_responses=True)
    
    async def test_postgresql_vietnamese_support(self, postgres_connection):
        """Test PostgreSQL Vietnamese language support"""
        test_text = "Hướng dẫn sử dụng hệ thống quản lý tài liệu"
        
        # Test Vietnamese text normalization
        normalized = await postgres_connection.fetchval(
            "SELECT normalize_vietnamese_text($1)", test_text
        )
        
        assert "huong dan" in normalized
        assert "he thong" in normalized
        
        # Test document insertion with Vietnamese content
        doc_id = await postgres_connection.fetchval("""
            INSERT INTO documents_metadata_v2 
            (title, content, document_type, access_level, department_owner, author)
            VALUES ($1, $2, 'manual', 'employee_only', 'IT', 'Test Author')
            RETURNING document_id
        """, test_text, f"Nội dung tài liệu: {test_text}")
        
        assert doc_id is not None
        
        # Cleanup
        await postgres_connection.execute(
            "DELETE FROM documents_metadata_v2 WHERE document_id = $1", doc_id
        )
    
    def test_chroma_vietnamese_embeddings(self, chroma_client):
        """Test ChromaDB with Vietnamese content"""
        try:
            collection = chroma_client.get_collection("knowledge_base_v2")
        except:
            collection = chroma_client.create_collection(
                name="knowledge_base_v2",
                metadata={"embedding_dimension": 1024}
            )
        
        # Test Vietnamese document addition
        vietnamese_docs = [
            {
                'id': 'test_vi_1',
                'content': 'Hướng dẫn sử dụng hệ thống chatbot tiếng Việt',
                'embedding': np.random.rand(1024).tolist(),
                'metadata': {'language': 'vi', 'type': 'guide'}
            },
            {
                'id': 'test_vi_2',
                'content': 'Chính sách làm việc từ xa của công ty',
                'embedding': np.random.rand(1024).tolist(),
                'metadata': {'language': 'vi', 'type': 'policy'}
            }
        ]
        
        collection.add(
            ids=[doc['id'] for doc in vietnamese_docs],
            embeddings=[doc['embedding'] for doc in vietnamese_docs],
            documents=[doc['content'] for doc in vietnamese_docs],
            metadatas=[doc['metadata'] for doc in vietnamese_docs]
        )
        
        # Test Vietnamese search
        query_embedding = np.random.rand(1024).tolist()
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=2,
            where={"language": "vi"}
        )
        
        assert len(results['ids'][0]) == 2
        assert all('vi' in doc for doc in results['documents'][0])
        
        # Cleanup
        collection.delete(ids=['test_vi_1', 'test_vi_2'])
    
    def test_redis_cache_performance(self, redis_client):
        """Test Redis caching performance"""
        # Test basic operations
        redis_client.set('test_key', 'test_value', ex=300)
        assert redis_client.get('test_key') == 'test_value'
        
        # Test Vietnamese text caching
        vietnamese_text = "Hệ thống quản lý tài liệu tiếng Việt"
        redis_client.hset('vietnamese_cache', 'test_doc', vietnamese_text)
        
        cached_text = redis_client.hget('vietnamese_cache', 'test_doc')
        assert cached_text == vietnamese_text
        
        # Test performance
        start_time = time.time()
        for i in range(1000):
            redis_client.set(f'perf_test_{i}', f'value_{i}')
        operation_time = time.time() - start_time
        
        assert operation_time < 1.0  # Should complete in under 1 second
        
        # Cleanup
        redis_client.delete('test_key')
        redis_client.delete('vietnamese_cache')
        for i in range(1000):
            redis_client.delete(f'perf_test_{i}')
    
    async def test_integrated_search_workflow(self, postgres_connection, chroma_client):
        """Test complete search workflow integration"""
        # Create test user
        user_id = await postgres_connection.fetchval("""
            INSERT INTO users (username, email, password_hash, user_level, department)
            VALUES ('test_integration', 'test@integration.com', 'hash123', 'EMPLOYEE', 'IT')
            RETURNING user_id
        """)
        
        # Create test document
        doc_id = await postgres_connection.fetchval("""
            INSERT INTO documents_metadata_v2 
            (title, content, document_type, access_level, department_owner, author)
            VALUES ('Test Integration Doc', 'Content for integration testing', 
                    'technical_guide', 'employee_only', 'IT', 'Test Author')
            RETURNING document_id
        """)
        
        # Create test chunks
        chunk_ids = []
        for i in range(3):
            chunk_id = await postgres_connection.fetchval("""
                INSERT INTO document_chunks_enhanced 
                (document_id, chunk_content, chunk_position, chunk_size_tokens, 
                 semantic_boundary, chunk_method, embedding_model)
                VALUES ($1, $2, $3, 100, true, 'semantic_boundary', 'Qwen/Qwen3-Embedding-0.6B')
                RETURNING chunk_id
            """, doc_id, f'Test chunk content {i}', i)
            chunk_ids.append(chunk_id)
        
        # Add to ChromaDB
        try:
            collection = chroma_client.get_collection("knowledge_base_v2")
        except:
            collection = chroma_client.create_collection("knowledge_base_v2")
        
        embeddings = [np.random.rand(1024).tolist() for _ in range(3)]
        collection.add(
            ids=[f"chunk_{i}" for i in range(3)],
            embeddings=embeddings,
            documents=[f'Test chunk content {i}' for i in range(3)],
            metadatas=[{
                'document_id': str(doc_id),
                'chunk_id': str(chunk_ids[i]),
                'access_level': 'employee_only'
            } for i in range(3)]
        )
        
        # Test search
        query_embedding = np.random.rand(1024).tolist()
        search_results = collection.query(
            query_embeddings=[query_embedding],
            n_results=3,
            where={"access_level": "employee_only"}
        )
        
        assert len(search_results['ids'][0]) == 3
        
        # Verify database consistency
        db_chunks = await postgres_connection.fetch(
            "SELECT chunk_id FROM document_chunks_enhanced WHERE document_id = $1", doc_id
        )
        assert len(db_chunks) == 3
        
        # Cleanup
        collection.delete(ids=[f"chunk_{i}" for i in range(3)])
        await postgres_connection.execute("DELETE FROM users WHERE user_id = $1", user_id)
        await postgres_connection.execute("DELETE FROM documents_metadata_v2 WHERE document_id = $1", doc_id)
    
    async def test_performance_benchmarks(self, postgres_connection, chroma_client):
        """Test system performance benchmarks"""
        # Database query performance
        start_time = time.time()
        result = await postgres_connection.fetchval("SELECT COUNT(*) FROM documents_metadata_v2")
        db_query_time = time.time() - start_time
        
        assert db_query_time < 0.1  # Should be under 100ms
        
        # Vector search performance
        try:
            collection = chroma_client.get_collection("knowledge_base_v2")
            
            query_embedding = np.random.rand(1024).tolist()
            start_time = time.time()
            
            results = collection.query(
                query_embeddings=[query_embedding],
                n_results=5
            )
            
            vector_search_time = time.time() - start_time
            assert vector_search_time < 0.5  # Should be under 500ms
            
        except Exception as e:
            pytest.skip(f"ChromaDB collection not available: {e}")

    async def test_database_schema_validation(self, postgres_connection):
        """Test that all required tables and indexes exist"""
        # Check required tables
        required_tables = [
            'users', 'documents_metadata_v2', 'document_chunks_enhanced',
            'vietnamese_text_analysis', 'data_ingestion_jobs', 'system_health_metrics'
        ]
        
        for table_name in required_tables:
            exists = await postgres_connection.fetchval("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_schema = 'public' 
                    AND table_name = $1
                )
            """, table_name)
            assert exists, f"Required table {table_name} does not exist"
        
        # Check required functions
        required_functions = [
            'normalize_vietnamese_text', 'extract_emails_from_text'
        ]
        
        for func_name in required_functions:
            exists = await postgres_connection.fetchval("""
                SELECT EXISTS (
                    SELECT FROM pg_proc 
                    WHERE proname = $1
                )
            """, func_name)
            assert exists, f"Required function {func_name} does not exist"

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])