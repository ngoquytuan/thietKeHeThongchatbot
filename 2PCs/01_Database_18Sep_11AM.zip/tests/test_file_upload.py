#!/usr/bin/env python3
# tests/test_file_upload.py

import asyncio
import asyncpg
import json
import os
import shutil
import uuid
import hashlib
from datetime import datetime
from pathlib import Path
import tempfile
import mimetypes

class FileUploadTester:
    def __init__(self, db_url="postgresql://kb_admin:1234567890@localhost:5432/knowledge_base_v2"):
        self.db_url = db_url
        self.storage_base = "D:\\chatbot-storage"
        
    async def test_file_upload_workflow(self):
        """Test complete file upload and storage workflow"""
        
        print("Starting File Upload Test...")

        # 1. Create test file
        test_file_info = await self.create_test_file()
        print(f"[OK] Created test file: {test_file_info['file_path']}")

        # 2. Simulate FR03.1 export package
        package_info = await self.create_mock_export_package(test_file_info)
        print(f"[OK] Created mock export package: {package_info['package_path']}")

        # 3. Test file preservation
        preserved_info = await self.preserve_files_to_storage(test_file_info, package_info)
        print(f"[OK] Files preserved to storage: {preserved_info['original_path']}")

        # 4. Test database insertion
        document_id = await self.insert_document_with_files(test_file_info, preserved_info)
        print(f"[OK] Document inserted to database: {document_id}")

        # 5. Test file access via API
        access_result = await self.test_file_access_api(document_id)
        print(f"[OK] File access test: {access_result}")

        # 6. Test file serving
        serve_result = await self.test_file_serving(document_id)
        print(f"[OK] File serving test: {serve_result}")

        print("All tests completed successfully!")
        return {
            'document_id': document_id,
            'test_file': test_file_info,
            'preserved_files': preserved_info
        }
    
    async def create_test_file(self):
        """Create a test PDF file for upload testing"""
        
        # Create temporary test file
        test_content = """
        # Test Document for FR-02.1 File Management

        This is a test document to verify file upload and storage functionality.

        ## Document Information
        - Created: {datetime.now().isoformat()}
        - Purpose: File management testing
        - System: Vietnamese Chatbot FR-02.1 v2.0

        ## Vietnamese Content Test
        Day la tai lieu thu nghiem de kiem tra chuc nang quan ly file.
        He thong chatbot tieng Viet can luu tru va truy xuat files mot cach chinh xac.

        Test Vietnamese characters: aeuio
        """.strip()
        
        # Create temp file
        temp_dir = tempfile.mkdtemp()
        test_file_path = os.path.join(temp_dir, "test_document.txt")
        
        with open(test_file_path, 'w', encoding='utf-8') as f:
            f.write(test_content)
        
        # Calculate file hash
        file_hash = self.calculate_file_hash(test_file_path)
        file_size = os.path.getsize(test_file_path)
        
        return {
            'file_path': test_file_path,
            'filename': 'test_document.txt',
            'content': test_content,
            'file_hash': file_hash,
            'file_size': file_size,
            'mime_type': 'text/plain',
            'temp_dir': temp_dir
        }
    
    async def create_mock_export_package(self, test_file_info):
        """Create mock FR03.1 export package structure"""
        
        package_dir = os.path.join(test_file_info['temp_dir'], 'mock_package')
        os.makedirs(package_dir, exist_ok=True)
        
        # Create package structure
        original_dir = os.path.join(package_dir, 'original')
        for_db_dir = os.path.join(package_dir, 'FOR_DATABASE')
        os.makedirs(original_dir, exist_ok=True)
        os.makedirs(for_db_dir, exist_ok=True)
        
        # Copy original file
        shutil.copy2(test_file_info['file_path'], 
                    os.path.join(original_dir, test_file_info['filename']))
        
        # Create manifest
        manifest = {
            'package_name': 'TEST_DOCUMENT_' + datetime.now().strftime('%Y%m%d_%H%M%S'),
            'original_filename': test_file_info['filename'],
            'file_size_bytes': test_file_info['file_size'],
            'file_hash': test_file_info['file_hash'],
            'mime_type': test_file_info['mime_type'],
            'created_at': datetime.now().isoformat(),
            'author_email': 'test@example.com',
            'chunk_count': 1
        }
        
        with open(os.path.join(package_dir, 'manifest.json'), 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)

        # Create document metadata
        document_metadata = {
            'document_id': str(uuid.uuid4()),
            'title': 'Test Document for File Management',
            'document_type': 'manual',
            'access_level': 'employee_only',
            'department_owner': 'IT',
            'author': 'Test System',
            'status': 'approved',
            'language_detected': 'vi',
            'vietnamese_segmented': True,
            'diacritics_normalized': True,
            'tone_marks_preserved': True,
            'search_text_normalized': 'test document file management system',
            'indexable_content': test_file_info['content'][:500],
            'chunk_count': 1,
            'file_size_bytes': test_file_info['file_size'],
            'embedding_model_primary': 'Qwen/Qwen3-Embedding-0.6B'
        }

        with open(os.path.join(for_db_dir, 'document_metadata_v2.json'), 'w', encoding='utf-8') as f:
            json.dump(document_metadata, f, indent=2, ensure_ascii=False)
        
        return {
            'package_path': package_dir,
            'manifest': manifest,
            'document_metadata': document_metadata
        }
    
    async def preserve_files_to_storage(self, test_file_info, package_info):
        """Simulate file preservation to shared storage"""
        
        # Create date-based storage path
        now = datetime.now()
        date_path = f"{now.year:04d}/{now.month:02d}/{now.day:02d}"
        package_name = package_info['manifest']['package_name']
        
        # Prepare storage paths
        original_storage_dir = f"{self.storage_base}/original/{date_path}/{package_name}"
        packages_storage_dir = f"{self.storage_base}/packages/{date_path}"
        
        # Create directories
        os.makedirs(original_storage_dir, exist_ok=True)
        os.makedirs(packages_storage_dir, exist_ok=True)
        
        # Copy original file
        original_file_path = os.path.join(original_storage_dir, test_file_info['filename'])
        shutil.copy2(test_file_info['file_path'], original_file_path)
        
        # Create file metadata
        file_metadata = {
            "original_filename": test_file_info['filename'],
            "preserved_at": now.isoformat(),
            "file_size": test_file_info['file_size'],
            "file_hash": test_file_info['file_hash'],
            "processing_job_id": str(uuid.uuid4()),
            "package_source": package_name,
            "preservation_method": "test_copy"
        }
        
        with open(os.path.join(original_storage_dir, 'file_metadata.json'), 'w', encoding='utf-8') as f:
            json.dump(file_metadata, f, indent=2, ensure_ascii=False)
        
        # Create package archive (simulate)
        package_archive_path = os.path.join(packages_storage_dir, f"{package_name}.zip")
        shutil.make_archive(package_archive_path.replace('.zip', ''), 'zip', package_info['package_path'])
        
        return {
            'original_path': original_file_path,
            'package_path': package_archive_path,
            'metadata_path': os.path.join(original_storage_dir, 'file_metadata.json'),
            'storage_dir': original_storage_dir
        }
    
    async def insert_document_with_files(self, test_file_info, preserved_info):
        """Insert document with file information into database"""
        
        conn = await asyncpg.connect(self.db_url)
        
        try:
            document_id = uuid.uuid4()
            
            # Prepare file information
            original_file_info = {
                "original_file_path": preserved_info['original_path'],
                "original_filename": test_file_info['filename'],
                "file_size_bytes": test_file_info['file_size'],
                "file_hash": test_file_info['file_hash'],
                "mime_type": test_file_info['mime_type'],
                "upload_timestamp": datetime.now().isoformat(),
                "uploaded_by": "test_system",
                "file_accessible": True,
                "preservation_status": "preserved"
            }
            
            export_package_info = {
                "fr03_1_package_path": preserved_info['package_path'],
                "package_timestamp": datetime.now().isoformat(),
                "package_hash": self.calculate_file_hash(preserved_info['package_path']),
                "package_size_bytes": os.path.getsize(preserved_info['package_path']),
                "export_version": "1.0",
                "processing_job_id": str(uuid.uuid4()),
                "package_accessible": True
            }
            
            file_access_info = {
                "storage_tier": "warm",
                "access_count": 0,
                "last_accessed": None,
                "retention_policy": "7_years",
                "backup_locations": [],
                "legal_hold": False,
                "scheduled_deletion": None
            }
            
            # Insert document
            await conn.execute("""
                INSERT INTO documents_metadata_v2 (
                    document_id, title, content, document_type, access_level,
                    department_owner, author, status, language_detected,
                    vietnamese_segmented, diacritics_normalized, tone_marks_preserved,
                    search_text_normalized, indexable_content, extracted_emails,
                    extracted_phones, extracted_dates, embedding_model_primary,
                    chunk_count, file_size_bytes, search_tokens,
                    original_file_info, export_package_info, file_access_info,
                    created_at, updated_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14,
                    $15, $16, $17, $18, $19, $20, to_tsvector('simple', $13),
                    $21, $22, $23, $24, $25
                )
            """,
            document_id,
            'Test Document for File Management',
            test_file_info['content'],
            'manual',
            'employee_only',
            'IT',
            'Test System',
            'approved',
            'vi',
            True, True, True,
            'test document file management system',
            test_file_info['content'][:500],
            [], [], [],
            'Qwen/Qwen3-Embedding-0.6B',
            1,
            test_file_info['file_size'],
            json.dumps(original_file_info),
            json.dumps(export_package_info),
            json.dumps(file_access_info),
            datetime.now(),
            datetime.now()
            )
            
            return str(document_id)
            
        finally:
            await conn.close()
    
    async def test_file_access_api(self, document_id):
        """Test file access through API"""
        
        conn = await asyncpg.connect(self.db_url)
        
        try:
            # Query document file info
            result = await conn.fetchrow("""
                SELECT original_file_info, export_package_info, title
                FROM documents_metadata_v2
                WHERE document_id = $1
            """, uuid.UUID(document_id))
            
            if not result:
                return {'status': 'failed', 'reason': 'Document not found'}
            
            original_info = json.loads(result['original_file_info'])
            package_info = json.loads(result['export_package_info'])
            
            # Check file accessibility
            original_accessible = os.path.exists(original_info['original_file_path'])
            package_accessible = os.path.exists(package_info['fr03_1_package_path'])
            
            return {
                'status': 'success',
                'original_file_accessible': original_accessible,
                'package_accessible': package_accessible,
                'original_path': original_info['original_file_path'],
                'package_path': package_info['fr03_1_package_path']
            }
            
        finally:
            await conn.close()
    
    async def test_file_serving(self, document_id):
        """Test file serving through API endpoint"""
        
        import aiohttp
        
        try:
            async with aiohttp.ClientSession() as session:
                # Test original file endpoint
                async with session.get(f'http://localhost:8002/api/documents/{document_id}/original') as resp:
                    original_status = resp.status
                    original_headers = dict(resp.headers)
                
                # Test package endpoint
                async with session.get(f'http://localhost:8002/api/documents/{document_id}/package') as resp:
                    package_status = resp.status
                    package_headers = dict(resp.headers)
                
                return {
                    'original_endpoint': {
                        'status': original_status,
                        'content_type': original_headers.get('content-type'),
                        'success': original_status == 200
                    },
                    'package_endpoint': {
                        'status': package_status,
                        'content_type': package_headers.get('content-type'),
                        'success': package_status == 200
                    }
                }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e),
                'note': 'API might not be running'
            }
    
    def calculate_file_hash(self, file_path):
        """Calculate SHA256 hash of file"""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return f"sha256:{hash_sha256.hexdigest()}"
    
    async def cleanup_test_data(self, test_results):
        """Clean up test data"""
        
        print("Cleaning up test data...")

        # Remove from database
        conn = await asyncpg.connect(self.db_url)
        try:
            await conn.execute("""
                DELETE FROM documents_metadata_v2
                WHERE document_id = $1
            """, uuid.UUID(test_results['document_id']))
            print("[OK] Database records cleaned")
        finally:
            await conn.close()

        # Remove test files
        if 'preserved_files' in test_results:
            storage_dir = test_results['preserved_files']['storage_dir']
            if os.path.exists(storage_dir):
                shutil.rmtree(os.path.dirname(storage_dir))
                print("[OK] Storage files cleaned")

        # Remove temp files
        if 'test_file' in test_results:
            temp_dir = test_results['test_file']['temp_dir']
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
                print("[OK] Temporary files cleaned")

async def main():
    """Main test runner"""
    
    print("FR-02.1 File Upload Test Suite")
    print("=" * 50)

    tester = FileUploadTester()

    try:
        # Run tests
        results = await tester.test_file_upload_workflow()

        print("\nTest Results Summary:")
        print(f"Document ID: {results['document_id']}")
        print(f"Original file: {results['preserved_files']['original_path']}")
        print(f"Package file: {results['preserved_files']['package_path']}")

        # Optional: Clean up
        cleanup = input("\nClean up test data? (y/N): ").lower() == 'y'
        if cleanup:
            await tester.cleanup_test_data(results)
        else:
            print("Test data preserved for manual inspection")

    except Exception as e:
        print(f"[ERROR] Test failed: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())