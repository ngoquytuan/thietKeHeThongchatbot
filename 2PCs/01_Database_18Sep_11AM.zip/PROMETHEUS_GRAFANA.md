Dựa trên kết quả tìm kiếm trong project knowledge, tôi thấy rằng **Prometheus và Grafana** xuất hiện trong nhiều module khác nhau:

## 📊 **PROMETHEUS & GRAFANA TRONG CẤU TRÚC DỰ ÁN**

### **FR-02.1: Dual Database System**
- **Prometheus**: Metrics collection cho PostgreSQL, ChromaDB, Redis
- **Grafana**: Database performance dashboards
- **Scope**: Infrastructure monitoring cho database layer

### **FR-07: Analytics & Reporting** 
- **Prometheus**: Application metrics và business metrics
- **Grafana**: Analytics dashboards cho user behavior, search patterns
- **Scope**: Business intelligence và reporting

### **FR-08: Admin & Maintenance Tools**
- **Prometheus**: System health monitoring
- **Grafana**: Admin dashboards cho system administration
- **Scope**: Administrative monitoring và maintenance

## 🎯 **PHÂN CHIA TRÁCH NHIỆM**

### **FR-02.1 (Infrastructure Monitoring)**
```yaml
# Prometheus trong FR-02.1
scrape_configs:
  - job_name: 'postgres-exporter'
  - job_name: 'redis-exporter' 
  - job_name: 'chroma-api'
  - job_name: 'node-exporter'
```

### **FR-07 (Business Analytics)**
```python
# Prometheus trong FR-07
from prometheus_client import Counter, Histogram, Gauge
search_queries_total = Counter('search_queries_total')
response_time_histogram = Histogram('response_time_seconds')
```

### **FR-08 (System Administration)**
```yaml
# Prometheus trong FR-08
admin_operations_total = Counter('admin_operations_total')
system_health_gauge = Gauge('system_health_status')
```

## 🔧 **KHUYẾN NGHỊ THIẾT KẾ**

### **Tách biệt theo Layer:**
1. **FR-02.1**: Infrastructure metrics (database, cache, storage)
2. **FR-07**: Application metrics (business logic, user analytics)  
3. **FR-08**: Administrative metrics (system health, maintenance)

### **Shared Configuration:**
- **Centralized Prometheus**: Một instance duy nhất collect từ tất cả modules
- **Dedicated Grafana Dashboards**: Mỗi module có dashboard riêng
- **Alert Manager**: Chung cho toàn hệ thống

## 📋 **CẬP NHẬT CHO FR-02.1 v2.0**

Trong tài liệu FR-02.1 v2.0, cần làm rõ:

```yaml
# FR-02.1 chỉ tập trung vào Infrastructure Monitoring
prometheus:
  role: "Infrastructure Metrics Collection"
  scope: 
    - Database performance (PostgreSQL, ChromaDB)
    - Cache performance (Redis)
    - Storage metrics
    - Network performance
  
grafana:
  role: "Infrastructure Dashboards" 
  scope:
    - Database connection pools
    - Query performance
    - Cache hit rates
    - Storage utilization
```

Tài liệu FR-02.1 v2.0 hiện tại đã đúng khi đặt Prometheus/Grafana trong infrastructure monitoring, nhưng nên bổ sung note về coordination với các module khác để tránh confusion.