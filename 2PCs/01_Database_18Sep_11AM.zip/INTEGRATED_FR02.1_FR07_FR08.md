Dựa trên docker-compose hiện tại của FR-02.1 và handover documents của FR-07, FR-08, tôi sẽ hướng dẫn tích hợp thành một docker-compose file duy nhất.

## 🎯 **INTEGRATED FR-02.1 + FR-07 + FR-08 ARCHITECTURE**

### **Current FR-02.1 Services:**
- PostgreSQL, ChromaDB, Redis, Prometheus, Grafana ✅
- PgBouncer, Node Exporter, Adminer, Nginx ✅  
- fr02-file-api ✅

### **Adding:**
- **FR-07 Analytics API** (port 8003)
- **FR-07 Streamlit Dashboard** (port 8501)
- **FR-08 Admin API** (port 8004)

## 📋 **PHASE 1: Directory Structure Update (15 phút)**

### **Step 1.1: Extend FR-02.1 Structure**
```bash
cd D:\Projects\checkbot\FR-02.1

# Add new directories for integrated modules
mkdir -p analytics/{app/{api,core,models,schemas,services},dashboard}
mkdir -p admin/{app/{api,core,models,schemas,services}}
mkdir -p scripts/analytics
mkdir -p scripts/admin
```

### **Step 1.2: Create Analytics Module Structure**
```
FR-02.1/
├── analytics/
│   ├── app/
│   │   ├── api/
│   │   │   └── analytics_endpoints.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   └── database.py
│   │   ├── models/
│   │   │   └── analytics.py
│   │   ├── schemas/
│   │   │   └── analytics.py
│   │   ├── services/
│   │   │   └── analytics_service.py
│   │   └── main.py
│   ├── dashboard/
│   │   └── streamlit_app.py
│   ├── Dockerfile
│   └── requirements.txt
├── admin/
│   ├── app/
│   │   ├── api/
│   │   │   ├── admin_endpoints.py
│   │   │   └── maintenance_endpoints.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   └── database.py
│   │   ├── models/
│   │   │   └── admin.py
│   │   ├── services/
│   │   │   ├── admin_service.py
│   │   │   └── monitoring_service.py
│   │   └── main.py
│   ├── Dockerfile  
│   └── requirements.txt
```

## 📋 **PHASE 2: Database Schema Integration (30 phút)**

### **Step 2.1: Update Database Init Script**
```sql
-- scripts/01_init_database_V5.sql (update existing)
-- Add to existing init script

-- ================================
-- FR-07 ANALYTICS TABLES
-- ================================

-- Search Analytics
CREATE TABLE IF NOT EXISTS search_analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    query_text TEXT NOT NULL,
    processing_time_ms INTEGER,
    results_count INTEGER,
    has_results BOOLEAN DEFAULT FALSE,
    cache_hit BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- User Activity Summary
CREATE TABLE IF NOT EXISTS user_activity_summary (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    date DATE NOT NULL,
    search_count INTEGER DEFAULT 0,
    session_duration_minutes INTEGER DEFAULT 0,
    documents_accessed INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, date)
);

-- Document Usage Statistics
CREATE TABLE IF NOT EXISTS document_usage_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES documents_metadata_v2(document_id),
    access_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMPTZ,
    most_frequent_user_level user_level,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- System Metrics
CREATE TABLE IF NOT EXISTS system_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(100) NOT NULL,
    metric_value FLOAT,
    metric_unit VARCHAR(20),
    component VARCHAR(50),
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Analytics Cache
CREATE TABLE IF NOT EXISTS analytics_cache (
    cache_key VARCHAR(255) PRIMARY KEY,
    cache_value JSONB NOT NULL,
    cache_type VARCHAR(50) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ================================
-- FR-08 ADMIN TABLES
-- ================================

-- Admin Actions Log
CREATE TABLE IF NOT EXISTS admin_actions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_user_id UUID REFERENCES users(user_id),
    action_type VARCHAR(50) NOT NULL,
    target_resource VARCHAR(100),
    target_id VARCHAR(100),
    action_details JSONB,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- System Health Log
CREATE TABLE IF NOT EXISTS system_health_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component_name VARCHAR(50) NOT NULL,
    status VARCHAR(20) CHECK (status IN ('healthy', 'unhealthy', 'degraded')),
    cpu_usage FLOAT,
    memory_usage FLOAT,
    disk_usage FLOAT,
    response_time_ms INTEGER,
    error_message TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- Backup Status
CREATE TABLE IF NOT EXISTS backup_status (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    backup_type VARCHAR(50) NOT NULL,
    backup_path VARCHAR(500),
    file_size_bytes BIGINT,
    status VARCHAR(20) CHECK (status IN ('started', 'completed', 'failed')),
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    error_message TEXT
);

-- ================================
-- INDEXES FOR PERFORMANCE
-- ================================

-- Analytics indexes
CREATE INDEX IF NOT EXISTS idx_search_analytics_timestamp ON search_analytics(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_search_analytics_user_date ON search_analytics(user_id, DATE(timestamp));
CREATE INDEX IF NOT EXISTS idx_user_activity_date ON user_activity_summary(date DESC);
CREATE INDEX IF NOT EXISTS idx_document_usage_access_count ON document_usage_stats(access_count DESC);
CREATE INDEX IF NOT EXISTS idx_system_metrics_component_timestamp ON system_metrics(component, timestamp DESC);

-- Admin indexes  
CREATE INDEX IF NOT EXISTS idx_admin_actions_admin_timestamp ON admin_actions(admin_user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_admin_actions_type_timestamp ON admin_actions(action_type, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_system_health_component_timestamp ON system_health_log(component_name, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_backup_status_timestamp ON backup_status(started_at DESC);
```

## 📋 **PHASE 3: Analytics Module Implementation (45 phút)**

### **Step 3.1: Create Analytics API**
```python
# analytics/app/main.py
from fastapi import FastAPI, Depends, HTTPException
from analytics.app.api.analytics_endpoints import router as analytics_router
from analytics.app.core.database import get_db, engine
from analytics.app.models import analytics
import uvicorn

app = FastAPI(
    title="FR-07 Analytics Module",
    description="Integrated Analytics for RAG Knowledge Assistant",
    version="1.0.0"
)

# Create tables
@app.on_event("startup")
async def create_tables():
    async with engine.begin() as conn:
        await conn.run_sync(analytics.Base.metadata.create_all)

# Include routers
app.include_router(analytics_router, prefix="/api/v1/analytics", tags=["Analytics"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "FR-07 Analytics"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8003, reload=False)
```

```python
# analytics/app/api/analytics_endpoints.py
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from analytics.app.core.database import get_db
from analytics.app.services.analytics_service import AnalyticsService
from typing import Optional
from datetime import datetime

router = APIRouter()

@router.get("/search-metrics")
async def get_search_metrics(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    user_level: Optional[str] = Query(None),
    limit: int = Query(100, le=1000),
    db: AsyncSession = Depends(get_db)
):
    """Get search analytics metrics"""
    service = AnalyticsService(db)
    return await service.get_search_metrics(start_date, end_date, user_level, limit)

@router.get("/user-activity")
async def get_user_activity(
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    department: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """Get user activity analytics"""
    service = AnalyticsService(db)
    return await service.get_user_activity(start_date, end_date, department)

@router.get("/document-usage")
async def get_document_usage(
    document_type: Optional[str] = Query(None),
    min_access_count: Optional[int] = Query(1),
    limit: int = Query(50, le=500),
    db: AsyncSession = Depends(get_db)
):
    """Get document usage statistics"""
    service = AnalyticsService(db)
    return await service.get_document_usage(document_type, min_access_count, limit)

@router.get("/system-metrics")
async def get_system_metrics(
    component: Optional[str] = Query(None),
    hours: int = Query(24, le=168),
    db: AsyncSession = Depends(get_db)
):
    """Get system performance metrics"""
    service = AnalyticsService(db)
    return await service.get_system_metrics(component, hours)
```

### **Step 3.2: Create Streamlit Dashboard**
```python
# analytics/dashboard/streamlit_app.py
import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

st.set_page_config(
    page_title="RAG Analytics Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("🤖 RAG Knowledge Assistant Analytics")
st.markdown("Real-time analytics dashboard cho Vietnamese Chatbot System")

# API Base URL
API_BASE = "http://fr02-analytics:8003/api/v1/analytics"

# Sidebar filters
st.sidebar.header("📅 Filters")
date_range = st.sidebar.date_input(
    "Select Date Range",
    value=[datetime.now() - timedelta(days=7), datetime.now()],
    max_value=datetime.now()
)

user_level = st.sidebar.selectbox(
    "User Level",
    options=["All", "EMPLOYEE", "MANAGER", "DIRECTOR", "SYSTEM_ADMIN"]
)

# Main dashboard
col1, col2, col3, col4 = st.columns(4)

try:
    # Fetch data from analytics API
    search_response = requests.get(f"{API_BASE}/search-metrics", params={
        "start_date": date_range[0].isoformat() if len(date_range) == 2 else None,
        "end_date": date_range[1].isoformat() if len(date_range) == 2 else None,
        "user_level": user_level if user_level != "All" else None
    })
    
    if search_response.status_code == 200:
        search_data = search_response.json()
        
        # Metrics cards
        with col1:
            st.metric("Total Searches", search_data.get("total_searches", 0))
        with col2:
            st.metric("Avg Response Time", f"{search_data.get('avg_response_time', 0)}ms")
        with col3:
            st.metric("Success Rate", f"{search_data.get('success_rate', 0):.1f}%")
        with col4:
            st.metric("Cache Hit Rate", f"{search_data.get('cache_hit_rate', 0):.1f}%")
            
        # Charts
        if search_data.get("daily_metrics"):
            df = pd.DataFrame(search_data["daily_metrics"])
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📈 Daily Search Volume")
                fig = px.line(df, x='date', y='search_count', 
                             title='Search Volume Over Time')
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.subheader("⏱️ Response Time Trends")
                fig = px.line(df, x='date', y='avg_response_time',
                             title='Average Response Time (ms)')
                st.plotly_chart(fig, use_container_width=True)
    
    # User Activity Section
    st.subheader("👥 User Activity Analytics")
    
    user_response = requests.get(f"{API_BASE}/user-activity", params={
        "start_date": date_range[0].isoformat() if len(date_range) == 2 else None,
        "end_date": date_range[1].isoformat() if len(date_range) == 2 else None
    })
    
    if user_response.status_code == 200:
        user_data = user_response.json()
        
        if user_data.get("by_department"):
            dept_df = pd.DataFrame(user_data["by_department"])
            
            col1, col2 = st.columns(2)
            
            with col1:
                fig = px.bar(dept_df, x='department', y='active_users',
                            title='Active Users by Department')
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                fig = px.pie(dept_df, values='search_count', names='department',
                            title='Search Distribution by Department')
                st.plotly_chart(fig, use_container_width=True)

except requests.exceptions.RequestException as e:
    st.error(f"❌ Cannot connect to analytics API: {str(e)}")
    st.info("Make sure the analytics service is running on port 8003")

# Auto-refresh
if st.sidebar.checkbox("Auto Refresh (30s)", value=False):
    st.rerun()
```

### **Step 3.3: Analytics Dockerfile**
```dockerfile
# analytics/Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY app/ ./app/
COPY dashboard/ ./dashboard/

# Default command (can be overridden in docker-compose)
CMD ["python", "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8003"]
```

```txt
# analytics/requirements.txt
fastapi>=0.104.1
uvicorn[standard]>=0.24.0
sqlalchemy>=2.0.23
asyncpg>=0.29.0
redis>=5.0.1
pydantic>=2.5.0
pydantic-settings>=2.1.0
streamlit>=1.28.0
plotly>=5.17.0
pandas>=2.1.4
requests>=2.31.0
```

## 📋 **PHASE 4: Admin Module Implementation (45 phút)**

### **Step 4.1: Create Admin API**
```python
# admin/app/main.py
from fastapi import FastAPI, Depends
from admin.app.api.admin_endpoints import router as admin_router
from admin.app.api.maintenance_endpoints import router as maintenance_router
from admin.app.core.database import get_db, engine
from admin.app.models import admin
import uvicorn

app = FastAPI(
    title="FR-08 Admin & Maintenance Tools",
    description="System Administration for RAG Knowledge Assistant",
    version="1.0.0"
)

@app.on_event("startup")
async def create_tables():
    async with engine.begin() as conn:
        await conn.run_sync(admin.Base.metadata.create_all)

# Include routers
app.include_router(admin_router, prefix="/api/v1/admin", tags=["Administration"])
app.include_router(maintenance_router, prefix="/api/v1/maintenance", tags=["Maintenance"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "FR-08 Admin Tools"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8004, reload=False)
```

```python
# admin/app/api/admin_endpoints.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from admin.app.core.database import get_db
from admin.app.services.admin_service import AdminService
from typing import Optional

router = APIRouter()

@router.get("/users")
async def list_users(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    user_level: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List users with pagination and filtering"""
    service = AdminService(db)
    return await service.list_users(page, size, user_level, is_active)

@router.get("/users/{user_id}")
async def get_user(
    user_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get specific user details"""
    service = AdminService(db)
    user = await service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.put("/users/{user_id}")
async def update_user(
    user_id: str,
    user_update: dict,
    db: AsyncSession = Depends(get_db)
):
    """Update user information"""
    service = AdminService(db)
    return await service.update_user(user_id, user_update)

@router.get("/documents")
async def list_documents(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    document_type: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List documents with pagination"""
    service = AdminService(db)
    return await service.list_documents(page, size, document_type, is_active)

@router.get("/system/stats")
async def get_system_stats(
    db: AsyncSession = Depends(get_db)
):
    """Get overall system statistics"""
    service = AdminService(db)
    return await service.get_system_stats()
```

### **Step 4.2: Admin Dockerfile**
```dockerfile
# admin/Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies for monitoring
RUN apt-get update && apt-get install -y \
    gcc \
    postgresql-client \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY app/ ./app/

# Expose port
EXPOSE 8004

CMD ["python", "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8004"]
```

```txt
# admin/requirements.txt
fastapi>=0.104.1
uvicorn[standard]>=0.24.0
sqlalchemy>=2.0.23
asyncpg>=0.29.0
redis>=5.0.1
pydantic>=2.5.0
pydantic-settings>=2.1.0
psutil>=5.9.6
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
prometheus-client>=0.19.0
```

## 📋 **PHASE 5: Updated Docker Compose (30 phút)**

### **Step 5.1: Enhanced docker-compose.yml**
```yaml
# docker-compose.yml (updated from existing FR-02.1)
version: '3.8'

services:
  # ================================
  # EXISTING FR-02.1 SERVICES (keep as is)
  # ================================
  postgres:
    image: postgres:15-alpine
    container_name: fr02-postgres-v2
    environment:
      POSTGRES_DB: knowledge_base_v2
      POSTGRES_USER: kb_admin
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_INITDB_ARGS: "--encoding=UTF8 --locale=C.UTF-8"
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./config/postgres.conf:/etc/postgresql/postgresql.conf
      - ./scripts/01_init_database_V5.sql:/docker-entrypoint-initdb.d/01_init_database.sql  # Updated
      - chatbot_storage:/opt/chatbot-storage
    command: postgres -c config_file=/etc/postgresql/postgresql.conf
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U kb_admin -d knowledge_base_v2"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 60s
    networks:
      - fr02-network

  # Keep all existing services (pgbouncer, chroma, redis, prometheus, grafana, etc.)
  # ... (copy all existing services from current docker-compose.yml)

  # ================================  
  # NEW: FR-07 ANALYTICS SERVICES
  # ================================
  fr02-analytics:
    build:
      context: ./analytics
      dockerfile: Dockerfile
    container_name: fr02-analytics
    ports:
      - "8003:8003"
    environment:
      - DATABASE_URL=postgresql+asyncpg://kb_admin:${POSTGRES_PASSWORD}@postgres:5432/knowledge_base_v2
      - REDIS_URL=redis://redis-master:6379/3
      - API_PORT=8003
      - LOG_LEVEL=INFO
    depends_on:
      postgres:
        condition: service_healthy
      redis-master:
        condition: service_healthy
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8003/health || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - fr02-network

  fr02-analytics-dashboard:
    build:
      context: ./analytics
      dockerfile: Dockerfile
    container_name: fr02-analytics-dashboard
    ports:
      - "8501:8501"
    environment:
      - ANALYTICS_API_URL=http://fr02-analytics:8003
    command: streamlit run dashboard/streamlit_app.py --server.port 8501 --server.address 0.0.0.0
    depends_on:
      - fr02-analytics
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8501/_stcore/health || exit 1"]
      interval: 60s
      timeout: 10s
      retries: 3
    networks:
      - fr02-network

  # ================================
  # NEW: FR-08 ADMIN SERVICES  
  # ================================
  fr02-admin:
    build:
      context: ./admin
      dockerfile: Dockerfile
    container_name: fr02-admin
    ports:
      - "8004:8004"
    environment:
      - DATABASE_URL=postgresql+asyncpg://kb_admin:${POSTGRES_PASSWORD}@postgres:5432/knowledge_base_v2
      - REDIS_URL=redis://redis-master:6379/4
      - CHROMADB_URL=http://chroma:8001
      - JWT_SECRET_KEY=${JWT_SECRET_KEY:-default-secret-key}
      - LOG_LEVEL=INFO
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock  # For container monitoring
      - backup_data:/app/backups
    depends_on:
      postgres:
        condition: service_healthy
      redis-master:
        condition: service_healthy
      chroma:
        condition: service_healthy
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8004/health || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
    networks:
      - fr02-network

  # ================================
  # UPDATED SERVICES
  # ================================
  
  # Update Prometheus to scrape new services
  prometheus:
    image: prom/prometheus:latest
    container_name: fr02-prometheus
    ports:
      - "9090:9090"
    volumes:
      - prometheus_data:/prometheus
      - ./config/prometheus-integrated.yml:/etc/prometheus/prometheus.yml  # Updated config
      - ./config/alert_rules.yml:/etc/prometheus/alert_rules.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=30d'
      - '--web.enable-lifecycle'
      - '--web.enable-admin-api'
    depends_on:
      - fr02-analytics
      - fr02-admin
    restart: unless-stopped
    networks:
      - fr02-network

  # Update Nginx to proxy new services  
  nginx:
    image: nginx:alpine
    container_name: fr02-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./config/nginx-integrated.conf:/etc/nginx/nginx.conf  # Updated config
      - ./config/ssl:/etc/nginx/ssl
    depends_on:
      - chroma
      - postgres
      - fr02-analytics
      - fr02-admin
      - fr02-analytics-dashboard
    restart: unless-stopped
    networks:
      - fr02-network

# Add new volume
volumes:
  postgres_data:
    driver: local
  chroma_data:
    driver: local
  redis_data:
    driver: local
  redis_replica_data:
    driver: local
  prometheus_data:
    driver: local
  grafana_data:
    driver: local
  backup_data:  # NEW: For admin backups
    driver: local
  chatbot_storage:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: D:\chatbot-storage

networks:
  fr02-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

### **Step 5.2: Updated Prometheus Config**
```yaml
# config/prometheus-integrated.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  # Existing targets
  - job_name: 'postgres-exporter'
    static_configs:
      - targets: ['postgres-exporter:9187']

  - job_name: 'redis-exporter'
    static_configs:
      - targets: ['redis-exporter:9121']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  # NEW: Analytics service
  - job_name: 'fr02-analytics'
    static_configs:
      - targets: ['fr02-analytics:8003']
    metrics_path: '/metrics'
    scrape_interval: 30s

  # NEW: Admin service
  - job_name: 'fr02-admin'
    static_configs:
      - targets: ['fr02-admin:8004']
    metrics_path: '/metrics'
    scrape_interval: 30s

  # Existing file API
  - job_name: 'fr02-file-api'
    static_configs:
      - targets: ['fr02-file-api:8000']
    metrics_path: '/metrics'
```

### **Step 5.3: Updated Nginx Config**
```nginx
# config/nginx-integrated.conf
events {
    worker_connections 1024;
}

http {
    upstream analytics_api {
        server fr02-analytics:8003;
    }
    
    upstream admin_api {
        server fr02-admin:8004;
    }
    
    upstream analytics_dashboard {
        server fr02-analytics-dashboard:8501;
    }

    # Analytics API
    server {
        listen 80;
        server_name analytics.localhost;
        
        location / {
            proxy_pass http://analytics_api;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }

    # Admin API  
    server {
        listen 80;
        server_name admin.localhost;
        
        location / {
            proxy_pass http://admin_api;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }

    # Analytics Dashboard
    server {
        listen 80;
        server_name dashboard.localhost;
        
        location / {
            proxy_pass http://analytics_dashboard;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
        }
    }

    # Main app (existing)
    server {
        listen 80 default_server;
        
        location /analytics/ {
            proxy_pass http://analytics_api/;
        }
        
        location /admin/ {
            proxy_pass http://admin_api/;
        }
        
        location /dashboard/ {
            proxy_pass http://analytics_dashboard/;
        }
        
        # Existing ChromaDB, other services...
    }
}
```

## 🚀 **PHASE 6: Deployment & Testing (30 phút)**

### **Step 6.1: Environment Setup**
```bash
# Update .env file
echo "# Integrated FR-02.1 + FR-07 + FR-08" >> .env
echo "POSTGRES_PASSWORD=1234567890" >> .env
echo "JWT_SECRET_KEY=integrated-fr02-fr07-fr08-secret-2025" >> .env
echo "GRAFANA_PASSWORD=admin123456" >> .env
echo "CHROMA_AUTH_TOKEN=1234567890" >> .env
```

### **Step 6.2: Build and Deploy**
```bash
# Stop existing services
cd D:\Projects\checkbot\FR-02.1
docker-compose down

# Build new integrated services
docker-compose build fr02-analytics fr02-admin

# Start all services
docker-compose up -d

# Verify all services are running
docker-compose ps
```

### **Step 6.3: Testing Integration**
```bash
# Test all services
curl http://localhost:5432  # PostgreSQL
curl http://localhost:8001/api/v2/heartbeat  # ChromaDB
curl http://localhost:6379  # Redis (telnet)
curl http://localhost:8003/health  # Analytics API
curl http://localhost:8004/health  # Admin API  
curl http://localhost:8501  # Analytics Dashboard
curl http://localhost:9090/-/healthy  # Prometheus
curl http://localhost:3009  # Grafana (port 3009 from your config)
```

## 🎯 **SUCCESS CRITERIA**

### **Integration Success:**
- [ ] All existing FR-02.1 services continue working
- [ ] Analytics API responds on port 8003
- [ ] Admin API responds on port 8004
- [ ] Streamlit dashboard loads on port 8501
- [ ] Prometheus scrapes all services
- [ ] Shared database contains all tables
- [ ] All services in same Docker network

### **Expected URLs:**
```bash
# Infrastructure
http://localhost:5432    # PostgreSQL
http://localhost:8001    # ChromaDB
http://localhost:6379    # Redis

# Original FR-02.1
http://localhost:8002    # File API
http://localhost:8081    # Adminer

# NEW Integrated Services  
http://localhost:8003    # Analytics API
http://localhost:8004    # Admin API
http://localhost:8501    # Analytics Dashboard

# Monitoring
http://localhost:9090    # Prometheus
http://localhost:3009    # Grafana
```

**Total estimated time: 3-4 hours** for complete integration với testing.

**Key benefits:**
- **Single docker-compose file** cho toàn bộ system
- **Shared infrastructure** (PostgreSQL, Redis, monitoring)
- **Centralized management** và easier maintenance
- **Cost-effective** resource usage

Bạn muốn bắt đầu với Phase 1 không? Tôi sẽ hướng dẫn từng bước cụ thể.