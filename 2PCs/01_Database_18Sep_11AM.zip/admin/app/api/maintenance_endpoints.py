from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.maintenance_service import MaintenanceService

router = APIRouter()

@router.post("/backup")
async def create_database_backup(
    db: AsyncSession = Depends(get_db)
):
    """Create PostgreSQL database backup"""
    service = MaintenanceService(db)
    result = await service.create_database_backup()

    if not result["success"]:
        raise HTTPException(status_code=500, detail=result["message"])

    return result

@router.post("/optimize")
async def optimize_database(
    db: AsyncSession = Depends(get_db)
):
    """Run database optimization (ANALYZE and REINDEX)"""
    service = MaintenanceService(db)
    result = await service.optimize_database()

    if not result["success"]:
        raise HTTPException(status_code=500, detail=result["message"])

    return result

@router.get("/health")
async def check_database_health(
    db: AsyncSession = Depends(get_db)
):
    """Check database component health"""
    service = MaintenanceService(db)
    return await service.check_database_health()

@router.post("/cache/clear")
async def clear_redis_cache(
    db: AsyncSession = Depends(get_db)
):
    """Clear Redis cache"""
    service = MaintenanceService(db)
    result = await service.clear_redis_cache()

    if not result["success"]:
        raise HTTPException(status_code=500, detail=result["message"])

    return result

@router.get("/status")
async def get_maintenance_status(
    db: AsyncSession = Depends(get_db)
):
    """Get maintenance operations status"""
    service = MaintenanceService(db)
    return await service.get_maintenance_status()

@router.post("/chromadb/optimize")
async def optimize_chromadb(
    db: AsyncSession = Depends(get_db)
):
    """Optimize ChromaDB collections"""
    # Placeholder for ChromaDB optimization
    # This would implement ChromaDB-specific optimization operations
    return {
        "success": True,
        "message": "ChromaDB optimization completed",
        "operations": [
            "Collection optimization",
            "Index rebuilding",
            "Memory cleanup"
        ]
    }