from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.services.admin_service import AdminService
from typing import Optional, Dict, Any

router = APIRouter()

@router.get("/users")
async def list_users(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    user_level: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List users with pagination and filtering"""
    service = AdminService(db)
    return await service.list_users(page, size, user_level, is_active)

@router.get("/users/{user_id}")
async def get_user(
    user_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get specific user by ID"""
    service = AdminService(db)
    user = await service.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.put("/users/{user_id}")
async def update_user(
    user_id: str,
    user_update: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """Update user information"""
    service = AdminService(db)
    success = await service.update_user(user_id, user_update)
    if not success:
        raise HTTPException(status_code=400, detail="Failed to update user")

    # Log admin action (simplified - in production, get admin_user_id from JWT token)
    await service.log_admin_action(
        admin_user_id="system",  # Should be from JWT token
        action_type="user_update",
        target_resource="user",
        target_id=user_id,
        action_details=user_update
    )

    return {"message": "User updated successfully"}

@router.get("/documents")
async def list_documents(
    page: int = Query(1, ge=1),
    size: int = Query(10, ge=1, le=100),
    document_type: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List documents with pagination and filtering"""
    service = AdminService(db)
    return await service.list_documents(page, size, document_type, is_active)

@router.get("/documents/{document_id}")
async def get_document(
    document_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get specific document by ID"""
    # This would be implemented similar to get_user
    # For now, return placeholder
    return {"message": "Document details endpoint - to be implemented"}

@router.put("/documents/{document_id}")
async def update_document(
    document_id: str,
    document_update: Dict[str, Any],
    db: AsyncSession = Depends(get_db)
):
    """Update document metadata"""
    # This would be implemented similar to update_user
    # For now, return placeholder
    return {"message": "Document update endpoint - to be implemented"}

@router.get("/system/stats")
async def get_system_stats(
    db: AsyncSession = Depends(get_db)
):
    """Get overall system statistics"""
    service = AdminService(db)
    return await service.get_system_stats()