from sqlalchemy import Column, String, Integer, Float, Boolean, Text, DateTime, UUID, ForeignKey, Date, BIGINT, CheckConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
import uuid

Base = declarative_base()

class AdminActions(Base):
    __tablename__ = "admin_actions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    admin_user_id = Column(UUID(as_uuid=True))
    action_type = Column(String(50), nullable=False)
    target_resource = Column(String(100))
    target_id = Column(String(100))
    action_details = Column(JSONB)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

class SystemHealthLog(Base):
    __tablename__ = "system_health_log"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    component_name = Column(String(50), nullable=False)
    status = Column(String(20), CheckConstraint("status IN ('healthy', 'unhealthy', 'degraded')"))
    cpu_usage = Column(Float)
    memory_usage = Column(Float)
    disk_usage = Column(Float)
    response_time_ms = Column(Integer)
    error_message = Column(Text)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())

class BackupStatus(Base):
    __tablename__ = "backup_status"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    backup_type = Column(String(50), nullable=False)
    backup_path = Column(String(500))
    file_size_bytes = Column(BIGINT)
    status = Column(String(20), CheckConstraint("status IN ('started', 'completed', 'failed')"))
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True))
    error_message = Column(Text)

# Reference existing user model
class Users(Base):
    __tablename__ = "users"

    user_id = Column(UUID(as_uuid=True), primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255))
    user_level = Column(String(20))  # user_level enum type
    department = Column(String(100))
    full_name = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

# Reference existing document model
class DocumentsMetadataV2(Base):
    __tablename__ = "documents_metadata_v2"

    document_id = Column(UUID(as_uuid=True), primary_key=True)
    title = Column(String(500), nullable=False)
    file_name = Column(String(255))
    document_type = Column(String(50))
    content_type = Column(String(100))
    file_size_bytes = Column(BIGINT)
    document_hash = Column(String(64))
    upload_source = Column(String(50))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())