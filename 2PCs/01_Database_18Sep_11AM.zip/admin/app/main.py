from fastapi import FastAPI, Depends
from app.api.admin_endpoints import router as admin_router
from app.api.maintenance_endpoints import router as maintenance_router
from app.core.database import get_db, engine
from app.models import admin
import uvicorn

app = FastAPI(
    title="FR-08 Admin & Maintenance Tools",
    description="System Administration for RAG Knowledge Assistant",
    version="1.0.0"
)

@app.on_event("startup")
async def create_tables():
    async with engine.begin() as conn:
        await conn.run_sync(admin.Base.metadata.create_all)

# Include routers
app.include_router(admin_router, prefix="/api/v1/admin", tags=["Administration"])
app.include_router(maintenance_router, prefix="/api/v1/maintenance", tags=["Maintenance"])

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "FR-08 Admin Tools"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8005, reload=False)