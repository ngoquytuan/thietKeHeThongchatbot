from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, desc, update, delete
from app.models.admin import Users, DocumentsMetadataV2, AdminActions
from typing import Optional, Dict, Any, List
from datetime import datetime

class AdminService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list_users(
        self,
        page: int = 1,
        size: int = 10,
        user_level: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> Dict[str, Any]:
        """List users with pagination and filtering"""

        query = select(Users)

        # Apply filters
        if user_level:
            query = query.where(Users.user_level == user_level)
        if is_active is not None:
            query = query.where(Users.is_active == is_active)

        # Get total count
        count_query = select(func.count(Users.user_id))
        if user_level:
            count_query = count_query.where(Users.user_level == user_level)
        if is_active is not None:
            count_query = count_query.where(Users.is_active == is_active)

        count_result = await self.db.execute(count_query)
        total_count = count_result.scalar()

        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size)
        query = query.order_by(desc(Users.created_at))

        result = await self.db.execute(query)
        users = result.scalars().all()

        # Convert to dict format
        users_data = []
        for user in users:
            users_data.append({
                "user_id": str(user.user_id),
                "email": user.email,
                "full_name": user.full_name,
                "user_level": user.user_level,
                "department": user.department,
                "is_active": user.is_active,
                "created_at": user.created_at.isoformat() if user.created_at else None
            })

        return {
            "users": users_data,
            "total_count": total_count,
            "page": page,
            "size": size,
            "total_pages": (total_count + size - 1) // size
        }

    async def get_user(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get specific user details"""

        query = select(Users).where(Users.user_id == user_id)
        result = await self.db.execute(query)
        user = result.scalar_one_or_none()

        if not user:
            return None

        return {
            "user_id": str(user.user_id),
            "email": user.email,
            "full_name": user.full_name,
            "user_level": user.user_level,
            "department": user.department,
            "is_active": user.is_active,
            "created_at": user.created_at.isoformat() if user.created_at else None,
            "updated_at": user.updated_at.isoformat() if user.updated_at else None
        }

    async def update_user(self, user_id: str, user_update: Dict[str, Any]) -> bool:
        """Update user information"""

        try:
            # Filter allowed fields
            allowed_fields = ["user_level", "department", "full_name", "is_active"]
            filtered_update = {k: v for k, v in user_update.items() if k in allowed_fields}

            if not filtered_update:
                return False

            # Add updated_at
            filtered_update["updated_at"] = datetime.now()

            query = (
                update(Users)
                .where(Users.user_id == user_id)
                .values(**filtered_update)
            )

            result = await self.db.execute(query)
            await self.db.commit()

            return result.rowcount > 0

        except Exception as e:
            await self.db.rollback()
            return False

    async def list_documents(
        self,
        page: int = 1,
        size: int = 10,
        document_type: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> Dict[str, Any]:
        """List documents with pagination"""

        query = select(DocumentsMetadataV2)

        # Apply filters
        if document_type:
            query = query.where(DocumentsMetadataV2.document_type == document_type)
        if is_active is not None:
            query = query.where(DocumentsMetadataV2.is_active == is_active)

        # Get total count
        count_query = select(func.count(DocumentsMetadataV2.document_id))
        if document_type:
            count_query = count_query.where(DocumentsMetadataV2.document_type == document_type)
        if is_active is not None:
            count_query = count_query.where(DocumentsMetadataV2.is_active == is_active)

        count_result = await self.db.execute(count_query)
        total_count = count_result.scalar()

        # Apply pagination
        offset = (page - 1) * size
        query = query.offset(offset).limit(size)
        query = query.order_by(desc(DocumentsMetadataV2.created_at))

        result = await self.db.execute(query)
        documents = result.scalars().all()

        # Convert to dict format
        documents_data = []
        for doc in documents:
            documents_data.append({
                "document_id": str(doc.document_id),
                "title": doc.title,
                "file_name": doc.file_name,
                "document_type": doc.document_type,
                "content_type": doc.content_type,
                "file_size_bytes": doc.file_size_bytes,
                "is_active": doc.is_active,
                "created_at": doc.created_at.isoformat() if doc.created_at else None
            })

        return {
            "documents": documents_data,
            "total_count": total_count,
            "page": page,
            "size": size,
            "total_pages": (total_count + size - 1) // size
        }

    async def get_system_stats(self) -> Dict[str, Any]:
        """Get overall system statistics"""

        try:
            # Get user statistics
            user_stats_query = select(
                func.count(Users.user_id).label('total_users'),
                func.count().filter(Users.is_active == True).label('active_users'),
                func.count().filter(Users.user_level == 'System Admin').label('admin_users')
            )

            user_stats_result = await self.db.execute(user_stats_query)
            user_stats = user_stats_result.first()

            # Get document statistics
            doc_stats_query = select(
                func.count(DocumentsMetadataV2.document_id).label('total_documents'),
                func.count().filter(DocumentsMetadataV2.is_active == True).label('active_documents'),
                func.sum(DocumentsMetadataV2.file_size_bytes).label('total_size_bytes')
            )

            doc_stats_result = await self.db.execute(doc_stats_query)
            doc_stats = doc_stats_result.first()

            return {
                "users": {
                    "total": user_stats.total_users or 0,
                    "active": user_stats.active_users or 0,
                    "admins": user_stats.admin_users or 0
                },
                "documents": {
                    "total": doc_stats.total_documents or 0,
                    "active": doc_stats.active_documents or 0,
                    "total_size_mb": round((doc_stats.total_size_bytes or 0) / (1024 * 1024), 2)
                },
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            return {
                "users": {"total": 0, "active": 0, "admins": 0},
                "documents": {"total": 0, "active": 0, "total_size_mb": 0},
                "timestamp": datetime.now().isoformat(),
                "error": str(e)
            }

    async def log_admin_action(
        self,
        admin_user_id: str,
        action_type: str,
        target_resource: str = None,
        target_id: str = None,
        action_details: Dict[str, Any] = None
    ) -> bool:
        """Log admin action"""

        try:
            admin_action = AdminActions(
                admin_user_id=admin_user_id,
                action_type=action_type,
                target_resource=target_resource,
                target_id=target_id,
                action_details=action_details or {}
            )

            self.db.add(admin_action)
            await self.db.commit()
            return True

        except Exception as e:
            await self.db.rollback()
            return False