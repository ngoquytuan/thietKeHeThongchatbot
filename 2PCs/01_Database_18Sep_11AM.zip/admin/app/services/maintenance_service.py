from sqlalchemy.ext.asyncio import AsyncSession
from app.models.admin import BackupStatus, SystemHealthLog
from app.core.database import get_redis, get_chromadb
from typing import Dict, Any
from datetime import datetime
import asyncio
import subprocess
import os

class MaintenanceService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_database_backup(self) -> Dict[str, Any]:
        """Create PostgreSQL database backup"""

        backup_record = BackupStatus(
            backup_type="postgresql",
            status="started"
        )

        try:
            self.db.add(backup_record)
            await self.db.commit()

            # Create backup directory if not exists
            backup_dir = "/app/backups"
            os.makedirs(backup_dir, exist_ok=True)

            # Generate backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"knowledge_base_v2_backup_{timestamp}.sql"
            backup_path = os.path.join(backup_dir, backup_filename)

            # Execute pg_dump command
            cmd = [
                "pg_dump",
                "-h", "fr02-postgres-v2",
                "-U", "kb_admin",
                "-d", "knowledge_base_v2",
                "-f", backup_path,
                "--no-password"
            ]

            # Set environment variable for password
            env = os.environ.copy()
            env["PGPASSWORD"] = "1234567890"

            # Execute backup command
            process = await asyncio.create_subprocess_exec(
                *cmd,
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()

            if process.returncode == 0 and os.path.exists(backup_path):
                # Get file size
                file_size = os.path.getsize(backup_path)

                # Update backup record
                backup_record.status = "completed"
                backup_record.backup_path = backup_path
                backup_record.file_size_bytes = file_size
                backup_record.completed_at = datetime.now()

                await self.db.commit()

                return {
                    "success": True,
                    "backup_path": backup_path,
                    "file_size_bytes": file_size,
                    "message": "Database backup completed successfully"
                }
            else:
                # Backup failed
                error_msg = stderr.decode() if stderr else "Unknown error"
                backup_record.status = "failed"
                backup_record.error_message = error_msg
                backup_record.completed_at = datetime.now()

                await self.db.commit()

                return {
                    "success": False,
                    "error": error_msg,
                    "message": "Database backup failed"
                }

        except Exception as e:
            # Update backup record with error
            backup_record.status = "failed"
            backup_record.error_message = str(e)
            backup_record.completed_at = datetime.now()

            await self.db.rollback()
            self.db.add(backup_record)
            await self.db.commit()

            return {
                "success": False,
                "error": str(e),
                "message": "Database backup failed"
            }

    async def optimize_database(self) -> Dict[str, Any]:
        """Run database optimization (ANALYZE and REINDEX)"""

        try:
            # Run ANALYZE on all tables
            analyze_queries = [
                "ANALYZE users;",
                "ANALYZE documents_metadata_v2;",
                "ANALYZE search_analytics;",
                "ANALYZE system_metrics;",
                "ANALYZE admin_actions;",
                "ANALYZE system_health_log;",
                "ANALYZE backup_status;"
            ]

            results = []
            for query in analyze_queries:
                try:
                    await self.db.execute(query)
                    results.append(f"✅ {query}")
                except Exception as e:
                    results.append(f"❌ {query} - Error: {str(e)}")

            await self.db.commit()

            return {
                "success": True,
                "operations_completed": len([r for r in results if r.startswith("✅")]),
                "operations_failed": len([r for r in results if r.startswith("❌")]),
                "details": results,
                "message": "Database optimization completed"
            }

        except Exception as e:
            await self.db.rollback()
            return {
                "success": False,
                "error": str(e),
                "message": "Database optimization failed"
            }

    async def check_database_health(self) -> Dict[str, Any]:
        """Check database component health"""

        health_status = {
            "database": "unknown",
            "redis": "unknown",
            "chromadb": "unknown"
        }

        # Check PostgreSQL
        try:
            await self.db.execute("SELECT 1")
            health_status["database"] = "healthy"
        except Exception as e:
            health_status["database"] = "unhealthy"

        # Check Redis
        try:
            redis_client = await get_redis()
            await redis_client.ping()
            health_status["redis"] = "healthy"
        except Exception as e:
            health_status["redis"] = "unhealthy"

        # Check ChromaDB
        try:
            chromadb_client = await get_chromadb()
            response = await chromadb_client.get("/api/v1/heartbeat")
            if response.status_code == 200:
                health_status["chromadb"] = "healthy"
            else:
                health_status["chromadb"] = "unhealthy"
        except Exception as e:
            health_status["chromadb"] = "unhealthy"

        # Log health status
        for component, status in health_status.items():
            health_log = SystemHealthLog(
                component_name=component,
                status=status if status in ['healthy', 'unhealthy', 'degraded'] else 'unhealthy'
            )
            self.db.add(health_log)

        try:
            await self.db.commit()
        except:
            await self.db.rollback()

        # Determine overall health
        all_healthy = all(status == "healthy" for status in health_status.values())
        overall_status = "healthy" if all_healthy else "degraded"

        return {
            "overall_status": overall_status,
            "components": health_status,
            "timestamp": datetime.now().isoformat()
        }

    async def clear_redis_cache(self) -> Dict[str, Any]:
        """Clear Redis cache"""

        try:
            redis_client = await get_redis()
            await redis_client.flushdb()

            return {
                "success": True,
                "message": "Redis cache cleared successfully"
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Failed to clear Redis cache"
            }

    async def get_maintenance_status(self) -> Dict[str, Any]:
        """Get recent maintenance operations status"""

        try:
            # Get recent backup status
            from sqlalchemy import select, desc
            backup_query = select(BackupStatus).order_by(desc(BackupStatus.started_at)).limit(5)
            backup_result = await self.db.execute(backup_query)
            backups = backup_result.scalars().all()

            backup_data = []
            for backup in backups:
                backup_data.append({
                    "id": str(backup.id),
                    "backup_type": backup.backup_type,
                    "status": backup.status,
                    "started_at": backup.started_at.isoformat() if backup.started_at else None,
                    "completed_at": backup.completed_at.isoformat() if backup.completed_at else None,
                    "file_size_mb": round((backup.file_size_bytes or 0) / (1024 * 1024), 2)
                })

            # Get recent system health logs
            health_query = select(SystemHealthLog).order_by(desc(SystemHealthLog.timestamp)).limit(10)
            health_result = await self.db.execute(health_query)
            health_logs = health_result.scalars().all()

            health_data = []
            for log in health_logs:
                health_data.append({
                    "component": log.component_name,
                    "status": log.status,
                    "timestamp": log.timestamp.isoformat() if log.timestamp else None,
                    "cpu_usage": log.cpu_usage,
                    "memory_usage": log.memory_usage
                })

            return {
                "recent_backups": backup_data,
                "recent_health_logs": health_data,
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            return {
                "recent_backups": [],
                "recent_health_logs": [],
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }