from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Database Configuration
    DATABASE_URL: str = "postgresql+asyncpg://kb_admin:1234567890@fr02-postgres-v2:5432/knowledge_base_v2"

    # Redis Configuration
    REDIS_URL: str = "redis://fr02-redis-master:6379/4"

    # ChromaDB Configuration
    CHROMADB_URL: str = "http://fr02-chroma-v2:8001"

    # Security
    JWT_SECRET_KEY: str = "integrated-fr02-fr07-fr08-secret-2025"
    JWT_ALGORITHM: str = "HS256"

    # Application
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"

settings = Settings()