#!/bin/bash
# Quick installer for deployment checker

echo "🔧 Installing Python dependencies for deployment checker..."

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 not found. Please install Python 3 first."
    exit 1
fi

# Install requirements
pip3 install -r requirements_check.txt

echo "✅ Dependencies installed!"
echo "🚀 Running deployment check..."

# Run the deployment checker
python3 check_deployment.py