"""
User Database Model
"""

from sqlalchemy import Column, String, DateTime, Enum, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from datetime import datetime
from enum import Enum as PyEnum
import uuid

from ..config.database import Base


class UserLevel(PyEnum):
    """User access levels for RBAC"""
    GUEST = "Guest"
    EMPLOYEE = "Employee"
    MANAGER = "Manager"
    DIRECTOR = "Director"
    SYSTEM_ADMIN = "System Admin"


class User(Base):
    """Model for users table"""
    
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    user_level = Column(Enum(UserLevel), nullable=False, default=UserLevel.GUEST)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Indexes for better query performance
    __table_args__ = (
        Index('idx_users_email_level', 'email', 'user_level'),
        Index('idx_users_created_at', 'created_at'),
    )
    
    def __repr__(self):
        return f"<User(id={self.id}, email={self.email}, level={self.user_level.value})>"
    
    def to_dict(self, include_sensitive=False):
        """Convert to dictionary for JSON serialization"""
        data = {
            "id": str(self.id),
            "email": self.email,
            "user_level": self.user_level.value,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }
        
        if include_sensitive:
            # Only include password_hash for system admin operations
            data["password_hash"] = "***MASKED***"  # Never expose actual hash
            
        return data
    
    def is_system_admin(self) -> bool:
        """Check if user is system admin"""
        return self.user_level == UserLevel.SYSTEM_ADMIN
    
    def can_access_admin(self) -> bool:
        """Check if user can access admin endpoints"""
        return self.user_level == UserLevel.SYSTEM_ADMIN