"""
Database and system maintenance API routes
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, Field
from typing import Dict, Any, List
from datetime import datetime
from loguru import logger

from ..config.database import get_db
from ..models.users import User
from ..services.auth_service import get_current_admin
from ..services.maintenance_service import MaintenanceService

maintenance_router = APIRouter()
maintenance_service = MaintenanceService()

# Pydantic models for responses
class BackupResponse(BaseModel):
    success: bool
    filename: str = None
    size_bytes: int = None
    timestamp: str = None
    path: str = None
    error: str = None

class OptimizationResponse(BaseModel):
    success: bool
    results: List[Dict[str, Any]]
    timestamp: str
    error: str = None

class CleanupResponse(BaseModel):
    success: bool
    deleted_records: int = None
    cutoff_date: str = None
    message: str = None
    error: str = None

class HealthCheckResponse(BaseModel):
    overall_status: str
    components: List[Dict[str, Any]]
    timestamp: str
    healthy_components: int
    total_components: int


@maintenance_router.post("/backup", response_model=BackupResponse)
async def create_database_backup(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Create a backup of the PostgreSQL database"""
    try:
        logger.info(f"Admin {current_admin.email} initiated database backup")
        
        result = await maintenance_service.create_database_backup(db)
        
        if result["success"]:
            logger.info(f"Database backup completed successfully: {result.get('filename')}")
        else:
            logger.error(f"Database backup failed: {result.get('error')}")
        
        return BackupResponse(**result)
        
    except Exception as e:
        logger.error(f"Error creating database backup: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create database backup"
        )


@maintenance_router.post("/optimize", response_model=OptimizationResponse)
async def optimize_database(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Optimize PostgreSQL database with ANALYZE and REINDEX operations"""
    try:
        logger.info(f"Admin {current_admin.email} initiated database optimization")
        
        result = await maintenance_service.optimize_database(db)
        
        if result["success"]:
            successful_tables = len([r for r in result["results"] if r.get("analyze") == "success"])
            logger.info(f"Database optimization completed: {successful_tables} tables optimized")
        else:
            logger.error(f"Database optimization failed: {result.get('error')}")
        
        return OptimizationResponse(**result)
        
    except Exception as e:
        logger.error(f"Error optimizing database: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to optimize database"
        )


@maintenance_router.post("/cleanup/metrics", response_model=CleanupResponse)
async def cleanup_old_metrics(
    days: int = Query(30, ge=1, le=365, description="Days of metrics to retain"),
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Clean up old system metrics data older than specified days"""
    try:
        logger.info(f"Admin {current_admin.email} initiated metrics cleanup (>{days} days)")
        
        result = await maintenance_service.cleanup_old_metrics(db, days)
        
        if result["success"]:
            logger.info(f"Metrics cleanup completed: {result.get('deleted_records', 0)} records deleted")
        else:
            logger.error(f"Metrics cleanup failed: {result.get('error')}")
        
        return CleanupResponse(**result)
        
    except Exception as e:
        logger.error(f"Error cleaning up old metrics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to clean up old metrics"
        )


@maintenance_router.post("/cache/clear")
async def clear_redis_cache(
    current_admin: User = Depends(get_current_admin)
):
    """Clear Redis cache"""
    try:
        logger.info(f"Admin {current_admin.email} initiated Redis cache clear")
        
        result = await maintenance_service.clear_redis_cache()
        
        if result["success"]:
            freed_mb = result.get("memory_freed_bytes", 0) / 1024 / 1024
            logger.info(f"Redis cache cleared successfully: {freed_mb:.2f}MB freed")
        else:
            logger.error(f"Redis cache clear failed: {result.get('error')}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error clearing Redis cache: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to clear Redis cache"
        )


@maintenance_router.post("/chromadb/optimize")
async def optimize_chromadb(
    current_admin: User = Depends(get_current_admin)
):
    """Optimize ChromaDB collections"""
    try:
        logger.info(f"Admin {current_admin.email} initiated ChromaDB optimization")
        
        result = await maintenance_service.optimize_chromadb()
        
        if result["success"]:
            logger.info(f"ChromaDB optimization completed: {result.get('collections_processed', 0)} collections processed")
        else:
            logger.error(f"ChromaDB optimization failed: {result.get('error')}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error optimizing ChromaDB: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to optimize ChromaDB"
        )


@maintenance_router.get("/health", response_model=HealthCheckResponse)
async def check_database_health(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Check health of all database components"""
    try:
        logger.info(f"Admin {current_admin.email} requested database health check")
        
        result = await maintenance_service.check_database_health(db)
        
        logger.info(f"Database health check completed: {result['overall_status']}")
        
        return HealthCheckResponse(**result)
        
    except Exception as e:
        logger.error(f"Error checking database health: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to check database health"
        )


@maintenance_router.post("/restart/container")
async def restart_container(
    container_name: str = Query(..., description="Name of the container to restart"),
    current_admin: User = Depends(get_current_admin)
):
    """Restart a specific Docker container (placeholder implementation)"""
    try:
        logger.info(f"Admin {current_admin.email} requested restart of container: {container_name}")
        
        # This is a placeholder implementation
        # In a real system, you would integrate with Docker API
        # For security reasons, this should be carefully implemented
        
        # Simulate container restart
        import asyncio
        await asyncio.sleep(1)  # Simulate restart time
        
        logger.warning(f"Container restart requested but not implemented: {container_name}")
        
        return {
            "message": f"Container restart requested: {container_name}",
            "status": "not_implemented",
            "note": "Container restart functionality requires proper Docker integration and security measures",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error restarting container {container_name}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to restart container"
        )


@maintenance_router.get("/status")
async def get_maintenance_status(
    current_admin: User = Depends(get_current_admin)
):
    """Get current maintenance operations status and system info"""
    try:
        logger.info(f"Admin {current_admin.email} requested maintenance status")
        
        # Get system info
        import psutil
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        uptime = datetime.utcnow() - boot_time
        
        status_info = {
            "system_uptime": {
                "boot_time": boot_time.isoformat(),
                "uptime_seconds": int(uptime.total_seconds()),
                "uptime_formatted": str(uptime).split('.')[0]  # Remove microseconds
            },
            "maintenance_info": {
                "backup_directory": str(maintenance_service.backup_dir),
                "max_backup_count": maintenance_service.backup_dir.parent.joinpath("settings").exists(),  # Placeholder
                "last_optimization": "unknown",  # Would track in real implementation
                "next_scheduled_backup": "not_scheduled"  # Would implement scheduling
            },
            "database_connections": {
                "postgresql": "connected",  # Would check actual status
                "redis": "connected",
                "chromadb": "connected"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return status_info
        
    except Exception as e:
        logger.error(f"Error getting maintenance status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get maintenance status"
        )