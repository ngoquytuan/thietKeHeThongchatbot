"""
System monitoring API routes
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from loguru import logger

from ..config.database import get_db
from ..models.users import User
from ..services.auth_service import get_current_admin
from ..services.monitoring_service import MonitoringService

monitoring_router = APIRouter()
monitoring_service = MonitoringService()

# Pydantic models for responses
class SystemMetricsResponse(BaseModel):
    system: Dict[str, Any]
    containers: List[Dict[str, Any]]
    timestamp: str

class AlertResponse(BaseModel):
    type: str
    message: str
    threshold: Optional[float] = None
    current: Optional[float] = None
    severity: str
    container: Optional[str] = None

class HistoricalMetricsResponse(BaseModel):
    metrics: List[Dict[str, Any]]
    total_records: int
    time_range_hours: int


@monitoring_router.get("/system", response_model=SystemMetricsResponse)
async def get_system_metrics(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get current system metrics including CPU, memory, disk, and network usage"""
    try:
        metrics = await monitoring_service.collect_system_metrics(db)
        
        logger.info(f"Admin {current_admin.email} requested system metrics")
        
        return SystemMetricsResponse(
            system=metrics["system"],
            containers=metrics["containers"],
            timestamp=metrics["timestamp"]
        )
        
    except Exception as e:
        logger.error(f"Error getting system metrics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve system metrics"
        )


@monitoring_router.get("/system/historical", response_model=HistoricalMetricsResponse)
async def get_historical_metrics(
    hours: int = Query(24, ge=1, le=168),  # Max 1 week
    container_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get historical system metrics for the specified time range"""
    try:
        metrics = await monitoring_service.get_historical_metrics(
            db, hours=hours, container_id=container_id
        )
        
        logger.info(f"Admin {current_admin.email} requested {hours}h historical metrics")
        
        return HistoricalMetricsResponse(
            metrics=metrics,
            total_records=len(metrics),
            time_range_hours=hours
        )
        
    except Exception as e:
        logger.error(f"Error getting historical metrics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve historical metrics"
        )


@monitoring_router.get("/system/alerts", response_model=List[AlertResponse])
async def get_current_alerts(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get current system alerts based on threshold violations"""
    try:
        # Get current metrics first
        metrics = await monitoring_service.collect_system_metrics(db)
        
        # Check thresholds
        alerts = await monitoring_service.check_thresholds(metrics)
        
        logger.info(f"Admin {current_admin.email} requested current alerts: {len(alerts)} found")
        
        # Convert to response format
        alert_responses = []
        for alert in alerts:
            alert_responses.append(AlertResponse(
                type=alert["type"],
                message=alert["message"],
                threshold=alert.get("threshold"),
                current=alert.get("current"),
                severity=alert["severity"],
                container=alert.get("container")
            ))
        
        return alert_responses
        
    except Exception as e:
        logger.error(f"Error getting current alerts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve current alerts"
        )


@monitoring_router.get("/system/health")
async def get_system_health(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get overall system health status"""
    try:
        # Get current metrics
        metrics = await monitoring_service.collect_system_metrics(db)
        
        # Get alerts
        alerts = await monitoring_service.check_thresholds(metrics)
        
        # Calculate health status
        critical_alerts = [a for a in alerts if a["severity"] == "critical"]
        warning_alerts = [a for a in alerts if a["severity"] == "warning"]
        
        if critical_alerts:
            overall_status = "critical"
        elif warning_alerts:
            overall_status = "warning"
        else:
            overall_status = "healthy"
        
        health_summary = {
            "overall_status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "system_metrics": {
                "cpu_usage_percent": metrics["system"]["cpu_usage_percent"],
                "memory_percent": metrics["system"]["memory_percent"],
                "disk_usage_gb": {
                    "read": round(metrics["system"]["disk_read_mb"] / 1024, 2),
                    "write": round(metrics["system"]["disk_write_mb"] / 1024, 2)
                },
                "network_usage_gb": {
                    "sent": round(metrics["system"]["network_sent_mb"] / 1024, 2),
                    "received": round(metrics["system"]["network_recv_mb"] / 1024, 2)
                }
            },
            "containers": {
                "total": len(metrics["containers"]),
                "running": len([c for c in metrics["containers"] if c["status"] == "running"]),
                "high_cpu": len([c for c in metrics["containers"] if c["cpu_usage_percent"] > 80]),
                "high_memory": len([c for c in metrics["containers"] if c["memory_percent"] > 90])
            },
            "alerts": {
                "total": len(alerts),
                "critical": len(critical_alerts),
                "warning": len(warning_alerts)
            }
        }
        
        logger.info(f"Admin {current_admin.email} requested system health: {overall_status}")
        
        return health_summary
        
    except Exception as e:
        logger.error(f"Error getting system health: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve system health"
        )


@monitoring_router.get("/containers")
async def get_container_details(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Get detailed information about all Docker containers"""
    try:
        metrics = await monitoring_service.collect_system_metrics(db)
        containers = metrics["containers"]
        
        # Enhance container info
        enhanced_containers = []
        for container in containers:
            enhanced_info = {
                **container,
                "health_status": "healthy",
                "uptime": "unknown",  # Would need additional Docker API calls
                "restart_count": "unknown"
            }
            
            # Determine health status based on metrics
            if container["cpu_usage_percent"] > 90:
                enhanced_info["health_status"] = "critical"
            elif container["cpu_usage_percent"] > 80 or container["memory_percent"] > 90:
                enhanced_info["health_status"] = "warning"
            
            enhanced_containers.append(enhanced_info)
        
        logger.info(f"Admin {current_admin.email} requested container details for {len(containers)} containers")
        
        return {
            "containers": enhanced_containers,
            "total_containers": len(containers),
            "timestamp": metrics["timestamp"]
        }
        
    except Exception as e:
        logger.error(f"Error getting container details: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve container details"
        )


@monitoring_router.post("/system/collect")
async def trigger_metrics_collection(
    db: AsyncSession = Depends(get_db),
    current_admin: User = Depends(get_current_admin)
):
    """Manually trigger system metrics collection"""
    try:
        metrics = await monitoring_service.collect_system_metrics(db)
        
        logger.info(f"Admin {current_admin.email} triggered manual metrics collection")
        
        return {
            "message": "Metrics collection completed",
            "timestamp": metrics["timestamp"],
            "containers_monitored": len(metrics["containers"])
        }
        
    except Exception as e:
        logger.error(f"Error triggering metrics collection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to trigger metrics collection"
        )