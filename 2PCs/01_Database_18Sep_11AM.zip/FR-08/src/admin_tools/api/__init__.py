"""
API routes for FR-08 Admin & Maintenance Tools
"""