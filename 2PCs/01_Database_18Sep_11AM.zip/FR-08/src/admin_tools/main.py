"""
FR-08 Admin & Maintenance Tools - Main FastAPI Application

This module provides comprehensive administrative and maintenance capabilities
for System Administrators to monitor, maintain, and manage the RAG Knowledge Assistant system.
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from contextlib import asynccontextmanager
import os
import logging
from loguru import logger
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

from admin_tools.config.settings import Settings
from admin_tools.config.database import init_db
from admin_tools.api.admin_routes import admin_router
from admin_tools.api.monitoring_routes import monitoring_router
from admin_tools.api.maintenance_routes import maintenance_router

settings = Settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info("Starting FR-08 Admin & Maintenance Tools")
    await init_db()
    yield
    logger.info("Shutting down FR-08 Admin & Maintenance Tools")

app = FastAPI(
    title="FR-08 Admin & Maintenance Tools",
    description="Administrative and maintenance tools for RAG Knowledge Assistant System",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.ENVIRONMENT == "development" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT == "development" else None
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="token",
    description="JWT token for System Admin authentication"
)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "FR-08 Admin Tools"}

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

app.include_router(admin_router, prefix="/api/admin", tags=["Admin"])
app.include_router(monitoring_router, prefix="/api/admin", tags=["Monitoring"])  
app.include_router(maintenance_router, prefix="/api/admin", tags=["Maintenance"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8002,
        reload=settings.ENVIRONMENT == "development",
        log_level="info"
    )