"""
Database configuration and connection management for FR-08
"""

from sqlalchemy import create_engine, text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import NullPool
import asyncpg
import asyncio
from loguru import logger
from typing import AsyncGenerator
import redis.asyncio as redis
import httpx

from .settings import Settings

settings = Settings()

# SQLAlchemy setup
Base = declarative_base()

# PostgreSQL async engine
async_engine = create_async_engine(
    settings.DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://"),
    poolclass=NullPool,
    echo=settings.ENVIRONMENT == "development"
)

AsyncSessionLocal = sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False
)

# Redis connection
redis_client = None

# ChromaDB client
chromadb_client = None

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Get database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

async def get_redis() -> redis.Redis:
    """Get Redis connection"""
    global redis_client
    if redis_client is None:
        redis_client = redis.from_url(settings.REDIS_URL)
    return redis_client

async def get_chromadb_client():
    """Get ChromaDB client"""
    global chromadb_client
    if chromadb_client is None:
        chromadb_client = httpx.AsyncClient(base_url=settings.CHROMADB_URL)
    return chromadb_client

async def init_db():
    """Initialize database and create tables"""
    try:
        # Test PostgreSQL connection
        async with AsyncSessionLocal() as session:
            result = await session.execute(text("SELECT 1"))
            logger.info("PostgreSQL connection successful")
            
        # Test Redis connection
        redis_conn = await get_redis()
        await redis_conn.ping()
        logger.info("Redis connection successful")
        
        # Test ChromaDB connection
        chromadb_conn = await get_chromadb_client()
        response = await chromadb_conn.get("/api/v1/heartbeat")
        if response.status_code == 200:
            logger.info("ChromaDB connection successful")
        
        # Create system_metrics table if not exists
        async with AsyncSessionLocal() as session:
            await session.execute(text("""
                CREATE TABLE IF NOT EXISTS system_metrics (
                    id SERIAL PRIMARY KEY,
                    container_id VARCHAR(64),
                    response_time_ms INTEGER,
                    cpu_usage_percent FLOAT,
                    memory_usage_mb FLOAT,
                    disk_io FLOAT,
                    network_throughput FLOAT,
                    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
                );
            """))
            
            await session.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp 
                ON system_metrics(timestamp);
            """))
            
            await session.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_system_metrics_container 
                ON system_metrics(container_id, timestamp);
            """))
            
            await session.commit()
            logger.info("System metrics table created/verified")
            
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise

async def close_db():
    """Close database connections"""
    global redis_client, chromadb_client
    
    if redis_client:
        await redis_client.close()
        redis_client = None
        
    if chromadb_client:
        await chromadb_client.aclose()
        chromadb_client = None
        
    await async_engine.dispose()
    logger.info("Database connections closed")