"""
Configuration settings for FR-08 Admin & Maintenance Tools
"""

from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # Application settings
    APP_NAME: str = "FR-08 Admin & Maintenance Tools"
    VERSION: str = "1.0.0"
    ENVIRONMENT: str = "production"
    
    # Database settings
    DATABASE_URL: str = "postgresql://user:pass@postgres:5432/rag_db"
    CHROMADB_HOST: str = "chromadb:8000"
    CHROMADB_URL: str = "http://chromadb:8000"
    
    # Redis settings
    REDIS_URL: str = "redis://redis:6379"
    
    # JWT settings
    JWT_SECRET_KEY: str = "your-secret-key-here"
    JWT_ALGORITHM: str = "RS256"
    JWT_EXPIRE_HOURS: int = 24
    
    # CORS settings
    ALLOWED_ORIGINS: List[str] = ["*"]
    
    # Monitoring settings
    PROMETHEUS_MULTIPROC_DIR: str = "/tmp"
    GRAFANA_URL: str = "http://grafana:3000"
    
    # Alerting thresholds
    CPU_THRESHOLD: float = 80.0
    MEMORY_THRESHOLD: float = 90.0
    RESPONSE_TIME_THRESHOLD: float = 2000.0  # milliseconds
    
    # Logging settings
    LOG_LEVEL: str = "INFO"
    
    # Backup settings
    BACKUP_DIR: str = "/app/backups"
    MAX_BACKUP_COUNT: int = 7
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True