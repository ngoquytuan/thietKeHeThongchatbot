-- FR-08 Database Initialization Script
-- Creates tables and indexes for Admin & Maintenance Tools

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    user_level VARCHAR(20) NOT NULL DEFAULT 'Guest' 
        CHECK (user_level IN ('Guest', 'Employee', 'Manager', 'Director', 'System Admin')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_email_level ON users(email, user_level);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Create documents_metadata_v2 table
CREATE TABLE IF NOT EXISTS documents_metadata_v2 (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create indexes for documents table
CREATE INDEX IF NOT EXISTS idx_documents_category ON documents_metadata_v2(category);
CREATE INDEX IF NOT EXISTS idx_documents_category_active ON documents_metadata_v2(category, is_active);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents_metadata_v2(created_at);
CREATE INDEX IF NOT EXISTS idx_documents_active ON documents_metadata_v2(is_active);
CREATE INDEX IF NOT EXISTS idx_documents_title_search ON documents_metadata_v2 USING gin(title gin_trgm_ops);

-- Create system_metrics table
CREATE TABLE IF NOT EXISTS system_metrics (
    id SERIAL PRIMARY KEY,
    container_id VARCHAR(64),
    response_time_ms INTEGER,
    cpu_usage_percent FLOAT,
    memory_usage_mb FLOAT,
    disk_io FLOAT,
    network_throughput FLOAT,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for system_metrics table
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_system_metrics_container ON system_metrics(container_id);
CREATE INDEX IF NOT EXISTS idx_system_metrics_container_timestamp ON system_metrics(container_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp_desc ON system_metrics(timestamp DESC);

-- Create search_analytics table (placeholder)
CREATE TABLE IF NOT EXISTS search_analytics (
    id SERIAL PRIMARY KEY,
    user_id UUID,
    query_text TEXT,
    results_count INTEGER,
    response_time_ms INTEGER,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Create indexes for search_analytics table
CREATE INDEX IF NOT EXISTS idx_search_analytics_timestamp ON search_analytics(timestamp);
CREATE INDEX IF NOT EXISTS idx_search_analytics_user_id ON search_analytics(user_id);

-- Insert default system admin user (password: admin123)
-- In production, this should be changed immediately
INSERT INTO users (email, password_hash, user_level) 
VALUES ('admin@system.local', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewi5Y2Q6.Ey1fH5O', 'System Admin')
ON CONFLICT (email) DO NOTHING;

-- Insert sample documents for testing
INSERT INTO documents_metadata_v2 (title, category, is_active) VALUES
    ('System Administration Guide', 'Documentation', TRUE),
    ('API Reference Manual', 'Documentation', TRUE),
    ('Security Best Practices', 'Security', TRUE),
    ('Database Schema Documentation', 'Technical', TRUE),
    ('User Manual v1.0', 'Documentation', FALSE)
ON CONFLICT DO NOTHING;

-- Insert sample system metrics for testing
INSERT INTO system_metrics (container_id, cpu_usage_percent, memory_usage_mb, disk_io, network_throughput) VALUES
    ('system', 45.2, 2048.5, 150.3, 89.7),
    ('admin_tools', 15.8, 512.2, 25.1, 12.4),
    ('postgres', 8.3, 256.8, 78.9, 45.2),
    ('redis', 3.1, 64.5, 12.3, 8.9),
    ('chromadb', 22.7, 1024.3, 95.6, 23.1)
ON CONFLICT DO NOTHING;

-- Create function to clean old metrics automatically
CREATE OR REPLACE FUNCTION cleanup_old_system_metrics()
RETURNS void AS $$
BEGIN
    DELETE FROM system_metrics 
    WHERE timestamp < CURRENT_TIMESTAMP - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- Create function to get system health summary
CREATE OR REPLACE FUNCTION get_system_health_summary()
RETURNS TABLE(
    total_users INTEGER,
    active_documents INTEGER,
    recent_metrics_count INTEGER,
    avg_cpu_usage FLOAT,
    avg_memory_usage FLOAT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*)::INTEGER FROM users) as total_users,
        (SELECT COUNT(*)::INTEGER FROM documents_metadata_v2 WHERE is_active = TRUE) as active_documents,
        (SELECT COUNT(*)::INTEGER FROM system_metrics WHERE timestamp > CURRENT_TIMESTAMP - INTERVAL '1 hour') as recent_metrics_count,
        (SELECT AVG(cpu_usage_percent) FROM system_metrics WHERE timestamp > CURRENT_TIMESTAMP - INTERVAL '1 hour') as avg_cpu_usage,
        (SELECT AVG(memory_usage_mb) FROM system_metrics WHERE timestamp > CURRENT_TIMESTAMP - INTERVAL '1 hour') as avg_memory_usage;
END;
$$ LANGUAGE plpgsql;

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO rag_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO rag_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO rag_user;