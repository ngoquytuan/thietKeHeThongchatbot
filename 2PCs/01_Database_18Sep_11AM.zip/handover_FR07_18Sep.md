# FR-07 Analytics & Reporting - Handover Documentation

## Project Overview

**Project Name**: FR-07 Analytics & Reporting Module
**Status**: Complete - Production Ready
**Date**: September 18, 2025
**Integration**: Integrated with FR-02 database and services
**Tech Stack**: FastAPI, Streamlit, SQLAlchemy, PostgreSQL, Redis, Docker, Prometheus

## 📋 Current Implementation Status

### ✅ Completed Steps
- **Step 1**: ✅ Created analytics API with comprehensive metrics collection
- **Step 2**: ✅ Implemented Streamlit dashboard with real-time data visualization
- **Step 3**: ✅ Fixed Docker networking and service connectivity issues
- **Step 4**: ✅ Resolved authentication token handling and API connections
- **Step 5**: ✅ Fixed Streamlit permissions and container configuration
- **Step 6**: ✅ Implemented data aggregation and time-series analytics
- **Step 7**: ✅ Added system health monitoring and alerting
- **Step 8**: ✅ Complete testing and validation

### 🎯 Next Steps
- **Enhancement**: Add more advanced analytics (ML-based insights)
- **Export**: Add data export functionality (PDF reports, CSV)
- **Alerting**: Implement email/Slack notifications for critical alerts
- **Performance**: Add analytics data archiving and optimization

## 🏗️ Project Structure

```
FR-07/
├── analytics_module/                 # Main analytics module
│   ├── app/                          # FastAPI analytics API
│   │   ├── api/                      # API layer
│   │   │   └── endpoints/            # API endpoints
│   │   │       └── analytics.py      # Analytics data endpoints
│   │   ├── core/                     # Core functionality
│   │   │   ├── config.py             # Configuration settings
│   │   │   └── database.py           # Database connections
│   │   ├── models/                   # Database models
│   │   │   └── analytics.py          # Analytics data models
│   │   └── main.py                   # FastAPI application entry
│   ├── dashboard/                    # Streamlit dashboard
│   │   └── main.py                   # Dashboard application
│   ├── docker/                       # Docker deployment
│   │   ├── Dockerfile.api            # API container build
│   │   ├── Dockerfile.dashboard      # Dashboard container build
│   │   └── docker-compose.yml        # Service orchestration
│   ├── scripts/                      # Utility scripts
│   │   └── sample_data.py            # Sample data generation
│   └── requirements.txt              # Python dependencies
└── handover_FR07_18Sep.md           # This handover document
```

## 🔧 Environment Setup

### Prerequisites
- **Python**: 3.11+ (Streamlit and FastAPI compatibility)
- **PostgreSQL**: 12+ (Analytics data storage)
- **Redis**: 6+ (Caching and real-time data)
- **Docker**: 20+ (Containerized deployment)

### 1. Database Setup (Uses Existing FR-02 Database)

#### Connection to Existing Database
```bash
# Uses existing FR-02 database configuration
Host: fr02-postgres-v2
Port: 5432
Database: knowledge_base_v2
User: kb_admin
Password: 1234567890
```

### 2. Redis Setup (Uses Existing FR-02 Redis)

```bash
# Uses existing Redis infrastructure
Master: fr02-redis-master:6379
Replica: fr02-redis-replica:6380
```

### 3. Application Environment Setup

```bash
# Navigate to analytics module
cd FR-07/analytics_module

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 4. Environment Configuration

FR-07 uses environment variables in docker-compose configuration:

```env
# Database Configuration
DATABASE_URL=postgresql://kb_admin:1234567890@fr02-postgres-v2:5432/knowledge_base_v2

# Redis Configuration
REDIS_URL=redis://fr02-redis-master:6379/0

# API Configuration
API_HOST=0.0.0.0
API_PORT=8003
API_RELOAD=false
API_WORKERS=1

# Logging
LOG_LEVEL=INFO
```

## 🚀 Running the Application

### Docker Deployment (Recommended)
```bash
# Navigate to main docker directory
cd D:\Projects\checkbot\docker\PC1\Database

# Build and start FR-07 services
docker-compose up -d fr07-analytics-api fr07-analytics-dashboard

# Services will be available at:
# - Analytics API: http://localhost:8003
# - Dashboard: http://localhost:8501
# - API Documentation: http://localhost:8003/docs
```

### Development Mode
```bash
# Start API server
cd FR-07/analytics_module
python -m uvicorn app.main:app --host 0.0.0.0 --port 8003 --reload

# Start dashboard (in separate terminal)
cd FR-07/analytics_module/dashboard
streamlit run main.py --server.port 8501 --server.address 0.0.0.0
```

### Individual Service Testing
```bash
# Test API health
curl http://localhost:8003/health

# Test dashboard access
curl http://localhost:8501
```

## 📁 Key Files Description

### Analytics API Files

#### `app/main.py`
- **Purpose**: FastAPI application with analytics endpoints and monitoring
- **Features**: Prometheus metrics, request timing, CORS middleware
- **Key Functions**: Health checks, error handling, startup/shutdown events

#### `app/core/config.py`
- **Purpose**: Centralized configuration management
- **Features**: Database URLs, API settings, logging configuration
- **Key Settings**: Host/port configuration, database connections

#### `app/core/database.py`
- **Purpose**: Database connection management with SQLAlchemy
- **Features**: Async database connections, session management
- **Integrations**: PostgreSQL connection pooling

### Analytics Data System

#### `app/models/analytics.py`
- **Purpose**: Database models for analytics data storage
- **Features**: User events, search queries, document access tracking
- **Models**: UserEvent, SearchQuery, DocumentAccess, SystemMetrics

#### `app/api/endpoints/analytics.py`
- **Purpose**: Analytics data API endpoints
- **Features**: Data aggregation, time-series queries, filtering
- **Operations**: Search analytics, user analytics, document analytics, system metrics

### Dashboard System

#### `dashboard/main.py`
- **Purpose**: Streamlit web dashboard for analytics visualization
- **Features**: Real-time charts, interactive filters, data tables
- **Components**: Metric cards, time-series charts, pie charts, system health gauges

### Docker Configuration

#### `docker/Dockerfile.api`
- **Purpose**: Analytics API container build instructions
- **Features**: Python 3.11, FastAPI dependencies, health checks
- **Security**: Non-root user, minimal attack surface

#### `docker/Dockerfile.dashboard`
- **Purpose**: Streamlit dashboard container build
- **Features**: Streamlit configuration, proper permissions, health checks
- **Security**: Non-root user, disabled telemetry

## 🧪 Testing Steps

### Step 1: API Functionality Testing
**Status**: ✅ Completed

#### Health Check Testing
```bash
# Test API health
curl http://localhost:8003/health

# Expected result: {"status":"healthy","service":"analytics","version":"1.0.0","timestamp":1726649808}
```

#### Analytics Endpoints Testing
```bash
# Test search analytics
curl "http://localhost:8003/api/analytics/search?start_date=2025-09-01&end_date=2025-09-18&limit=100"

# Expected result: JSON with search metrics, top queries, response times
```

### Step 2: Dashboard Testing
**Status**: ✅ Completed

#### Dashboard Access Testing
```bash
# Test dashboard availability
curl -I http://localhost:8501

# Expected result: HTTP/1.1 200 OK with Streamlit headers
```

#### Dashboard Functionality
```bash
# Access dashboard in browser
# URL: http://localhost:8501
# Expected: Interactive dashboard with charts, filters, and real-time data
```

### Step 3: Data Integration Testing
**Status**: ✅ Completed

#### User Analytics
```bash
# Test user analytics endpoint
curl "http://localhost:8003/api/analytics/users?start_date=2025-09-01&end_date=2025-09-18"

# Expected result: User activity metrics, distribution by level, active users
```

#### Document Analytics
```bash
# Test document analytics
curl "http://localhost:8003/api/analytics/documents?start_date=2025-09-01&end_date=2025-09-18"

# Expected result: Document access metrics, popular documents, access patterns
```

### Step 4: System Monitoring Testing
**Status**: ✅ Completed

#### System Metrics
```bash
# Test system metrics endpoint
curl http://localhost:8003/api/analytics/system

# Expected result: CPU, memory, response time metrics
```

#### Health Monitoring
```bash
# Test overall system health
curl http://localhost:8003/api/analytics/health

# Expected result: Comprehensive health status of all components
```

## 🔍 API Documentation

### Interactive Documentation
- **Swagger UI**: http://localhost:8003/docs
- **ReDoc**: http://localhost:8003/redoc

### Analytics Endpoints
```
GET    /api/analytics/search              # Search query analytics
GET    /api/analytics/users               # User activity analytics
GET    /api/analytics/documents           # Document access analytics
GET    /api/analytics/system              # System performance metrics
GET    /health                            # Service health check
GET    /metrics                           # Prometheus metrics
GET    /                                  # Service information
```

### Query Parameters
```
# Time Range Filtering
start_date: ISO datetime string (required)
end_date: ISO datetime string (required)
limit: Integer (default: 100, max: 1000)

# User Filtering
user_level: String (Guest, Employee, Manager, Director, System Admin)

# Document Filtering
category: String (document category filter)
is_active: Boolean (active/inactive document filter)

# System Metrics
hours: Integer (historical data range, default: 24)
container_id: String (specific container metrics)
```

## 🗃️ Database Schema

### Analytics Tables (FR-02 Compatible)
```sql
-- User Events (tracks user activities)
user_events (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(user_id),
  event_type VARCHAR(50) NOT NULL,
  event_data JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  session_id VARCHAR(255),
  ip_address INET,
  user_agent TEXT
)

-- Search Queries (tracks search activities)
search_queries (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(user_id),
  query_text TEXT NOT NULL,
  result_count INTEGER,
  processing_time_ms INTEGER,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  filters_applied JSONB,
  user_level VARCHAR(20)
)

-- Document Access (tracks document usage)
document_access (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(user_id),
  document_id UUID REFERENCES documents_metadata_v2(id),
  access_type VARCHAR(20) NOT NULL,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  user_level VARCHAR(20),
  session_duration INTEGER
)
```

### System Metrics Tables
```sql
-- System Metrics (performance monitoring)
system_metrics (
  id SERIAL PRIMARY KEY,
  container_id VARCHAR(64),
  response_time_ms INTEGER,
  cpu_usage_percent REAL,
  memory_usage_mb REAL,
  disk_io REAL,
  network_throughput REAL,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
)
```

## 🔧 Common Issues & Solutions

### Issue 1: Analytics API Not Available
```bash
# Check API container status
docker ps | grep fr07-analytics-api

# Check API logs
docker logs fr07-analytics-api

# Restart API service
docker-compose restart fr07-analytics-api
```

### Issue 2: Dashboard Connection Error
```bash
# Dashboard shows "Analytics API is not available"
# Check API health from dashboard container
docker exec fr07-analytics-dashboard curl http://fr07-analytics-api:8003/health

# Verify Docker network connectivity
docker network inspect database_fr02_network
```

### Issue 3: Streamlit Permission Errors
```bash
# Check Streamlit logs
docker logs fr07-analytics-dashboard

# Verify user permissions in container
docker exec fr07-analytics-dashboard ls -la /home/dashboard/.streamlit

# Rebuild container if needed
docker-compose build fr07-analytics-dashboard
```

### Issue 4: Database Connection Issues
```bash
# Test database connectivity
docker exec fr07-analytics-api python -c "
import asyncpg
import asyncio
async def test():
    conn = await asyncpg.connect('postgresql://kb_admin:1234567890@fr02-postgres-v2:5432/knowledge_base_v2')
    print('Connected successfully')
    await conn.close()
asyncio.run(test())
"
```

## 🚨 Known Issues & Resolutions

### Issue 5: Middleware Async/Await Error
**Problem**: Missing `await` in middleware causing 500 errors
**Root Cause**: FastAPI middleware requires proper async handling
**Solution**:
```python
# Fixed in app/main.py line 85
response = await call_next(request)  # Added await keyword
```

### Issue 6: Docker Service Discovery
**Problem**: Dashboard using localhost instead of Docker service names
**Root Cause**: API_BASE_URL pointing to localhost in containerized environment
**Solution**:
```python
# Fixed in dashboard/main.py line 20
API_BASE_URL = "http://fr07-analytics-api:8003"  # Use Docker service name
```

### Issue 7: Streamlit Configuration Issues
**Problem**: Streamlit unable to create configuration directories
**Root Cause**: Incorrect home directory and permissions setup
**Solution**:
```dockerfile
# Fixed in Dockerfile.dashboard
ENV HOME=/home/dashboard
RUN mkdir -p /home/dashboard/.streamlit && \
    chown -R dashboard:dashboard /home/dashboard/.streamlit
```

### Issue 8: Auto-refresh Compatibility
**Problem**: st.experimental_rerun() deprecated in newer Streamlit versions
**Root Cause**: Streamlit API changes
**Solution**:
```python
# dashboard/main.py line 197
st.experimental_rerun()  # Works with current Streamlit version
# Future: Use st.rerun() for Streamlit 1.27+
```

## 🔍 Troubleshooting FR-07 System

### FR-07 Health Check
```bash
# Check both services
curl http://localhost:8003/health  # API
curl http://localhost:8501         # Dashboard

# Expected API: {"status":"healthy","service":"analytics",...}
# Expected Dashboard: HTTP 200 with Streamlit content
```

### Database Connection Verification
```bash
# Connect to analytics database
docker exec -it fr02-postgres-v2 psql -U kb_admin -d knowledge_base_v2

# Check analytics tables
\dt *event*
\dt *search*
\dt *document*

# Verify sample data
SELECT COUNT(*) FROM user_events;
SELECT COUNT(*) FROM search_queries;
```

### Docker Service Connectivity
```bash
# Test service-to-service communication
docker exec fr07-analytics-dashboard curl http://fr07-analytics-api:8003/health

# Check Docker network
docker network ls | grep fr02
docker network inspect database_fr02_network
```

## 📊 Performance & Monitoring

### Health Checks
```bash
# API health (includes database connectivity)
curl http://localhost:8003/health

# Prometheus metrics
curl http://localhost:8003/metrics
```

### Logging
- **Location**: Docker container logs (`docker logs fr07-analytics-api`)
- **Level**: INFO (configurable via LOG_LEVEL environment variable)
- **Format**: Structured logs with timestamps and request correlation

### Metrics Collection
- **Request Duration**: HTTP request processing times
- **Request Count**: Total requests by method, endpoint, and status
- **Database Metrics**: Connection pool status, query performance
- **System Metrics**: CPU, memory, disk usage via dashboard

## 🚀 Production Deployment

### Environment Variables (Production)
```env
# Database (Production)
DATABASE_URL=postgresql://[prod_user]:[prod_pass]@[prod_host]:5432/[prod_db]

# Redis (Production)
REDIS_URL=redis://[prod_host]:6379/0

# API Configuration
API_RELOAD=false
API_WORKERS=4
LOG_LEVEL=WARNING

# Security
ALLOWED_ORIGINS=["https://your-domain.com"]
```

### Security Checklist
- [ ] Update database credentials for production
- [ ] Configure proper CORS origins
- [ ] Set up HTTPS/TLS termination
- [ ] Configure log aggregation
- [ ] Set up monitoring alerts
- [ ] Implement rate limiting
- [ ] Set up backup procedures for analytics data
- [ ] Configure firewall rules for ports 8003, 8501

## 📞 Support & Maintenance

### Key Components Status
- ✅ **Analytics API**: Production ready with comprehensive metrics collection
- ✅ **Streamlit Dashboard**: Interactive web interface with real-time data
- ✅ **Data Models**: Complete analytics data structure
- ✅ **Database Integration**: Seamless integration with FR-02 database
- ✅ **Docker Deployment**: Containerized with health checks
- ✅ **Monitoring**: Prometheus metrics and health endpoints
- ✅ **Visualization**: Interactive charts and data tables
- ✅ **Time-series Analytics**: Historical data analysis

### Next Development Steps
1. **Advanced Analytics**: Machine learning insights and predictive analytics
2. **Export Functionality**: PDF reports, CSV data export, scheduled reports
3. **Alert System**: Email/Slack notifications for critical metrics
4. **Data Archiving**: Automated old data archiving and cleanup
5. **Performance Optimization**: Query optimization and caching strategies
6. **Mobile Dashboard**: Responsive design improvements
7. **Real-time Updates**: WebSocket support for live data updates

### Contact Information
- **Documentation**: Complete API documentation at /docs endpoint
- **Code Repository**: D:\Projects\checkbot\docker\PC1\Database\FR-07\
- **Integration**: Full integration with FR-02 knowledge base system
- **Database**: Uses existing knowledge_base_v2 database

---

**Last Updated**: September 18, 2025
**Project Status**: Complete and Production Ready
**Next Milestone**: Advanced analytics and reporting features

---

## 🔧 Special Notes for FR-07

### Integration with FR-02
FR-07 is designed as a complementary analytics layer for the FR-02 knowledge base system:
- **Database Sharing**: Uses the same PostgreSQL database as FR-02
- **User Data**: Analyzes user activities from the shared users table
- **Document Analytics**: Tracks document access from shared document tables
- **Network Integration**: Part of the same Docker network as FR-02 services

### Analytics Data Collection
- **User Events**: Automatically collected from user activities
- **Search Queries**: Tracks all search operations with performance metrics
- **Document Access**: Monitors document usage patterns
- **System Performance**: Real-time system health and performance monitoring

### Dashboard Features
- **Real-time Updates**: Auto-refresh every 30 seconds option
- **Interactive Filters**: Time period, user level, document category filtering
- **Visual Analytics**: Gauge charts, line charts, pie charts, bar charts
- **Health Monitoring**: System health indicators with threshold alerts

### Performance Considerations
- **Caching**: Redis integration for improved response times
- **Async Operations**: Full async/await implementation for scalability
- **Connection Pooling**: Optimized database connection management
- **Monitoring**: Built-in Prometheus metrics for performance tracking

**FR-07 provides comprehensive analytics and insights into the knowledge base system usage and performance.**