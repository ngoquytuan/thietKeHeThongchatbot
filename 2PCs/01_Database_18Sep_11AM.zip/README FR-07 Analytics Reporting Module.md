# FR-07 Analytics & Reporting Module

A comprehensive analytics and reporting system for the RAG Knowledge Assistant, providing real-time insights into system performance, user behavior, and document usage.

## 🚀 Quick Start

1. **Clone and Setup**
   ```bash
   git clone <repository>
   cd FR-07
   cp .env.example .env
   # Edit .env with your configuration
   ```

2. **Start Services**
   ```bash
   ./scripts/start.sh
   ```

3. **Access Dashboards**
   - Analytics Dashboard: http://localhost:8501
   - API Documentation: http://localhost:8001/docs
   - Grafana: http://localhost:3000 (admin/admin)
   - Prometheus: http://localhost:9090

## 📊 Features

### Analytics Capabilities
- **Search Analytics**: Query performance, cache hit rates, popular searches
- **User Analytics**: Activity patterns, engagement metrics, role distribution
- **Document Analytics**: Usage patterns, popularity rankings, quality metrics
- **System Metrics**: CPU, memory, response times, uptime tracking

### Dashboard Features
- **Real-time Monitoring**: Live updates with auto-refresh
- **Interactive Visualizations**: Charts, graphs, and gauges
- **Time Range Filtering**: Custom date ranges and periods
- **Role-based Access**: Different views for different user levels
- **Export Capabilities**: PDF, CSV, Excel report generation

### API Endpoints
- `GET /api/analytics/search` - Search performance data
- `GET /api/analytics/users` - User behavior analytics
- `GET /api/analytics/documents` - Document usage statistics
- `GET /api/analytics/system` - System health metrics
- `POST /api/analytics/record/*` - Data collection endpoints

## 🏗️ Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Streamlit     │    │   FastAPI        │    │  PostgreSQL     │
│   Dashboard     │◄──►│   Analytics API  │◄──►│   Database      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         │              ┌─────────────────┐              │
         └──────────────►│     Redis       │◄─────────────┘
                        │     Cache       │
                        └─────────────────┘
                                 │
                        ┌─────────────────┐
                        │   Prometheus    │
                        │   Grafana       │
                        └─────────────────┘
```

## 🔧 Configuration

### Environment Variables (.env)
```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/rag_db
DB_HOST=localhost
DB_PORT=5432
DB_USER=user
DB_PASSWORD=password
DB_NAME=rag_db

# Redis
REDIS_URL=redis://localhost:6379

# API
API_HOST=0.0.0.0
API_PORT=8001

# Dashboard
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=8501

# JWT
SECRET_KEY=your-secret-key-here
```

### Docker Services
- **analytics-api**: FastAPI backend service
- **analytics-dashboard**: Streamlit frontend
- **postgres**: PostgreSQL database
- **redis**: Redis cache
- **prometheus**: Metrics collection
- **grafana**: Advanced dashboards
- **nginx**: Reverse proxy

## 📈 Usage

### Recording Analytics Events

```python
# Record search analytics
import requests

response = requests.post("http://localhost:8001/api/analytics/record/search", {
    "query_text": "machine learning best practices",
    "processing_time_ms": 150,
    "results_count": 25,
    "cache_hit": True
}, headers={"Authorization": "Bearer <token>"})
```

### Querying Analytics Data

```python
# Get search analytics
response = requests.get("http://localhost:8001/api/analytics/search", {
    "start_date": "2025-01-01T00:00:00Z",
    "end_date": "2025-01-31T23:59:59Z",
    "limit": 1000
}, headers={"Authorization": "Bearer <token>"})

data = response.json()
print(f"Total queries: {data['total_queries']}")
print(f"Average response time: {data['avg_processing_time_ms']}ms")
```

## 🔐 Security

### Authentication
- JWT-based authentication required for all endpoints
- Role-based access control (RBAC)
- Different permission levels for different user roles

### Access Levels
- **System Admin**: Full access to all analytics and system metrics
- **Director**: Access to all business analytics and reports
- **Manager**: Access to team and performance analytics
- **Employee**: Limited access to basic analytics
- **Guest**: No analytics access

## 🚀 Deployment

### Development
```bash
./scripts/start.sh
```

### Production
1. Update environment variables for production
2. Configure SSL certificates
3. Set up monitoring and alerting
4. Scale services as needed:
   ```bash
   docker-compose up --scale analytics-api=3 -d
   ```

## 📊 Monitoring

### Health Checks
- Service health: `http://localhost:8001/health`
- Database connectivity: Automatic health checks
- Redis availability: Built-in monitoring

### Metrics
- Prometheus metrics: `http://localhost:8001/metrics`
- Grafana dashboards: `http://localhost:3000`
- Application logs: `docker-compose logs -f`

## 🔧 Development

### Project Structure
```
analytics_module/
├── app/                    # FastAPI application
│   ├── api/               # API endpoints and dependencies
│   ├── core/              # Core configuration and database
│   ├── models/            # Database models
│   ├── schemas/           # Pydantic schemas
│   └── services/          # Business logic
├── dashboard/             # Streamlit dashboard
├── docker/               # Docker configurations
├── tests/                # Test files
└── scripts/              # Utility scripts
```

### Running Tests
```bash
pytest tests/
```

### API Development
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8001
```

### Dashboard Development
```bash
streamlit run dashboard/main.py --server.port 8501
```

## 📚 Documentation

- **API Documentation**: Available at `/docs` endpoint
- **Technical Documentation**: See `handover_FR07.md`
- **Architecture Diagrams**: In `docs/` directory

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check PostgreSQL status
   docker-compose logs postgres
   
   # Restart database
   docker-compose restart postgres
   ```

2. **Redis Connection Failed**
   ```bash
   # Check Redis status
   docker-compose logs redis
   
   # Clear Redis cache
   docker-compose exec redis redis-cli FLUSHALL
   ```

3. **API Service Not Responding**
   ```bash
   # Check API logs
   docker-compose logs analytics-api
   
   # Restart API service
   docker-compose restart analytics-api
   ```

4. **Dashboard Not Loading**
   ```bash
   # Check dashboard logs
   docker-compose logs analytics-dashboard
   
   # Check API connectivity from dashboard
   docker-compose exec analytics-dashboard curl http://analytics-api:8001/health
   ```

### Performance Tuning
- Adjust `db_pool_size` for database connections
- Scale API services: `docker-compose up --scale analytics-api=N -d`
- Configure Redis memory settings
- Optimize database indexes

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes with tests
4. Submit pull request

## 📞 Support

For issues and support:
1. Check logs: `docker-compose logs -f [service]`
2. Review documentation
3. Create issue in repository
4. Contact development team

## 📄 License

See LICENSE file for details.

---

**FR-07 Analytics & Reporting Module** - Providing comprehensive insights for the RAG Knowledge Assistant system.