"""
.\evaluate_search_quality_from_gold_standard.py
Evaluate Search Quality Using Gold Standard Queries

Script đánh giá chất lượng search sử dụng test queries được tạo
từ dữ liệu thực tế trong database.
"""

import requests
import json
import time
import statistics
from typing import List, Dict, Optional
from datetime import datetime

API_BASE = "http://localhost:8000/api/v1"

def load_gold_standard(filename: str = "gold_standard_template.json") -> List[Dict]:
    """Load test queries from JSON file"""
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"❌ File {filename} không tồn tại!")
        print("   Chạy script 'explore_database_for_test_queries.py' trước")
        return []

def evaluate_single_query(
    query_data: Dict, 
    method: str = "hybrid",
    verbose: bool = False
) -> Dict:
    """Đánh giá một query"""
    
    query = query_data["query"]
    
    # Send search request
    try:
        response = requests.post(f"{API_BASE}/search", json={
            "query": query,
            "search_method": method,
            "top_k": 10
        }, timeout=10)
        response.raise_for_status()
        results = response.json()['results']
    except Exception as e:
        print(f"❌ Lỗi khi search: {e}")
        return {
            "query": query,
            "category": query_data.get("category", "unknown"),
            "error": str(e),
            "passed": False
        }
    
    # Extract metrics
    top1_score = results[0]['score'] if results else 0
    top3_scores = [r['score'] for r in results[:3]]
    top3_avg = statistics.mean(top3_scores) if top3_scores else 0
    
    # Check if meets expectations
    passed = True
    failure_reasons = []
    
    # Check minimum score requirement
    if "min_top1_score" in query_data:
        if top1_score < query_data["min_top1_score"]:
            passed = False
            failure_reasons.append(
                f"Top-1 score {top1_score:.3f} < expected {query_data['min_top1_score']}"
            )
    
    # Check if expected documents appear
    if "expected_docs" in query_data:
        found_expected = False
        for result in results[:5]:  # Check top 5
            for expected_doc in query_data["expected_docs"]:
                if expected_doc.lower() in result.get('document_number', '').lower():
                    found_expected = True
                    break
            if found_expected:
                break
        
        if not found_expected:
            passed = False
            failure_reasons.append(
                f"Expected doc '{query_data['expected_docs'][0]}' not in top 5"
            )
    
    # Check minimum results
    if "min_results" in query_data:
        if len(results) < query_data["min_results"]:
            passed = False
            failure_reasons.append(
                f"Found {len(results)} results < expected {query_data['min_results']}"
            )
    
    # Prepare result
    eval_result = {
        "query": query,
        "category": query_data.get("category", "unknown"),
        "note": query_data.get("note", ""),
        "top1_score": top1_score,
        "top3_avg": top3_avg,
        "num_results": len(results),
        "passed": passed,
        "failure_reasons": failure_reasons,
        "top_results": [
            {
                "rank": i+1,
                "score": r['score'],
                "title": r.get('title', 'N/A')[:60],
                "doc_number": r.get('document_number', 'N/A')
            }
            for i, r in enumerate(results[:3])
        ]
    }
    
    # Verbose output
    if verbose:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"\n{status} | {query}")
        print(f"     Category: {eval_result['category']}")
        print(f"     Top-1 Score: {top1_score:.3f} | Top-3 Avg: {top3_avg:.3f}")
        if not passed:
            for reason in failure_reasons:
                print(f"     ⚠️  {reason}")
        if results:
            print(f"     Top result: [{results[0]['score']:.3f}] {results[0].get('title', 'N/A')[:50]}")
    
    return eval_result

def run_evaluation(
    gold_standard_file: str = "gold_standard_template.json",
    search_method: str = "hybrid",
    output_file: Optional[str] = None
) -> Dict:
    """Chạy evaluation trên toàn bộ test queries"""
    
    print("="*80)
    print("BẮT ĐẦU ĐÁNH GIÁ CHẤT LƯỢNG SEARCH")
    print("="*80)
    print(f"Gold Standard: {gold_standard_file}")
    print(f"Search Method: {search_method}")
    print(f"Thời gian: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)
    
    # Load test queries
    test_queries = load_gold_standard(gold_standard_file)
    if not test_queries:
        return {}
    
    print(f"\nTổng số test queries: {len(test_queries)}")
    
    # Run evaluation
    results = []
    for i, query_data in enumerate(test_queries, 1):
        print(f"\n[{i}/{len(test_queries)}] ", end="")
        result = evaluate_single_query(query_data, method=search_method, verbose=True)
        results.append(result)
        time.sleep(0.5)  # Rate limiting
    
    # Calculate summary statistics
    passed_count = sum(1 for r in results if r.get("passed", False))
    failed_count = len(results) - passed_count
    pass_rate = (passed_count / len(results) * 100) if results else 0
    
    avg_top1 = statistics.mean(r["top1_score"] for r in results if "top1_score" in r)
    avg_top3 = statistics.mean(r["top3_avg"] for r in results if "top3_avg" in r)
    
    # Group by category
    categories = {}
    for r in results:
        cat = r.get("category", "unknown")
        if cat not in categories:
            categories[cat] = {
                "passed": 0, 
                "total": 0, 
                "scores_top1": [],
                "scores_top3": []
            }
        categories[cat]["total"] += 1
        if r.get("passed", False):
            categories[cat]["passed"] += 1
        if "top1_score" in r:
            categories[cat]["scores_top1"].append(r["top1_score"])
        if "top3_avg" in r:
            categories[cat]["scores_top3"].append(r["top3_avg"])
    
    # Print summary
    print("\n" + "="*80)
    print("KẾT QUẢ TỔNG HỢP")
    print("="*80)
    print(f"Tổng số queries:     {len(results)}")
    print(f"✅ Passed:           {passed_count} ({pass_rate:.1f}%)")
    print(f"❌ Failed:           {failed_count} ({100-pass_rate:.1f}%)")
    print(f"\n📊 Điểm trung bình:")
    print(f"   Top-1 Score:      {avg_top1:.3f}")
    print(f"   Top-3 Avg Score:  {avg_top3:.3f}")
    
    # Category breakdown
    print(f"\n📂 PHÂN TÍCH THEO CATEGORY:")
    print(f"{'Category':<25s} | {'Pass/Total':>12s} | {'Rate':>6s} | {'Top-1':>6s} | {'Top-3':>6s}")
    print("-"*80)
    
    for cat, stats in sorted(categories.items()):
        cat_pass_rate = (stats["passed"] / stats["total"] * 100) if stats["total"] > 0 else 0
        avg_top1_cat = statistics.mean(stats["scores_top1"]) if stats["scores_top1"] else 0
        avg_top3_cat = statistics.mean(stats["scores_top3"]) if stats["scores_top3"] else 0
        
        print(f"{cat:<25s} | {stats['passed']:>3d}/{stats['total']:<3d} ({cat_pass_rate:>5.1f}%) | "
              f"{cat_pass_rate:>5.1f}% | {avg_top1_cat:>5.3f} | {avg_top3_cat:>5.3f}")
    
    # Failed queries detail
    failed_queries = [r for r in results if not r.get("passed", False)]
    if failed_queries:
        print(f"\n❌ CHI TIẾT QUERIES FAILED ({len(failed_queries)} queries):")
        print("-"*80)
        for r in failed_queries[:10]:  # Show first 10
            print(f"\nQuery: {r['query']}")
            print(f"  Category: {r['category']}")
            print(f"  Score: Top-1={r.get('top1_score', 0):.3f}, Top-3={r.get('top3_avg', 0):.3f}")
            for reason in r.get("failure_reasons", []):
                print(f"  ⚠️  {reason}")
    
    # Quality assessment
    print("\n" + "="*80)
    print("📈 ĐÁNH GIÁ CHẤT LƯỢNG")
    print("="*80)
    
    def assess_score(score, thresholds):
        if score >= thresholds['good']:
            return "✅ Excellent"
        elif score >= thresholds['acceptable']:
            return "⚠️  Good"
        else:
            return "❌ Needs Work"
    
    print(f"Pass Rate:        {pass_rate:.1f}% - {assess_score(pass_rate/100, {'good': 0.80, 'acceptable': 0.60})}")
    print(f"Top-1 Score:      {avg_top1:.3f} - {assess_score(avg_top1, {'good': 0.75, 'acceptable': 0.60})}")
    print(f"Top-3 Avg Score:  {avg_top3:.3f} - {assess_score(avg_top3, {'good': 0.70, 'acceptable': 0.55})}")
    
    # Recommendations
    print("\n💡 KHUYẾN NGHỊ:")
    if pass_rate < 60:
        print("   1. Pass rate thấp - cần cải thiện search quality ngay")
        print("   2. Review failed queries để tìm patterns")
    if avg_top1 < 0.60:
        print("   3. Top-1 score thấp - xem xét:")
        print("      - Fine-tune embedding model")
        print("      - Improve chunking strategy")
        print("      - Check score normalization")
    if avg_top1 < avg_top3 * 0.9:
        print("   4. Score gap nhỏ giữa top-1 và top-3 - ranking có thể cần cải thiện")
    
    # Save results
    summary = {
        "evaluation_time": datetime.now().isoformat(),
        "gold_standard_file": gold_standard_file,
        "search_method": search_method,
        "summary": {
            "total_queries": len(results),
            "passed": passed_count,
            "failed": failed_count,
            "pass_rate": pass_rate,
            "avg_top1_score": avg_top1,
            "avg_top3_score": avg_top3
        },
        "by_category": {
            cat: {
                "passed": stats["passed"],
                "total": stats["total"],
                "pass_rate": (stats["passed"] / stats["total"] * 100) if stats["total"] > 0 else 0,
                "avg_top1": statistics.mean(stats["scores_top1"]) if stats["scores_top1"] else 0,
                "avg_top3": statistics.mean(stats["scores_top3"]) if stats["scores_top3"] else 0
            }
            for cat, stats in categories.items()
        },
        "detailed_results": results
    }
    
    if output_file is None:
        output_file = f"evaluation_results_{search_method}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    
    print(f"\n✅ Kết quả đã lưu vào: {output_file}")
    print("="*80)
    
    return summary

def compare_search_methods(gold_standard_file: str = "gold_standard_template.json"):
    """So sánh các search methods khác nhau"""
    
    print("\n" + "="*80)
    print("SO SÁNH CÁC SEARCH METHODS")
    print("="*80)
    
    methods = ["semantic", "bm25", "keyword", "hybrid"]
    results = {}
    
    for method in methods:
        print(f"\n{'='*80}")
        print(f"Đang test method: {method.upper()}")
        print('='*80)
        
        result = run_evaluation(
            gold_standard_file=gold_standard_file,
            search_method=method,
            output_file=f"eval_{method}.json"
        )
        results[method] = result
        
        time.sleep(2)  # Pause between methods
    
    # Comparison table
    print("\n" + "="*80)
    print("BẢNG SO SÁNH")
    print("="*80)
    print(f"{'Method':<12s} | {'Pass Rate':>10s} | {'Top-1':>6s} | {'Top-3':>6s}")
    print("-"*80)
    
    for method in methods:
        summary = results[method].get("summary", {})
        print(f"{method:<12s} | {summary.get('pass_rate', 0):>9.1f}% | "
              f"{summary.get('avg_top1_score', 0):>6.3f} | "
              f"{summary.get('avg_top3_score', 0):>6.3f}")
    
    print("\n💡 Best Method:")
    best_method = max(methods, key=lambda m: results[m].get("summary", {}).get("avg_top1_score", 0))
    print(f"   {best_method.upper()} - Top-1 Score: {results[best_method]['summary']['avg_top1_score']:.3f}")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "compare":
            # Compare all methods
            compare_search_methods()
        else:
            # Single method evaluation
            method = sys.argv[1]
            run_evaluation(search_method=method)
    else:
        # Default: evaluate hybrid only
        run_evaluation(search_method="hybrid")
