"""
.\explore_database_for_test_queries.py
Explore Database to Generate Realistic Test Queries

Script để khám phá dữ liệu trong database và tạo test queries phù hợp
với văn bản pháp luật thực tế có trong hệ thống.
"""

import psycopg2
from typing import List, Dict
import json

# Database connection
DB_CONFIG = {
    'host': '192.168.1.70',
    'port': 15432,
    'database': 'chatbotR4',
    'user': 'kb_admin',
    'password': '1234567890'
}

def connect_db():
    """Connect to PostgreSQL database"""
    return psycopg2.connect(**DB_CONFIG)

def explore_documents():
    """Khám phá các văn bản có trong database"""
    conn = connect_db()
    cursor = conn.cursor()
    
    print("="*80)
    print("1. THỐNG KÊ TỔNG QUAN")
    print("="*80)
    
    # Total documents
    cursor.execute("SELECT COUNT(*) FROM documents")
    total_docs = cursor.fetchone()[0]
    print(f"Tổng số văn bản: {total_docs:,}")
    
    # Total chunks
    cursor.execute("SELECT COUNT(*) FROM document_chunks")
    total_chunks = cursor.fetchone()[0]
    print(f"Tổng số chunks: {total_chunks:,}")
    
    print("\n" + "="*80)
    print("2. CÁC LOẠI VĂN BẢN (Top 20)")
    print("="*80)
    
    # Document types
    cursor.execute("""
        SELECT 
            document_type,
            COUNT(*) as count,
            COUNT(*) * 100.0 / SUM(COUNT(*)) OVER() as percentage
        FROM documents
        WHERE document_type IS NOT NULL
        GROUP BY document_type
        ORDER BY count DESC
        LIMIT 20
    """)
    
    print(f"{'Loại văn bản':<40s} | {'Số lượng':>10s} | {'%':>6s}")
    print("-"*80)
    for row in cursor.fetchall():
        doc_type, count, pct = row
        print(f"{doc_type:<40s} | {count:>10,d} | {pct:>5.1f}%")
    
    print("\n" + "="*80)
    print("3. CƠ QUAN BAN HÀNH (Top 20)")
    print("="*80)
    
    cursor.execute("""
        SELECT 
            issuing_body,
            COUNT(*) as count
        FROM documents
        WHERE issuing_body IS NOT NULL
        GROUP BY issuing_body
        ORDER BY count DESC
        LIMIT 20
    """)
    
    print(f"{'Cơ quan ban hành':<50s} | {'Số lượng':>10s}")
    print("-"*80)
    for row in cursor.fetchall():
        body, count = row
        print(f"{body:<50s} | {count:>10,d}")
    
    print("\n" + "="*80)
    print("4. MỘT SỐ VĂN BẢN MẪU")
    print("="*80)
    
    cursor.execute("""
        SELECT 
            document_number,
            title,
            document_type,
            issuing_body
        FROM documents
        ORDER BY created_at DESC
        LIMIT 10
    """)
    
    print(f"{'Số hiệu':<30s} | {'Tiêu đề':<60s}")
    print("-"*80)
    for row in cursor.fetchall():
        doc_num, title, doc_type, body = row
        title_short = title[:57] + "..." if len(title) > 60 else title
        print(f"{doc_num:<30s} | {title_short:<60s}")
    
    conn.close()
    
    print("\n" + "="*80)
    print("HOÀN TẤT KHÁM PHÁ DỮ LIỆU")
    print("="*80)

def suggest_test_queries():
    """Gợi ý các loại test queries dựa trên data thực tế"""
    conn = connect_db()
    cursor = conn.cursor()
    
    print("\n" + "="*80)
    print("5. GỢI Ý TEST QUERIES")
    print("="*80)
    
    # Category 1: Exact document lookup (từ số hiệu văn bản thực tế)
    print("\n📌 Category 1: EXACT DOCUMENT LOOKUP (tìm theo số hiệu)")
    cursor.execute("""
        SELECT DISTINCT document_number, title
        FROM documents
        WHERE document_number IS NOT NULL
        ORDER BY RANDOM()
        LIMIT 10
    """)
    
    exact_lookup_queries = []
    for row in cursor.fetchall():
        doc_num, title = row
        exact_lookup_queries.append({
            "query": doc_num,
            "expected_doc": doc_num,
            "category": "exact_lookup",
            "title": title[:60]
        })
        print(f"  - \"{doc_num}\" → Expect: {title[:60]}...")
    
    # Category 2: Concept search (từ title/content)
    print("\n📌 Category 2: CONCEPT SEARCH (tìm theo khái niệm)")
    cursor.execute("""
        SELECT DISTINCT 
            SUBSTRING(content FROM 1 FOR 100) as sample_text,
            title
        FROM document_chunks
        WHERE content IS NOT NULL
            AND LENGTH(content) > 50
        ORDER BY RANDOM()
        LIMIT 10
    """)
    
    concept_queries = []
    for row in cursor.fetchall():
        sample, title = row
        # Extract potential keywords
        words = sample.split()[:5]
        query = " ".join(words)
        concept_queries.append({
            "query": query,
            "expected_in_results": title,
            "category": "concept_search"
        })
        print(f"  - \"{query}...\"")
    
    # Category 3: Document type search
    print("\n📌 Category 3: DOCUMENT TYPE SEARCH (tìm theo loại văn bản)")
    cursor.execute("""
        SELECT DISTINCT document_type
        FROM documents
        WHERE document_type IS NOT NULL
        LIMIT 10
    """)
    
    type_queries = []
    for row in cursor.fetchall():
        doc_type = row[0]
        type_queries.append({
            "query": doc_type,
            "category": "type_search"
        })
        print(f"  - \"{doc_type}\"")
    
    # Category 4: Issuing body search
    print("\n📌 Category 4: ISSUING BODY SEARCH (tìm theo cơ quan ban hành)")
    cursor.execute("""
        SELECT DISTINCT issuing_body
        FROM documents
        WHERE issuing_body IS NOT NULL
        LIMIT 10
    """)
    
    body_queries = []
    for row in cursor.fetchall():
        body = row[0]
        body_queries.append({
            "query": f"văn bản {body}",
            "category": "issuing_body_search"
        })
        print(f"  - \"văn bản {body}\"")
    
    conn.close()
    
    # Save to JSON file
    all_queries = {
        "exact_lookup": exact_lookup_queries,
        "concept_search": concept_queries,
        "type_search": type_queries,
        "issuing_body_search": body_queries
    }
    
    with open("suggested_test_queries.json", "w", encoding="utf-8") as f:
        json.dump(all_queries, f, ensure_ascii=False, indent=2)
    
    print("\n✅ Đã lưu gợi ý queries vào: suggested_test_queries.json")

def generate_gold_standard_template():
    """Tạo template cho gold standard test queries"""
    conn = connect_db()
    cursor = conn.cursor()
    
    # Get real document samples
    cursor.execute("""
        SELECT 
            document_number,
            title,
            document_type,
            issuing_body
        FROM documents
        WHERE document_number IS NOT NULL
        ORDER BY RANDOM()
        LIMIT 20
    """)
    
    test_queries = []
    
    for row in cursor.fetchall():
        doc_num, title, doc_type, body = row
        
        # Query 1: Exact number
        test_queries.append({
            "query": doc_num,
            "expected_docs": [doc_num],
            "min_top1_score": 0.90,
            "category": "exact_lookup",
            "note": f"Tìm chính xác: {title[:50]}"
        })
        
        # Query 2: Concept from title
        title_words = title.split()[:8]
        concept_query = " ".join(title_words)
        test_queries.append({
            "query": concept_query,
            "expected_keywords": title_words[:5],
            "min_top1_score": 0.70,
            "category": "concept_search",
            "note": f"Tìm theo khái niệm từ: {title[:50]}"
        })
    
    # Save template
    with open("gold_standard_template.json", "w", encoding="utf-8") as f:
        json.dump(test_queries, f, ensure_ascii=False, indent=2)
    
    conn.close()
    
    print(f"\n✅ Đã tạo {len(test_queries)} test queries mẫu")
    print("   File: gold_standard_template.json")
    print("\n💡 Bước tiếp theo:")
    print("   1. Mở file gold_standard_template.json")
    print("   2. Review và adjust expected_docs, min_top1_score")
    print("   3. Thêm queries thủ công nếu cần")
    print("   4. Save lại và dùng cho evaluation")

if __name__ == "__main__":
    print("KHÁM PHÁ DỮ LIỆU ĐỂ TẠO TEST QUERIES PHÙ HỢP\n")
    
    try:
        # Step 1: Explore what data we have
        explore_documents()
        
        # Step 2: Suggest queries based on real data
        suggest_test_queries()
        
        # Step 3: Generate gold standard template
        generate_gold_standard_template()
        
    except Exception as e:
        print(f"\n❌ Lỗi: {e}")
        import traceback
        traceback.print_exc()
