"""
.\quick_quality_check.py
Quick Quality Check for Search System

Script kiểm tra nhanh chất lượng search với một vài queries mẫu
từ database để đánh giá sơ bộ.
"""

import requests
import time
from typing import List, Dict

API_BASE = "http://localhost:8000/api/v1"

def test_single_query(query: str, method: str = "hybrid") -> Dict:
    """Test một query và hiển thị kết quả"""
    
    print(f"\n{'='*80}")
    print(f"Query: {query}")
    print(f"Method: {method}")
    print('='*80)
    
    try:
        response = requests.post(f"{API_BASE}/search", json={
            "query": query,
            "search_method": method,
            "top_k": 5
        }, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        results = data['results']
        
        if not results:
            print("❌ Không có kết quả")
            return {"query": query, "method": method, "score": 0, "found": 0}
        
        # Display results
        print(f"\nTìm thấy: {len(results)} kết quả")
        print(f"Top-1 Score: {results[0]['score']:.3f}")
        
        top3_scores = [r['score'] for r in results[:3]]
        top3_avg = sum(top3_scores) / len(top3_scores) if top3_scores else 0
        print(f"Top-3 Avg:   {top3_avg:.3f}")
        
        print(f"\n{'Rank':<6s} {'Score':<8s} {'Title':<60s}")
        print('-'*80)
        
        for i, result in enumerate(results[:5], 1):
            title = result.get('title', 'N/A')[:57]
            if len(result.get('title', '')) > 60:
                title += "..."
            print(f"{i:<6d} {result['score']:<8.3f} {title}")
        
        return {
            "query": query,
            "method": method,
            "top1_score": results[0]['score'],
            "top3_avg": top3_avg,
            "found": len(results)
        }
        
    except Exception as e:
        print(f"❌ Lỗi: {e}")
        return {"query": query, "method": method, "error": str(e)}

def compare_methods_for_query(query: str):
    """So sánh các search methods cho cùng một query"""
    
    print(f"\n{'='*80}")
    print(f"SO SÁNH METHODS CHO QUERY: {query}")
    print('='*80)
    
    methods = ["semantic", "bm25", "keyword", "hybrid"]
    results = {}
    
    for method in methods:
        result = test_single_query(query, method)
        results[method] = result
        time.sleep(0.5)
    
    # Summary table
    print(f"\n{'='*80}")
    print("BẢNG SO SÁNH")
    print('='*80)
    print(f"{'Method':<12s} | {'Top-1 Score':>12s} | {'Top-3 Avg':>12s} | {'Results':>8s}")
    print('-'*80)
    
    for method in methods:
        r = results[method]
        top1 = r.get('top1_score', 0)
        top3 = r.get('top3_avg', 0)
        found = r.get('found', 0)
        print(f"{method:<12s} | {top1:>12.3f} | {top3:>12.3f} | {found:>8d}")
    
    # Identify best
    best_method = max(methods, key=lambda m: results[m].get('top1_score', 0))
    print(f"\n✅ Best method: {best_method.upper()} (Top-1: {results[best_method]['top1_score']:.3f})")
    
    # Check if hybrid is actually best
    hybrid_score = results['hybrid'].get('top1_score', 0)
    semantic_score = results['semantic'].get('top1_score', 0)
    
    if hybrid_score < semantic_score:
        gap = semantic_score - hybrid_score
        print(f"\n⚠️  WARNING: Hybrid ({hybrid_score:.3f}) < Semantic ({semantic_score:.3f})")
        print(f"   Gap: {gap:.3f} points ({gap/semantic_score*100:.1f}% worse)")
        print(f"   → Hybrid weights cần được tối ưu!")

def quick_health_check():
    """Kiểm tra sức khỏe hệ thống với một số queries cơ bản"""
    
    print("\n" + "="*80)
    print("QUICK HEALTH CHECK")
    print("="*80)
    
    # Test queries - BẠN NÊN THAY BẰNG QUERIES THỰC TẾ TỪ DATABASE
    test_queries = [
        "luật doanh nghiệp",           # Basic keyword
        "điều kiện thành lập công ty",  # Concept search
        "quyền cổ đông",               # Short query
    ]
    
    print("\n💡 Đang test với queries mẫu...")
    print("   (Bạn nên chạy explore_database_for_test_queries.py để có queries thực tế)")
    
    results = []
    for query in test_queries:
        result = test_single_query(query, method="hybrid")
        results.append(result)
        time.sleep(0.5)
    
    # Summary
    print("\n" + "="*80)
    print("HEALTH CHECK SUMMARY")
    print("="*80)
    
    avg_top1 = sum(r.get('top1_score', 0) for r in results) / len(results)
    avg_top3 = sum(r.get('top3_avg', 0) for r in results) / len(results)
    zero_results = sum(1 for r in results if r.get('found', 0) == 0)
    
    print(f"Queries tested:   {len(results)}")
    print(f"Avg Top-1 Score:  {avg_top1:.3f}")
    print(f"Avg Top-3 Score:  {avg_top3:.3f}")
    print(f"Zero results:     {zero_results}/{len(results)}")
    
    # Assessment
    print(f"\n📊 Assessment:")
    if avg_top1 >= 0.75:
        print("   ✅ Top-1 Score: Excellent")
    elif avg_top1 >= 0.60:
        print("   ⚠️  Top-1 Score: Good, có thể cải thiện")
    else:
        print("   ❌ Top-1 Score: Cần cải thiện ngay")
    
    if zero_results == 0:
        print("   ✅ Coverage: Excellent (no zero-result queries)")
    else:
        print(f"   ⚠️  Coverage: {zero_results} queries không có kết quả")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "compare":
            # Compare methods for a query
            query = sys.argv[2] if len(sys.argv) > 2 else "luật doanh nghiệp"
            compare_methods_for_query(query)
        elif sys.argv[1] == "health":
            # Quick health check
            quick_health_check()
        else:
            # Single query test
            query = sys.argv[1]
            method = sys.argv[2] if len(sys.argv) > 2 else "hybrid"
            test_single_query(query, method)
    else:
        # Default: health check
        print("📋 Usage:")
        print("  python quick_quality_check.py health                    # Quick health check")
        print("  python quick_quality_check.py compare \"query\"           # Compare methods")
        print('  python quick_quality_check.py "query" hybrid           # Test single query')
        print()
        quick_health_check()
